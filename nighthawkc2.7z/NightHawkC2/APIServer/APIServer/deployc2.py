# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import os
import sys
import json
import subprocess
import requests
import urllib3
from time import sleep
from threading import Thread

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import apimanager

ApiManager = apimanager.ApiManager.get_instance()

class DEPLOYED_C2_STATUS(object):
	RUNNING = 1
	TERMINATED = 2
	ERROR = 3
	
	@staticmethod
	def name(value):
		return {
				DEPLOYED_C2_STATUS.RUNNING: "RUNNING",
				DEPLOYED_C2_STATUS.TERMINATED: "TERMINATED",
				DEPLOYED_C2_STATUS.ERROR: "ERROR",
			}[value]

class DeployedC2Instance(object):
	class DummyProcess(object):
		def poll(self):
			return None
		def wait(self):
			return
		def kill(self):
			return

	C2SERVER_SCRIPT = r"../../C2Server/C2Server/c2server.py"
	PROFILE_DIRECTORY = "profiles"
	
	@staticmethod
	def adopt(listener_name, secret, profile):
		adopted_inst = DeployedC2Instance(listener_name, secret, profile)
		adopted_inst.__process = DeployedC2Instance.DummyProcess()
		return adopted_inst

	@staticmethod
	def create(listener_name, secret, profile):
		deployed_inst = DeployedC2Instance(listener_name, secret, profile)
		deployed_inst.launch()
		
		for i in xrange(10):
			if deployed_inst.status() != DEPLOYED_C2_STATUS.RUNNING:
				break
			
			# give it one second (0.1 * 10 = 1) to either error or run ok. this is not
			# ideal cos we're in a locking thread, but this API will not be called often
			# so it's probably ok
			sleep(0.1)
		
		if deployed_inst.status() == DEPLOYED_C2_STATUS.RUNNING:
			deployed_inst.__worker = DeployedC2InstanceWorker(deployed_inst)
			deployed_inst.__worker.start()
		
		return deployed_inst
	
	def __init__(self, listener_name, secret, profile):
		self.ListenerName = listener_name
		self.Secret = secret
		self.Profile = profile
		self.__profile_filename = None
		self.__process = None
		self.__worker = None
		self.__write_profile() # call from ctor as if this throws the instance is invalid anyway
		return
	
	def __write_profile(self):
		if not os.path.exists("profiles"):
			os.mkdir("profiles")
		
		filename = os.path.join(os.getcwd(), "%s/%s.json" % (DeployedC2Instance.PROFILE_DIRECTORY, self.ListenerName))
		
		with open(filename, "wb") as f:
			f.write(json.dumps(self.Profile))
		
		self.__profile_filename = filename
		return
	
	def launch(self):
		self.__process = subprocess.Popen(
				[
					sys.executable,
					DeployedC2Instance.C2SERVER_SCRIPT,
					self.ListenerName,
					self.Secret,
					"--profile=%s" % self.__profile_filename
				]
			)
		return
	
	def wait(self):
		self.__process.wait()
		return
	
	def status(self):
		rc = self.__process.poll()
		
		if rc is None:
			return DEPLOYED_C2_STATUS.RUNNING
		elif rc == 0:
			return DEPLOYED_C2_STATUS.TERMINATED
		
		return DEPLOYED_C2_STATUS.ERROR
	
	def teardown(self):
		if self.__process and self.__process.poll() is None:
			self.__process.kill()
		
		if os.path.exists(self.__profile_filename):
			os.remove(self.__profile_filename)
		return

# this exists so that if a deployed instance dies we can still unregister it from the ApiManager
# the thread termination event when the API server exits will also lead to teardown of each C2
# process as an added benefit
class DeployedC2InstanceWorker(Thread):
	def __init__(self, deployed_inst):
		super(DeployedC2InstanceWorker, self).__init__()
		self.__deployed_inst = deployed_inst
		self.__watchdog = False
		self.__watchdog_frequency = 5

		settings = deployed_inst.Profile["c2-profile"]["server-config"]["settings"]

		if "watchdog" in settings:
			self.__watchdog = bool(settings["watchdog"])
		
		if "watchdog-frequency" in settings:
			self.__watchdog_frequency = int(settings["watchdog-frequency"])

		return
	
	def __do_watchdog(self):
		try:
			is_ssl = bool(self.__deployed_inst.Profile["c2-profile"]["server-config"]["settings"]["ssl"]["enabled"])
			deployed_port = int(self.__deployed_inst.Profile["c2-profile"]["server-config"]["settings"]["port"])
			watchdog_url = "%s://127.0.0.1:%u/watchdog/%s" % ("https" if is_ssl else "http", deployed_port, self.__deployed_inst.Secret)
			r = requests.get(watchdog_url, verify=False)
			if r and r.status_code == 200 and r.text == "WATCHDOG":
				return True
		except:
			pass
		return

	def run(self):
		watchdog_failed = False

		if not self.__watchdog:
			self.__deployed_inst.wait()
		else:
			counter = 0

			while self.__deployed_inst.status() == DEPLOYED_C2_STATUS.RUNNING:
				if counter >= self.__watchdog_frequency:
					if not self.__do_watchdog():
						watchdog_failed = True
						break
					counter = 0
				counter += 1
				sleep(1)

			ApiManager.control_teardownc2(self.__deployed_inst.ListenerName)
		
		if watchdog_failed:
			ApiManager.control_deployc2(
				self.__deployed_inst.ListenerName,
				self.__deployed_inst.Secret,
				self.__deployed_inst.Profile,
				True)
		return

if __name__ == "__main__":
	with open("default.json") as f:
		inst = DeployedC2Instance.create("demo", json.loads(f.read()))
		while True:
			print DEPLOYED_C2_STATUS.name(inst.status())
			sleep(1)
