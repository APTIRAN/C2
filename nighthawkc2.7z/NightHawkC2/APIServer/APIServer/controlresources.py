# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import falcon
import apimanager
from base64 import b64encode

from deployc2 import DEPLOYED_C2_STATUS

ApiManager = apimanager.ApiManager.get_instance()

class ControlStatusResource(object):
	def on_get(self, req, resp):
		r = ApiManager.get_customer_info()
		if r:
			resp.media = r
		
		resp.status = falcon.HTTP_200
		return

class ControlCheckAuthResource(object):
	def on_post(self, req, resp):
		if ApiManager.control_checkauth(req.media["username"], req.media["password"]):
			resp.status = falcon.HTTP_200
			return
		
		resp.status = falcon.HTTP_403
		return

class ConsoleAddUserResource(object):
	def on_post(self, req, resp):
		if ApiManager.control_adduser(req.media["username"], req.media["password"]):
			resp.status = falcon.HTTP_200
			return
		
		resp.status = falcon.HTTP_403
		return

class ControlGetListenersResource(object):
	def on_get(self, req, resp):
		listeners = ApiManager.control_getlisteners()
		if not listeners:
			resp.status = falcon.HTTP_204
			return

		resp.status = falcon.HTTP_200
		resp.media = {"listeners": listeners}
		return
	
class ControlGetListenerProfileResource(object):
	def on_get(self, req, resp, listener_name):
		profile = ApiManager.control_getlistenerprofile(listener_name)
		if not profile:
			resp.status = falcon.HTTP_204
			return

		resp.status = falcon.HTTP_200
		resp.media = {"profile": profile}
		return
		
class ControlGetAgentProfileResource(object):
	def on_post(self, req, resp, listener_name):
		profile = ApiManager.control_getagentprofile(listener_name, req.media["uri"], req.media["type"], req.media["proxy_uri"])
		if not profile:
			resp.status = falcon.HTTP_204
			return

		resp.status = falcon.HTTP_200
		resp.media = {"profile": profile}
		return

class ControlGetActionResource(object):
	def on_get(self, req, resp, listener_name):
		action = ApiManager.control_getaction(listener_name)
		if not action:
			resp.status = falcon.HTTP_204
			return
		
		resp.status = falcon.HTTP_200
		resp.media = {"action": action}
		return

class ControlPutActionResource(object):
	def on_post(self, req, resp, listener_name):
		if not ApiManager.control_putaction(listener_name, req.media["action"]):
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class ControlDeployC2Resource(object):
	def on_post(self, req, resp, listener_name):
		result = ApiManager.control_deployc2(listener_name, req.media["secret"], req.media["profile"])
		if not result:
			resp.status = falcon.HTTP_409 # already exists
			return
		
		if result != DEPLOYED_C2_STATUS.RUNNING:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class ControlTeardownC2Resource(object):
	def on_get(self, req, resp, listener_name):
		if not ApiManager.control_teardownc2(listener_name):
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class ControlTeardownAllC2Resource(object):
	def on_get(self, req, resp):
		if not ApiManager.control_teardownallc2():
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class ControlAdoptC2Resource(object):
	def on_post(self, req, resp, listener_name):
		result = ApiManager.control_adoptc2(listener_name, req.media["secret"], req.media["profile"])
		if not result:
			resp.status = falcon.HTTP_409 # already exists
			return
		
		if result != DEPLOYED_C2_STATUS.RUNNING:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class ControlPayloadGeneratorResource(object):
	def on_post(self, req, resp, listener_name):
		try:
			r = ApiManager.control_payload_gen(listener_name, req.media["payload_request"])
			if not r:
				resp.status = 500
				return
		
			payload,filename = r
		except Exception as ex:
			resp.media = {"error": ex.message}
			resp.status = falcon.HTTP_500
			return

		resp.status = falcon.HTTP_200
		resp.media = {"payload": b64encode(payload), "filename": filename} 
		return
	
class ControlPayloadFromAgentProfileResource(object):
	def on_post(self, req, resp, listener_name):
		try:
			r = ApiManager.control_payload_gen_from_agentprofile(listener_name, req.media["agent_profile"], req.media["payload_request"])
			if not r:
				resp.status = 500
				return
			
			payload,filename = r
		except Exception as ex:
			resp.media = {"error": ex.message}
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = {"payload": b64encode(payload), "filename": filename} 
		return

class ControlStegoStagerGeneratorResource(object):
	def on_post(self, req, resp):
		try:
			r = ApiManager.control_stego_stager_gen(req.media["stager_request"])
			if not r:
				resp.status = 500
				return
			resp.status = falcon.HTTP_200
			resp.media = r
		except Exception as ex:
			resp.media = {"error": ex.message}
			resp.status = falcon.HTTP_200
			return
		return
