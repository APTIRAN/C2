# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import sys
import sqlite3
import os
import json
from base64 import b64decode, b64encode
from datetime import datetime
from pprint import pprint
import struct
import csv
import re

from apimanager import ECommsProtocolMessageType

class LogCommandEntry(object):
	def __init__(self, timestamp, client_id, message_id, protomsg_type_name):
		self.TimeStamp = timestamp
		self.ClientId = client_id
		self.MessageId = message_id
		self.FriendlyName = ""
		self.ProtoMsgType = protomsg_type_name
		self.PayloadLength = None
		self.ResultLength = None
		self.Priority = "LOW"
		self.Issuer = ""
		self.VerbatimCommand = ""
		self.Description = [] # strings
		self.ConsoleInput = [] # strings
		self.ConsoleOutput = [] # strings
		self.Tags = [] # strings
		return

	def __repr__(self):
		return ("%s\n%-20s | %-40s | %-20s | %-10s\n%s\n%s\n\n%s\n") % (
			"-" * 110,
			self.TimeStamp,
			self.ClientId,
			self.ProtoMsgType,
			self.Priority,
			"-" * 110,
			"" if not self.Description else ("DESCRIPTION:\n" + "\n".join(self.Description)),
			"" if not self.ConsoleOutput else ("OUTPUT:\n" + "\n".join(self.ConsoleOutput))
		)

class DatabaseExporter(object):
	__instance = None
	__DB_FOLDER_PATH = "./db/"

	@staticmethod
	def get_instance(name):
		if not DatabaseExporter.__instance:
			DatabaseExporter.__instance = DatabaseExporter(name)
		return DatabaseExporter.__instance
	
	def __init__(self, name):
		self.__db_name = name
		self.__db_path = DatabaseExporter.__DB_FOLDER_PATH + name + ".db"
		return
	
	def __get_protomsg_type(self, payload_header):
		return struct.unpack("<I", payload_header[40:44])[0]

	def __get_protomsg_length(self, payload_header):
		return struct.unpack("<I", payload_header[44:48])[0]
	
	def __extract_friendlyname(self, name_map, entry):
		if entry.ProtoMsgType != "CPMT_GET_DETAILED_INFO":
			return

		for desc in entry.ConsoleOutput:
			m = re.search(r"Machine: (.*?), User: (.*?), Process: (.*?) \(PID: (.*?)\)", desc)
			if m:
				name_map[entry.ClientId] = "%s:%s:%s:%s" % (m.group(1), m.group(2), m.group(3), m.group(4))
		return

	def __extract_logs(self, index, limit):
		log_entries = []
		
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute("SELECT TimeStamp, ClientId, MessageId, PayloadHeader, ResultHeader FROM LoggedCommands ORDER BY TimeStamp LIMIT ? OFFSET ?", (limit, index))
				logged_commands = cur.fetchall()
				
				for logged_command in logged_commands:
					try:
						timestamp = datetime.strptime(logged_command[0], "%Y-%m-%d %H:%M:%S.%f") # 2021-04-06 15:11:06.585000
					except ValueError:
						timestamp = datetime.strptime(logged_command[0], "%Y-%m-%d %H:%M:%S")
					payload_header = b64decode(logged_command[3])
					payload_type_name = ECommsProtocolMessageType.name(self.__get_protomsg_type(payload_header))
					payload_length = self.__get_protomsg_length(payload_header)
					
					entry = LogCommandEntry(timestamp, logged_command[1], logged_command[2], payload_type_name)
					entry.PayloadLength = payload_length
					
					if logged_command[4]:
						result_header = b64decode(logged_command[4])
						result_length = self.__get_protomsg_length(result_header)
						entry.ResultLength = result_length

					cur.execute("SELECT TimeStamp, MessageId, CommandExtraDataType, ExtraData FROM LoggedCommandExtraData WHERE MessageId = ? ORDER BY TimeStamp", (entry.MessageId,))
					extra_data = cur.fetchall()

					for data in extra_data:
						if data[2] == "ISSUER":
							entry.Issuer = data[3]
						elif data[2] == "VERBATIM_COMMAND":
							entry.VerbatimCommand = data[3]
						elif data[2] == "DESCRIPTION":
							entry.Description.append(data[3])
						elif data[2] == "PRIORITY":
							entry.Priority = data[3]
						elif data[2] == "CONSOLE_INPUT":
							entry.ConsoleInput.append(data[3])
						elif data[2] == "CONSOLE_OUTPUT":
							entry.ConsoleOutput.append(data[3])
						elif data[2] == "TAGS":
							entry.Tags.append(data[3])

					log_entries.append(entry)
		finally:
			conn.close()
		return log_entries

	def export_xml(self, f):
		header = '<?xml version="1.0" encoding="utf-8"?>\n<Commands>'
		footer = '</Commands>'
		template = """
<Command>
	<TimeStamp>%s</TimeStamp>
	<ClientId>%s</ClientId>
	<MessageId>%s</MessageId>
	<FriendlyName>%s</FriendlyName>
	<ProtoMsgType>%s</ProtoMsgType>
	<PayloadLength>%s</PayloadLength>
	<ResultLength>%s</ResultLength>
	<Priority>%s</Priority>
	<Issuer>%s</Issuer>
	<VerbatimCommand>%s</VerbatimCommand>
	<Description>
		%s
	</Description>
	<ConsoleInput>
		%s
	</ConsoleInput>
	<ConsoleOutput>
		%s
	</ConsoleOutput>
	<Tags>
		%s
	</Tags>
</Command>
"""
		index = 0
		limit = 10000
		
		f.write(header)
		
		name_map = {}

		while True:
			entries = self.__extract_logs(index, limit)
			if not entries:
				break

			def escape_xml_string(xml_string):
				return xml_string.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").encode("utf-8")

			for entry in entries:
				self.__extract_friendlyname(name_map, entry)
				
				f.write(template % (
					str(entry.TimeStamp),
					str(entry.ClientId),
					str(entry.MessageId),
					name_map.setdefault(entry.ClientId, "").encode("utf-8"),
					entry.ProtoMsgType,
					entry.PayloadLength,
					entry.ResultLength,
					entry.Priority,
					escape_xml_string(entry.Issuer),
					escape_xml_string(entry.VerbatimCommand),
					"\n".join([("<![CDATA[%s]]>" % escape_xml_string(s)) for s in entry.Description]),
					"\n".join([("<![CDATA[%s]]>" % escape_xml_string(s)) for s in entry.ConsoleInput]),
					"\n".join([("<![CDATA[%s]]>" % escape_xml_string(s)) for s in entry.ConsoleOutput]),
					"\n".join([("<![CDATA[%s]]>" % escape_xml_string(s)) for s in entry.Tags])
				))

			index += len(entries)	
		f.write(footer)
		return

	def export_json(self, f):
		header = "["
		footer = "]"

		index = 0
		limit = 10000
		
		f.write(header)

		name_map = {}

		while True:
			entries = self.__extract_logs(index, limit)
			if not entries:
				break

			if index != 0:
				f.write(",")

			for i in xrange(len(entries)):
				entry = entries[i]

				self.__extract_friendlyname(name_map, entry)

				d_entry = {
					"TimeStamp": str(entry.TimeStamp),
					"ClientId": str(entry.ClientId),
					"MessageId": str(entry.MessageId),
					"FriendlyName": name_map.setdefault(entry.ClientId, "").encode("utf-8"),
					"ProtoMsgType": entry.ProtoMsgType,
					"PayloadLength": entry.PayloadLength,
					"ResultLength": entry.ResultLength,
					"Priority": entry.Priority,
					"Issuer": entry.Issuer,
					"VerbatimCommand": entry.VerbatimCommand,
					"Description": entry.Description,
					"ConsoleInput": entry.ConsoleInput,
					"ConsoleOutput": entry.ConsoleOutput,
					"Tags": entry.Tags
				}

				f.write(json.dumps(d_entry))
				
				if i + 1 != len(entries):
					f.write(",")

			index += len(entries)
		f.write(footer)
		return

	def export_csv(self, f):
		index = 0
		limit = 10000
		
		writer = csv.writer(f, dialect="excel")
		writer.writerow([
			"TimeStamp",
			"ClientId",
			"MessageId",
			"FriendlyName",
			"ProtoMsgType",
			"PayloadLength",
			"ResultLength",
			"Priority",
			"Issuer",
			"VerbatimCommand",
			"Description",
			"ConsoleInput",
			"ConsoleOutput",
			"Tags"
		])

		def escape_csv_multiline(s):
			return s.replace("\r","").replace("\\","\\\\").replace("\n", "\\n")

		name_map = {}

		while True:
			entries = self.__extract_logs(index, limit)
			if not entries:
				break

			for entry in entries:
				self.__extract_friendlyname(name_map, entry)

				writer.writerow([
					str(entry.TimeStamp),
					str(entry.ClientId),
					str(entry.MessageId),
					name_map.setdefault(entry.ClientId, "").encode("utf-8"),
					entry.ProtoMsgType,
					entry.PayloadLength,
					entry.ResultLength,
					entry.Priority,
					entry.Issuer.encode("utf-8"),
					entry.VerbatimCommand.encode("utf-8"),
					escape_csv_multiline("\n".join([s.encode("utf-8") for s in entry.Description])),
					escape_csv_multiline("\n".join([s.encode("utf-8") for s in entry.ConsoleInput])),
					escape_csv_multiline("\n".join([s.encode("utf-8") for s in entry.ConsoleOutput])),
					escape_csv_multiline("\n".join([s.encode("utf-8") for s in entry.Tags]))
				])
			index += len(entries)
		return

	def export_txt(self, f):
		header = """
 _______  .__       .__     __  .__                   __    
 \      \ |__| ____ |  |___/  |_|  |__ _____ __  _  _|  | __
 /   |   \|  |/ ___\|  |  \   __\  |  \\__  \\ \/ \/ /  |/ /
/    |    \  / /_/  >   Y  \  | |   Y  \/ __ \\     /|    < 
\____|__  /__\___  /|___|  /__| |___|  (____  /\/\_/ |__|_ \\
        \/  /_____/      \/          \/     \/            \/
"""
		template = "%-30s | %-36s | %-36s | %-50s | %-30s | %-16s | %-16s | %-10s\n"
		sep = "=" * len(template % tuple("" for i in xrange(template.count("%"))))

		index = 0
		limit = 10000
		
		f.write(header)

		name_map = {}

		while True:
			entries = self.__extract_logs(index, limit)
			if not entries:
				break

			for entry in entries:
				self.__extract_friendlyname(name_map, entry)

				f.write(template % (
					"TimeStamp",
					"ClientId",
					"MessageId",
					"FriendlyName",
					"ProtoMsgType",
					"PayloadLength",
					"ResultLength",
					"Priority"
				))

				f.write("%s\n" % sep)
				f.write(template % (
					str(entry.TimeStamp),
					str(entry.ClientId),
					str(entry.MessageId),
					name_map.setdefault(entry.ClientId, "").encode("utf-8"),
					entry.ProtoMsgType,
					entry.PayloadLength,
					entry.ResultLength,
					entry.Priority
				))
				
				if entry.Issuer:
					f.write("[ISSUER]\n")
					f.write("%s" % entry.Issuer.encode("utf-8"))
					f.write("\n\n")

				if entry.VerbatimCommand:
					f.write("[VERBATIM_COMMAND]\n")
					f.write("%s" % entry.VerbatimCommand.encode("utf-8"))
					f.write("\n\n")

				if entry.Description:
					f.write("[DESCRIPTION]\n")
					f.write("\n".join([s.encode("utf-8") for s in entry.Description]))
					f.write("\n\n")

				if entry.ConsoleInput:
					f.write("[CONSOLE INPUT]\n")
					f.write("\n".join([s.encode("utf-8") for s in entry.ConsoleInput]))
					f.write("\n\n")

				if entry.ConsoleOutput:
					f.write("[CONSOLE OUTPUT]\n")
					f.write("\n".join([s.encode("utf-8") for s in entry.ConsoleOutput]))
					f.write("\n\n")

				if entry.Tags:
					f.write("[TAGS]\n")
					f.write("\n".join([s.encode("utf-8") for s in entry.Tags]))
					f.write("\n\n")

				f.write("\n")
			index += len(entries)
		
		return

def exportLogs(instance_name, log_format, compress):
	exporter = DatabaseExporter.get_instance(instance_name)

	with open("%s.%s" % (instance_name, log_format), "wb") as f:
		if log_format == "xml":
			exporter.export_xml(f)
		elif log_format == "json":
			exporter.export_json(f)
		elif log_format == "csv":
			exporter.export_csv(f)
		elif log_format == "txt":
			exporter.export_txt(f)
		else:
			return
	
	return True

def showUsage():
	print "Nighthawk Log Exporter"
	print "  usage: logexporter.py <instance-name> <format> [compress]"
	print "    format - xml, json, csv, txt"
	print "  optional:"
	print "    compress - if specified the log file will be gzip compressed"
	return

if __name__ == "__main__":
	if len(sys.argv) > 2:
		if not exportLogs(sys.argv[1], sys.argv[2], False):
			print "Incorrect database or format - please check"
	else:
		showUsage()