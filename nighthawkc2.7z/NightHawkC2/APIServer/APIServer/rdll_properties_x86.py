
# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

from helpers import RDLLProperties

X86RDLLProperties = RDLLProperties(0, 837120, 4096, 776, 368, 421936)
