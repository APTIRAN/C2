
# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

from helpers import RDLLProperties

X64RDLLProperties = RDLLProperties(0, 1229824, 4096, 848, 344, 737792)
