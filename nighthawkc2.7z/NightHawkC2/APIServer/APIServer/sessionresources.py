# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import falcon
import apimanager
from base64 import b64decode, b64encode

ApiManager = apimanager.ApiManager.get_instance()

class SessionPutCommandResource(object):
	def on_post(self, req, resp, client_id, msg_id):
		if not ApiManager.session_putcommand(client_id.lower(), msg_id.lower(), req.media["payload"]):
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionClearCommandsResource(object):
	def on_get(self, req, resp, client_id, msg_id):
		ApiManager.session_clearcommands(client_id.lower(), msg_id.lower())
		resp.status = falcon.HTTP_200
		return

class SessionListResultsResource(object):
	def on_get(self, req, resp):
		resp.status = falcon.HTTP_200
		resp.media = ApiManager.session_listresults()
		return

class SessionGetResultResource(object):
	def on_get(self, req, resp, msg_id):
		command = ApiManager.session_getresult(msg_id.lower())
		if not command:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = {"payload": command}
		return

class SessionGetResultBatchResource(object):
	def on_post(self, req, resp):
		try:
			r = ApiManager.session_getresult_batch(
					[msg_id.lower() for msg_id in req.media["message_ids"]]
				)
			
			resp.media = [{"payload": command} for command in r]
		except Exception as ex:
			resp.media = {"error": ex.message}
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionListBroadcastResultsResource(object):
	def on_get(self, req, resp):
		resp.status = falcon.HTTP_200
		resp.media = ApiManager.session_listbroadcastresults()
		return

class SessionGetBroadcastResultResource(object):
	def on_get(self, req, resp, msg_id):
		command = ApiManager.session_getbroadcastresult(msg_id.lower())
		if not command:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = {"payload": command}
		return

class SessionGetLastActivityResource(object):
	def on_get(self, req, resp):
		activity = ApiManager.session_getlastactivity()
		
		resp.status = falcon.HTTP_200
		resp.media = {"lastactivity": activity}
		return

class SessionAddDetailedInfoResource(object):
	def on_post(self, req, resp, client_id):
		if not ApiManager.session_adddetailedinfo(client_id.lower(), req.media["detailedinfo"]):
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionLogCommandExtraDataResource(object):
	def on_post(self, req, resp, msg_id):
		if not ApiManager.session_log_command_extra_data(msg_id.lower(), req.media["extra_data_type"], req.media["extra_data"]):
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionLogClientExtraDataResource(object):
	def on_post(self, req, resp, client_id):
		if not ApiManager.session_log_client_extra_data(client_id.lower(), req.media["extra_data_type"], req.media["extra_data"]):
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionAddConsoleDeltaResource(object):
	def on_post(self, req, resp, client_id):
		if not ApiManager.session_addconsoledelta(client_id.lower(), req.media):
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionGetConsoleDeltaResource(object):
	def on_get(self, req, resp, client_id, delta_id):
		delta = ApiManager.session_getconsoledelta(client_id.lower(), delta_id.lower())
		if not delta:
			resp.status = falcon.HTTP_500
			return
		
		resp.media = delta
		resp.status = falcon.HTTP_200
		return

class SessionGetConsoleDeltaBatchResource(object):
	def on_post(self, req, resp, client_id):
		try:
			r = ApiManager.session_getconsoledelta_batch(
					client_id.lower(),
					[delta_id.lower() for delta_id in req.media["delta_ids"]]
				)
			
			resp.media = r
		except Exception as ex:
			resp.media = {"error": ex.message}
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionListConsoleDeltaResource(object):
	def on_get(self, req, resp, client_id, timestamp):
		resp.status = falcon.HTTP_200
		resp.media = ApiManager.session_listconsoledelta(client_id.lower(), timestamp)
		return

class SessionStoreArtifactResource(object):
	def on_post(self, req, resp, client_id, sha1hash):
		try:
			r = ApiManager.session_storeartifact(
					client_id.lower(),
					sha1hash.lower(),
					req.media["type"],
					req.media["issuer"],
					req.media["name"],
					req.media["description"],
					b64decode(req.media["payload"]) if req.media["payload"] else None,
					req.media["size"]
				)

			if not r:
				resp.status = falcon.HTTP_500
				return
		except Exception as ex:
			resp.media = {"error": ex.message}
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionArtifactExistsResource(object):
	def on_get(self, req, resp, sha1hash):
		if not ApiManager.session_artifactexists(sha1hash.lower()):
			resp.status = falcon.HTTP_404
			return
		
		resp.status = falcon.HTTP_200
		return
	
class SessionListArtifactsResource(object):
	def on_get(self, req, resp):
		r = ApiManager.session_listartifacts()
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = r
		return

class SessionDownloadArtifactResource(object):
	def on_get(self, req, resp, sha1hash):
		try:
			r = ApiManager.session_downloadartifact(sha1hash.lower())
			if not r:
				resp.status = 500
				return
		
			payload,filename = r
		except Exception as ex:
			resp.media = {"error": ex.message}
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = {"payload": b64encode(payload), "filename": filename} 
		return

class SessionHiddenDesktopStartResource(object):
	def on_get(self, req, resp, client_id, desktop_name):
		r = ApiManager.session_hiddendesktop_start(client_id.lower(), desktop_name)
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionHiddenDesktopStopResource(object):
	def on_get(self, req, resp, client_id):
		r = ApiManager.session_hiddendesktop_stop(client_id.lower())
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionHiddenDesktopStatusResource(object):
	def on_get(self, req, resp, client_id):
		r = ApiManager.session_hiddendesktop_status(client_id.lower())
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = r
		return

class SessionHiddenDesktopCaptureResource(object):
	def on_get(self, req, resp, client_id):
		r = ApiManager.session_hiddendesktop_capture(client_id.lower())
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = r
		return

class SessionHiddenDesktopInputResource(object):
	def on_post(self, req, resp, client_id):
		r = ApiManager.session_hiddendesktop_input(
				client_id,
				req.media["input_type"],
				req.media["input_key"],
				req.media["coord_x"],
				req.media["coord_y"]
			)
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return
	
class SessionHiddenDesktopCaptureWaitResource(object):
	def on_get(self, req, resp, client_id, timestamp):
		r = ApiManager.session_hiddendesktop_capturewait(client_id, timestamp)
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class SessionHiddenDesktopSetCaptureParamsResource(object):
	def on_post(self, req, resp, client_id):
		r = ApiManager.session_hiddendesktop_setcaptureparams(client_id.lower(), req.media["chunk_size"], req.media["quality"])
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = r
		return

class SessionGetP2PMeshResource(object):
	def on_get(self, req, resp):
		r = ApiManager.session_get_p2p_mesh()
		if r is None:
			resp.status = falcon.HTTP_500
			return
		
		resp.media = r
		resp.status = falcon.HTTP_200
		return

class SessionSOCKSStartResource(object):
	def on_get(self, req, resp, client_id, port):
		r = ApiManager.session_start_socks(client_id.lower(), int(port))
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.media = r
		resp.status = falcon.HTTP_200
		return

class SessionSOCKSStopResource(object):
	def on_get(self, req, resp, client_id):
		r = ApiManager.session_stop_socks(client_id.lower())
		if not r:
			resp.status = falcon.HTTP_500
			return
		
		resp.media = r
		resp.status = falcon.HTTP_200
		return