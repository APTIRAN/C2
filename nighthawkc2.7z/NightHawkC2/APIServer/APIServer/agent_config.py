# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import argparse
import json
from importlib import import_module
from os.path import exists, realpath, split, join
from helpers import recursiveMerge
from copy import deepcopy

def __formatJSON(data):
	s = json.dumps(data, indent=4, sort_keys=False)
	return s

def __mergeConfigDefaults(config):
	# merge command defaults with commands in config
	for name,value in config["commands"].iteritems():
		merged_config = dict()
		recursiveMerge(merged_config, config["command-defaults"])
		recursiveMerge(merged_config, value)
		config["commands"][name] = merged_config
	return

def __subChars(xlat_table, s):
	newstr = []
	for c in s:
		index = xlat_table[0].find(c)
		if index != -1:
			newstr.append(xlat_table[1][index])
		else:
			newstr.append(c)
	return "".join(newstr)

def xlatJSON(xlat_table, o):
	if type(o) is dict:
		n = {}
		for k,v in o.iteritems():
			if type(k) is str:
				n[__subChars(xlat_table, k)] = xlatJSON(xlat_table, v)
			elif type(k) is unicode:
				n[unicode(__subChars(xlat_table, k))] = xlatJSON(xlat_table, v)
			else:
				n[k] = xlatJSON(xlat_table, v)
		return n
	elif type(o) is list:
		n = []
		for v in o:
			n.append(xlatJSON(xlat_table, v))
		return n
	elif type(o) is str:
		return __subChars(xlat_table, o)
	elif type(o) is unicode:
		return unicode(__subChars(xlat_table, o))
	else:
		return o

def create(profile, type, uri, proxy_uri):
	if type not in ["egress", "p2p", "p2p-promote"]:
		return

	general_config = deepcopy(profile["c2-profile"]["general-config"])
	egress_config = deepcopy(profile["c2-profile"]["egress-config"])
	
	if profile["c2-profile"]["strategy"] == "http":
		__mergeConfigDefaults(egress_config)
		del egress_config["command-defaults"]
	
	p2p_config = deepcopy(profile["c2-profile"]["p2p-config"])

	implant_config = {
		"implant-config": {
				"mode": "egress" if type == "egress" else "p2p",
				"general-config": general_config,
				"egress-config": egress_config,
				"p2p-config": p2p_config,
				"listener-name": profile["c2-profile"]["listener-name"]
			}
		}

	if type == "egress":
		egress_config["c2-uri"] = uri
		
		if proxy_uri.startswith("http://"): proxy_uri = proxy_uri[7:]
		elif proxy_uri.startswith("https://"): proxy_uri = proxy_uri[8:]

		if proxy_uri.endswith("/"): proxy_uri = proxy_uri[:-1]

		proxy_creds = ""

		if "@" in proxy_uri:
			proxy_creds = proxy_uri.split("@", 1)[0]
			proxy_uri = proxy_uri.split("@", 1)[1]

		if proxy_uri: egress_config["proxy-override-uri"] = proxy_uri
		if proxy_creds: egress_config["proxy-override-credentials"] = proxy_creds
	else:
		p2p_config["p2p-listener-uri"] = uri

	if type == "p2p":
		# remove unnecessary profile info
		del implant_config["implant-config"]["egress-config"]
	elif type == "p2p-promote":
		implant_config["implant-config"]["p2p-config"]["promote"] = True
	
	return implant_config