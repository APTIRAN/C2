# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import sqlite3
import os
import json
from base64 import b64decode, b64encode
from datetime import datetime
from pprint import pprint
import struct
import hashlib

import apimanager

class ServerType(object):
	DEPLOYED = 0
	ADOPTED = 1

class CommandExtraDataType(object):
	VERBATIM_COMMAND = "VERBATIM_COMMAND" # for exact command logging
	DESCRIPTION = "DESCRIPTION"			# for embellishing reports
	PRIORITY = "PRIORITY"				# low, medium, high - for highlighting certain events
	CONSOLE_INPUT = "CONSOLE_INPUT"		# attach the command typed into the console that triggered the event
	CONSOLE_OUTPUT = "CONSOLE_OUTPUT"	# attach the corresponding console output
	TAGS = "TAGS"						# tags for reporting
	ISSUER = "ISSUER"					# issuing user

class ClientExtraDataType(object):
	DESCRIPTION = 0
	MISC = 1

class Database(object):
	__instance = None
	__DB_FOLDER_PATH = "./db/"

	@staticmethod
	def get_instance(name):
		if not Database.__instance:
			Database.__instance = Database(name)
		return Database.__instance
	
	def __init__(self, name):
		self.__db_name = name
		self.__db_path = Database.__DB_FOLDER_PATH + name + ".db"
		
		self.__setup()
		return

	def __setup(self):
		conn = sqlite3.connect(self.__db_path)
		cur = conn.cursor()

		# a table containing user credentials
		cur.execute("CREATE TABLE IF NOT EXISTS UserAccounts (Username text, PasswordHash text, PasswordSalt text)")

		# a table containing deployed and torn down c2s
		cur.execute("CREATE TABLE IF NOT EXISTS C2Servers (TimeStamp text, ServerType integer, ListenerName text, Secret text, Profile text, Active integer)")
		
		# a table containing currently queued commands in case we need to kill and resume the server
		cur.execute("CREATE TABLE IF NOT EXISTS QueuedCommands (ClientId text, MessageId text, Payload text, Result text)")
		
		# a table containing a record of clients and their last activity
		cur.execute("CREATE TABLE IF NOT EXISTS LastClientActivity (ClientId text, TimeStamp text, IP text, DetailedInfo text, ListenerName text)")
		try:
			cur.execute("CREATE UNIQUE INDEX idx_client_id ON LastClientActivity (ClientId)")
		except sqlite3.OperationalError:
			pass

		# a table containing info on all commands submitted throughout the campaign
		cur.execute("CREATE TABLE IF NOT EXISTS LoggedCommands (TimeStamp text, ClientId text, MessageId text, PayloadHeader text, ResultHeader text)")
		
		# a table containing extra data for logged commands (can have multiple extra data per command)
		cur.execute("CREATE TABLE IF NOT EXISTS LoggedCommandExtraData (TimeStamp text, MessageId text, CommandExtraDataType text, ExtraData text)")
		
		# a table containing extra data for clients (can have multiple extra data per client)
		cur.execute("CREATE TABLE IF NOT EXISTS LoggedClientExtraData (TimeStamp text, ClientId text, ClientExtraDataType text, ExtraData text)")
		
		# a table containing shared console data for clients
		cur.execute("CREATE TABLE IF NOT EXISTS SharedConsole (TimeStampUtc text, ClientId text, DeltaId text, DeltaType text, DeltaData text)")
		
		# a table containing copies of engagement artifacts sent to/from the target
		cur.execute("CREATE TABLE IF NOT EXISTS EngagementArtifacts (TimeStampUtc text, ClientId text, ArtifactType text, Issuer text, ArtifactName text, ArtifactSize text, Description text, SHA1Hash text)")

		conn.close()
		return

	def __execute_sql(self, sql_cmd, params = ()):
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute(sql_cmd, params)
		finally:
			conn.close()
		return

	def erase_db(self):
		self.__execute_sql("DROP TABLE IF EXISTS UserAccounts")
		self.__execute_sql("DROP TABLE IF EXISTS C2Servers")
		self.__execute_sql("DROP TABLE IF EXISTS QueuedCommands")
		self.__execute_sql("DROP TABLE IF EXISTS LastClientActivity")
		self.__execute_sql("DROP TABLE IF EXISTS LoggedCommands")
		self.__execute_sql("DROP TABLE IF EXISTS LoggedCommandExtraData")
		self.__execute_sql("DROP TABLE IF EXISTS LoggedClientExtraData")
		self.__execute_sql("DROP TABLE IF EXISTS SharedConsole")
		self.__execute_sql("DROP TABLE IF EXISTS EngagementArtifacts")
		return self.__setup()

	def store_artifact(self, client_id, artifact_type, issuer, artifact_name, artifact_size, description, sha1hash):
		return self.__execute_sql("INSERT INTO EngagementArtifacts VALUES (?,?,?,?,?,?,?,?)", (str(datetime.utcnow()), client_id, artifact_type, issuer, artifact_name, artifact_size, description, sha1hash))

	def get_artifact(self, sha1hash):
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute("SELECT TimeStampUtc, ClientId, ArtifactType, Issuer, ArtifactName, ArtifactSize, Description, SHA1Hash FROM EngagementArtifacts WHERE SHA1Hash = ?", (sha1hash,))
				
				rows = cur.fetchall()
				if rows:
					row = rows[0]
					return {
						"timestamp": str(row[0]),
						"client_id": str(row[1]),
						"artifact_type": str(row[2]),
						"issuer": str(row[3]),
						"name": str(row[4]),
						"size": str(row[5]),
						"description": str(row[6]),
						"sha1hash": str(row[7])
					}
		finally:
			conn.close()
		return

	def list_artifacts(self):
		artifacts = []
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute("SELECT TimeStampUtc, ClientId, ArtifactType, Issuer, ArtifactName, ArtifactSize, Description, SHA1Hash FROM EngagementArtifacts")
				
				rows = cur.fetchall()
				for row in rows:
					artifacts.append(({
						"timestamp": str(row[0]),
						"client_id": str(row[1]),
						"artifact_type": str(row[2]),
						"issuer": str(row[3]),
						"name": str(row[4]),
						"size": str(row[5]),
						"description": str(row[6]),
						"sha1hash": str(row[7])
					}))
		finally:
			conn.close()
		return artifacts
	
	def campaign_exists(self):
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute("SELECT ListenerName FROM C2Servers")
				
				rows = cur.fetchone()
				if rows:
					return True
		finally:
			conn.close()
		return

	def setup_user(self, username, password_clear):
		password_salt = "n1ghth4wk!"
		password_hash = b64encode(hashlib.pbkdf2_hmac("sha256", password_clear, password_salt, 100000))
		self.__execute_sql("DELETE FROM UserAccounts WHERE Username = ?", (username,))
		self.__execute_sql("INSERT INTO UserAccounts VALUES (?,?,?)", (username, password_hash, password_salt))
		return

	def check_auth(self, username, password_clear):
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute("SELECT PasswordHash, PasswordSalt FROM UserAccounts WHERE Username = ?", (username,))
				
				row = cur.fetchone()
				if not row:
					return

				password_hash = row[0]
				password_salt = row[1]

				compare_against = b64encode(hashlib.pbkdf2_hmac("sha256", password_clear, password_salt, 100000))
				if compare_against == password_hash:
					return True
		finally:
			conn.close()
		return

	def add_c2(self, server_type, inst): # DeployedC2Instance
		return self.__execute_sql("INSERT INTO C2Servers VALUES (?,?,?,?,?,?)", (str(datetime.now()), server_type, inst.ListenerName, inst.Secret, json.dumps(inst.Profile), 1))

	def remove_c2(self, inst): # DeployedC2Instance
		return self.__execute_sql("UPDATE C2Servers SET Active = 0 WHERE ListenerName = ?", (inst.ListenerName,))

	def get_c2s(self):
		existing_c2s = []
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute("SELECT TimeStamp, ServerType, ListenerName, Secret, Profile, Active FROM C2Servers")
				
				rows = cur.fetchall()
				for row in rows:
					existing_c2s.append((str(row[0]), int(row[1]), str(row[2]), str(row[3]), str(row[4]), int(row[5])))
		finally:
			conn.close()
		return existing_c2s

	def add_queued_command(self, inst):
		return self.__execute_sql("INSERT INTO QueuedCommands VALUES (?,?,?,?)", (inst.ClientId, inst.MessageId, inst.Payload, inst.Result))

	def clear_queued_commands(self, client_id):
		return self.__execute_sql("DELETE FROM QueuedCommands WHERE ClientId = ?", (client_id,))

	def remove_queued_command(self, inst):
		return self.__execute_sql("DELETE FROM QueuedCommands WHERE MessageId = ?", (inst.MessageId,))

	def get_queued_commands(self): #QueuedCommand
		queued_commands = []
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute("SELECT ClientId, MessageId, Payload, Result FROM QueuedCommands")
				
				rows = cur.fetchall()
				for row in rows:
					queued_commands.append((str(row[0]), str(row[1]), str(row[2]), str(row[3])))
		finally:
			conn.close()
		return queued_commands

	def update_last_client_activity(self, inst):
		detailed_info = "" if not inst.DetailedInfo else inst.DetailedInfo
		return self.__execute_sql("REPLACE INTO LastClientActivity (ClientId, TimeStamp, IP, DetailedInfo, ListenerName) VALUES (?,?,?,?,?)", (inst.ClientId, str(inst.TimeStamp), inst.IP, detailed_info, inst.ListenerName))

	def log_command(self, inst):
		payload_header = b64decode(inst.Payload)[:apimanager.PROTOMSG_HEADER_LENGTH]
		result_header = b64decode(inst.Result)[:apimanager.PROTOMSG_HEADER_LENGTH] if inst.Result else ""
		
		msg_type = struct.unpack("<I", payload_header[40:44])[0]
		
		#if msg_type in [apimanager.ECommsProtocolMessageType.CPMT_GET_FILEPART, apimanager.ECommsProtocolMessageType.CPMT_PUT_FILE, apimanager.ECommsProtocolMessageType.CPMT_SOCKS_MSG]:
		#	return

		return self.__execute_sql("INSERT INTO LoggedCommands VALUES (?,?,?,?,?)", (str(datetime.now()), inst.ClientId, inst.MessageId, b64encode(payload_header), b64encode(result_header)))
	
	def update_command_result(self, inst):
		result_header = b64decode(inst.Result)[:64] if inst.Result else ""
		return self.__execute_sql("UPDATE LoggedCommands SET ResultHeader = ? WHERE MessageId = ?", (b64encode(result_header), inst.MessageId))
	
	def add_command_extra_data(self, message_id, extra_data_type, extra_data):
		if extra_data_type in [CommandExtraDataType.PRIORITY, CommandExtraDataType.TAGS]:
			self.__execute_sql("DELETE FROM LoggedCommandExtraData WHERE MessageId = ? AND CommandExtraDataType = ?", (message_id, extra_data_type))
		return self.__execute_sql("INSERT INTO LoggedCommandExtraData VALUES (?,?,?,?)", (str(datetime.now()), message_id, extra_data_type, extra_data))
	
	def add_client_extra_data(self, client_id, extra_data_type, extra_data):
		return self.__execute_sql("INSERT INTO LoggedClientExtraData VALUES (?,?,?,?)", (str(datetime.now()), client_id, extra_data_type, extra_data))

	def add_console_delta(self, delta):
		return self.__execute_sql("INSERT INTO SharedConsole VALUES (?,?,?,?,?)", (str(delta.TimeStampUtc), delta.ClientId, delta.DeltaId, delta.DeltaType, delta.DeltaData))
		return

	def get_console_deltas(self): #ConsoleDelta
		client_ids = set()
		try:
			with sqlite3.connect(self.__db_path) as conn:
				cur = conn.cursor()
				cur.execute("SELECT ClientId FROM SharedConsole")
				
				rows = cur.fetchall()
				for row in rows:
					client_ids.add(str(row[0]))
		finally:
			conn.close()
		
		console_deltas = {}

		for client_id in client_ids:
			
			try:
				with sqlite3.connect(self.__db_path) as conn:
					cur = conn.cursor()
					cur.execute("SELECT TimeStampUtc, ClientId, DeltaId, DeltaType, DeltaData FROM SharedConsole WHERE ClientId = ?", (client_id,))
				
					rows = cur.fetchall()
					for row in rows:
						console_deltas.setdefault(client_id,[]).append((str(row[0]), str(row[1]), str(row[2]), str(row[3]), str(row[4])))
			finally:
				conn.close()

		return console_deltas

if __name__ == "__main__":
	#os.remove(r".\db\test.db")

	db = Database.get_instance("foobar")
	
	from deployc2 import DeployedC2Instance
	inst = DeployedC2Instance.adopt("test_listener", json.loads(open(r"C:\Users\Peter\Desktop\dev\implant\Profiles\office365.json").read()))
	
	db.add_c2(ServerType.ADOPTED, inst)
	db.remove_c2(inst)

	from apimanager import QueuedCommand
	inst = QueuedCommand("11111111-1111-1111-1111-111111111111", "11111111-1111-1111-1111-222222222222", "ABCD==")
	
	db.add_queued_command(inst)
	db.remove_queued_command(inst)


	from apimanager import ClientActivity
	inst = ClientActivity("11111111-1111-1111-1111-111111111111", datetime.now(), "10.1.11.2")
	db.update_last_client_activity(inst)
	inst.DetailedInfo = "YYYY=="
	db.update_last_client_detailed_info(inst)
	
	inst = QueuedCommand("11111111-1111-1111-1111-111111111111", "11111111-1111-1111-1111-222222222222", "ABCD==")
	db.log_command(inst)

	inst.Result = "XXXX=="
	db.update_command_result(inst)

	db.add_command_extra_data(inst.MessageId, CommandExtraDataType.DESCRIPTION, "hello world")
	db.add_command_extra_data(inst.MessageId, CommandExtraDataType.DESCRIPTION, "hello world")
	db.add_command_extra_data(inst.MessageId, CommandExtraDataType.DESCRIPTION, "hello world2")

	db.add_client_extra_data(inst.ClientId, ClientExtraDataType.DESCRIPTION, "hello")
	db.add_client_extra_data(inst.ClientId, ClientExtraDataType.DESCRIPTION, "hello")
