# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import struct
import gzip
import StringIO
import itertools
from datetime import datetime, timedelta
from gzip import GzipFile
from StringIO import StringIO
from Crypto.Cipher import AES
from copy import deepcopy

class RDLLProperties(object):
	def __init__(self, profile_raw_size, profile_raw_address, section_alignment, section_header_offset, image_size_offset, reflective_loader_offset):
		self.__profile_raw_size = profile_raw_size
		self.__profile_raw_address = profile_raw_address
		self.__section_alignment = section_alignment
		self.__section_header_offset = section_header_offset
		self.__image_size_offset = image_size_offset
		self.__reflective_loader_offset = reflective_loader_offset
		return
	
	def get_profile_section_header_offset(self):
		return self.__section_header_offset

	def get_profile_section_raw_size(self):
		return self.__profile_raw_size

	def get_profile_section_raw_address(self):
		return self.__profile_raw_address

	def get_section_alignment(self):
		return self.__section_alignment

	def get_image_size_offset(self):
		return self.__image_size_offset
	
	def get_reflective_loader_offset(self):
		return self.__reflective_loader_offset


def recursiveMerge(_to, _from):
	if (type(_to), type(_from)) == (dict, dict):
		for k in _from.iterkeys():
			if k in _to:
				if type(_from[k]) in [dict, list]:
					recursiveMerge(_to[k], _from[k])
					continue
			
			_to[k] = deepcopy(_from[k])
	elif (type(_to), type(_from)) == (list, list):
		for item in _from:
			if item not in _to:
				_to.append(deepcopy(item))
	else:
		raise Exception("recursiveMerge should only be called with matching dict/list inputs")
	
	return

def lookupConfig(config, path):
	pieces = path.split(".", 1)
	current = pieces.pop(0)
	if current in config:
		if type(config[current]) == dict and pieces:
			return lookupConfig(config[current], pieces.pop())
		else:
			return config[current]
	return

def is_pe_arch_x64(dll_bytes):
	pe_hdr_offs = struct.unpack("<H", dll_bytes[0x3c:0x3c + 2])[0]
	arch = struct.unpack("<H", dll_bytes[pe_hdr_offs + 0x18:pe_hdr_offs+0x18 + 2])[0]
	return arch != 0x010b

def write_le_dword(buf, offset, value):
	return buf[:offset] + struct.pack("<I", value) + buf[offset + 4:]

def gzip_compress(buf):
	out = StringIO()
	gzip_file = gzip.GzipFile(fileobj=out, mode='wb')
	gzip_file.write(buf)
	gzip_file.close()
	return out.getvalue()

# https://stackoverflow.com/a/63746596

FILE_TIME_EPOCH = datetime(1601, 1, 1)
FILE_TIME_MICROSECOND = 10 # FILETIME counts 100 nanoseconds intervals = 0.1 microseconds, so 10 of those are 1 microsecond
US_IN_SECOND = 1000000

def convert_from_file_time(ft):
    microseconds_since_file_time_epoch = ft // FILE_TIME_MICROSECOND
    return FILE_TIME_EPOCH + timedelta(microseconds=microseconds_since_file_time_epoch)

def convert_to_file_time(dt):
	microseconds_since_file_time_epoch = int((dt - FILE_TIME_EPOCH).total_seconds() // timedelta(microseconds=1).total_seconds())
	return microseconds_since_file_time_epoch * FILE_TIME_MICROSECOND

def aes128_encrypt(key, data):
	length = 16 - (len(data) % 16)
	data += chr(length)*length
	aes = AES.new(key, AES.MODE_CBC, "\x00" * 16)
	return aes.encrypt(data)