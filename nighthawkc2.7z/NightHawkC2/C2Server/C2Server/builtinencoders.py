# Copyright 2021 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

#	{ "BuiltIn.Text.DoNothingEncoder", CBuiltInEncoders::DoNothingEncoder },
#	{ "BuiltIn.Text.Base64Encode", CBuiltInEncoders::Base64Encode },
#	{ "BuiltIn.Text.Base64Decode", CBuiltInEncoders::Base64Decode },
#	{ "BuiltIn.Text.Base64UrlEncode", CBuiltInEncoders::Base64UrlEncode },
#	{ "BuiltIn.Text.Base64UrlDecode", CBuiltInEncoders::Base64UrlDecode },
#	{ "BuiltIn.Binary.GzipCompress", CBuiltInEncoders::GzipCompress},
#	{ "BuiltIn.Binary.GzipDecompress", CBuiltInEncoders::GzipDecompress },

from base64 import b64encode, b64decode
from gzip import GzipFile
from StringIO import StringIO

class BuiltIn(object):
	class Text(object):
		@staticmethod
		def DoNothingEncoder(data):
			return data
		
		@staticmethod
		def Base64Encode(data):
			return b64encode(data)
		
		@staticmethod
		def Base64Decode(data):
			return b64decode(data)
		
		@staticmethod
		def Base64UrlEncode(data):
			return b64encode(data).replace("+", "-").replace("/", "_").replace("=", ".")
		
		@staticmethod
		def Base64UrlDecode(data):
			return b64decode(data.replace("-", "+").replace("_", "/").replace(".", "="))
		
	class Binary(object):
		@staticmethod
		def GzipCompress(data):
			buf = StringIO()
			comp = GzipFile(fileobj=buf, mode="wb")
			comp.write(data)
			comp.close()
			return buf.getvalue()
		
		@staticmethod
		def GzipDecompress(data):
			decomp = GzipFile(fileobj=StringIO(data), mode="rb")
			buf = decomp.read()
			decomp.close()
			return buf
