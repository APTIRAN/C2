# Copyright 2021 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)


class EndpointBase(object):
	Config = None
	ApiClient = None
	
	def __init__(self, config, apiclient, listener_name, secret):
		EndpointBase.Config = config
		EndpointBase.ApiClient = apiclient
		EndpointBase.ListenerName = listener_name
		EndpointBase.EncoderNamespace = {}
		EndpointBase.Secret = secret
		return
	
	def start(self):
		raise Exception("EndpointBase.start() must be overridden")
	
	def stop(self):
		raise Exception("EndpointBase.stop() must be overridden")
