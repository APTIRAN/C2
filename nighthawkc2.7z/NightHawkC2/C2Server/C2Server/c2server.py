# Copyright 2021 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import argparse
import json
from importlib import import_module
from os.path import exists,realpath,split,join
from time import sleep

from apiclient import ApiClient

parser = argparse.ArgumentParser(description="MDSec C2 Server Launcher")
parser.add_argument("--profile", type=str, default="default.json", help="Configuration JSON profile file name")
parser.add_argument("listener_name", type=str, default=None, help="Listener name")
parser.add_argument("secret", type=str, default=None, help="Service-to-Service secret")
args = parser.parse_args()

class C2Server(object):
	def __init__(self, profile, listener_name, secret):
		if "c2-profile" not in profile:
			raise Exception("C2Server profile format incorrect")
		
		self.__profile = profile["c2-profile"]
		self.__listener_name = listener_name
		self.__secret = secret
		self.__endpoint = None
		return
	
	def __import_endpoint(self, strategy):
		module_name = (strategy + "-endpoint").replace("-", "_")
		module_path = join(split(realpath(__file__))[0], module_name + ".py") 
		
		if "\\" in module_name or "/" in module_name or not exists(module_path):
			raise Exception("C2Server invalid strategy name (%s)" % strategy)
		
		return import_module(module_name)
	
	def launch(self):
		endpoint = self.__import_endpoint(self.__profile["strategy"])
		self.__endpoint = endpoint.Endpoint(
				self.__profile["server-config"],
				ApiClient(
					self.__profile["api"]["host"],
					self.__profile["api"]["port"],
					self.__listener_name,
					self.__secret
				),
				self.__listener_name,
				self.__secret
			)
		return self.__endpoint.start()
	
	def shutdown(self):
		self.__endpoint.stop()
		return

profile = None

print "C2Server starting... (name: %s, secret: %s, profile: %s)" % (args.listener_name, args.secret, args.profile)

with open(args.profile, "rb") as f:
	# switch to hjson as it's much nicer to hand author
	profile = json.loads(f.read())

c2 = C2Server(profile, args.listener_name, args.secret)
c2.launch()
try:
	apiclient = ApiClient(
			profile["c2-profile"]["api"]["host"],
			profile["c2-profile"]["api"]["port"],
			args.listener_name,
			args.secret
		)
	
	while True:
		status_code,action = apiclient.control_getaction(args.listener_name)
		if status_code == 200 and action:
			if action["action"] == "shutdown":
				break
		
		sleep(1)
except KeyboardInterrupt:
	pass
except Exception as e:
	print " !! Exception caught: %s" % repr(e)
finally:
	c2.shutdown()