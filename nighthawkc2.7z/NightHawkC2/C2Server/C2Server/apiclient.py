# Copyright 2021 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

import requests
from base64 import b64decode
from uuid import UUID,uuid4
from datetime import datetime

class ApiClient(object):
	def __init__(self, host, port, listener_name, secret):
		self.__host = host
		self.__port = port
		self.__listener_name = listener_name
		self.__secret = secret
		return
	
	def __http_get(self, uri):
		full_url = "http://%s:%u%s" % (self.__host, self.__port, uri)
		r = requests.get(full_url, headers={"Authorization": self.__secret, "X-Listener-Name": self.__listener_name})
		return (r.status_code, r.json() if r.text else None)
	
	def __http_post(self, uri, json):
		full_url = "http://%s:%u%s" % (self.__host, self.__port, uri)
		r = requests.post(full_url, json=json, headers={"Authorization": self.__secret, "X-Listener-Name": self.__listener_name})
		return (r.status_code, r.json() if r.text else None)
	
# C2 agent command routes
	
	def c2_status(self):
		uri = "/c2/status"
		return self.__http_get(uri)
	
	def c2_listcommands(self, clientid):
		uri = "/c2/listcommands/{clientid}".format(clientid=str(UUID(clientid)))
		return self.__http_get(uri)
	
	def c2_getcommand(self, msgid):
		uri = "/c2/getcommand/{msgid}".format(msgid=str(UUID(msgid)))
		return self.__http_get(uri)
	
	def c2_putresult(self, clientid, msgid, payload):
		uri = "/c2/putresult/{clientid}/{msgid}".format(clientid=str(UUID(clientid)), msgid=str(UUID(msgid)))
		return self.__http_post(uri, payload)
	
	def c2_notifyactivity(self, clientid, listener_name, ip):
		uri = "/c2/notifyactivity/{clientid}/{listener_name}".format(clientid=str(UUID(clientid)), listener_name=listener_name)
		return self.__http_post(uri, {"ip": ip})
	
# service control routes
	
	def control_getaction(self, listener_name):
		uri = "/control/getaction/{listener_name}".format(listener_name=listener_name)
		return self.__http_get(uri)
