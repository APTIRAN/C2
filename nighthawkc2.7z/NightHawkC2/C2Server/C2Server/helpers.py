# Copyright 2021 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

from copy import deepcopy

def recursiveMerge(_to, _from):
	if (type(_to), type(_from)) == (dict, dict):
		for k in _from.iterkeys():
			if k in _to:
				if type(_from[k]) in [dict, list]:
					recursiveMerge(_to[k], _from[k])
					continue
			
			_to[k] = deepcopy(_from[k])
	elif (type(_to), type(_from)) == (list, list):
		for item in _from:
			if item not in _to:
				_to.append(deepcopy(item))
	else:
		raise Exception("recursiveMerge should only be called with matching dict/list inputs")
	
	return

def lookupConfig(config, path):
	pieces = path.split(".", 1)
	current = pieces.pop(0)
	if current in config:
		if type(config[current]) == dict and pieces:
			return lookupConfig(config[current], pieces.pop())
		else:
			return config[current]
	return
